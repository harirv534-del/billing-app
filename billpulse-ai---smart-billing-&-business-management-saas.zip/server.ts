import express, { Request, Response, NextFunction } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { db } from './server/db';
import { recognizeProductsFromImage } from './server/gemini';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Universal CORS & Preflight Handling
app.use((req: Request, res: Response, next: NextFunction) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization, x-business-id, x-user-id');
  res.header('Access-Control-Allow-Credentials', 'true');
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }
  next();
});

// High body limit for camera image payloads
app.use(express.json({ limit: '30mb' }));
app.use(express.urlencoded({ extended: true, limit: '30mb' }));

// ==========================================
// STORE VERIFICATION & WELL-KNOWN ENDPOINTS (Google Play TWA & Apple App Store)
// ==========================================
app.get('/.well-known/assetlinks.json', (_req: Request, res: Response) => {
  res.setHeader('Content-Type', 'application/json');
  const assetLinksPath = path.resolve(__dirname, 'public/.well-known/assetlinks.json');
  if (fs.existsSync(assetLinksPath)) {
    return res.sendFile(assetLinksPath);
  }
  return res.json([
    {
      relation: ['delegate_permission/common.handle_all_urls'],
      target: {
        namespace: 'android_app',
        package_name: 'com.billpulse.app',
        sha256_cert_fingerprints: [
          '14:6D:E9:7D:0F:52:AB:AC:6E:9B:04:88:1C:1E:58:62:39:69:42:07:37:A6:49:1C:C6:DA:52:0A:7F:0E:9F:8B',
        ],
      },
    },
  ]);
});

app.get('/.well-known/apple-app-site-association', (_req: Request, res: Response) => {
  res.setHeader('Content-Type', 'application/json');
  const applePath = path.resolve(__dirname, 'public/.well-known/apple-app-site-association');
  if (fs.existsSync(applePath)) {
    return res.sendFile(applePath);
  }
  return res.json({
    applinks: {
      apps: [],
      details: [
        {
          appID: 'TEAMID1234.com.billpulse.app',
          paths: ['*'],
        },
      ],
    },
    webcredentials: {
      apps: ['TEAMID1234.com.billpulse.app'],
    },
  });
});

// Helper to extract authenticated user & businessId
interface AuthSession {
  userId: string;
  businessId: string | null;
  role: string;
  name: string;
}

function getSession(req: Request): AuthSession {
  // Support header-based session or query for simplicity and testability
  const authHeader = req.headers.authorization;
  const userHeader = req.headers['x-user-id'] as string;
  const bizHeader = req.headers['x-business-id'] as string;

  if (userHeader) {
    const user = db.getUserById(userHeader);
    if (user) {
      return {
        userId: user.id,
        businessId: user.businessId,
        role: user.role,
        name: user.name,
      };
    }
  }

  // Fallback to default owner session (Cafe) for seamless development
  const defaultOwner = db.getUsers().find((u) => u.role === 'owner') || db.getUsers()[1];
  return {
    userId: defaultOwner.id,
    businessId: bizHeader || defaultOwner.businessId || 'biz_cafe_01',
    role: defaultOwner.role,
    name: defaultOwner.name,
  };
}

// ==========================================
// 1. AUTHENTICATION & SESSION ROUTES
// ==========================================

app.post('/api/auth/login', (req: Request, res: Response) => {
  const { emailOrPhone, password, role } = req.body;

  if (!emailOrPhone) {
    return res.status(400).json({ error: 'Email or phone number is required' });
  }

  // Super admin check
  if (emailOrPhone.toLowerCase() === 'admin@billpulse.io') {
    const adminUser = db.getUserByEmail('admin@billpulse.io');
    if (adminUser) {
      return res.json({
        user: adminUser,
        business: null,
        token: `token_admin_${adminUser.id}`,
      });
    }
  }

  // Find user by email or phone
  const user = db.getUsers().find(
    (u) =>
      u.email.toLowerCase() === emailOrPhone.toLowerCase() ||
      u.phone === emailOrPhone
  );

  if (!user) {
    return res.status(401).json({ error: 'Invalid credentials or user not registered' });
  }

  if (!user.active) {
    return res.status(403).json({ error: 'This user account has been deactivated' });
  }

  const business = user.businessId ? db.getBusiness(user.businessId) : null;
  if (business && !business.active) {
    return res.status(403).json({ error: 'This business account is currently inactive. Contact platform support.' });
  }

  // Record audit log
  db.addAuditLog({
    businessId: user.businessId,
    userId: user.id,
    userName: user.name,
    action: 'USER_LOGIN',
    details: `User ${user.name} logged in (${user.role})`,
  });

  return res.json({
    user,
    business,
    token: `token_${user.id}_${Date.now()}`,
  });
});

app.post('/api/auth/register', async (req: Request, res: Response) => {
  try {
    const {
      businessName,
      ownerName,
      email,
      phone,
      password,
      businessType,
      city,
      state,
      currency,
      invoicePrefix,
    } = req.body;

    if (!businessName || !email || !ownerName) {
      return res.status(400).json({ error: 'Business name, owner name, and email are required' });
    }

    const existing = db.getUserByEmail(email);
    if (existing) {
      return res.status(400).json({ error: 'An account with this email already exists' });
    }

    const now = new Date().toISOString();
    const newBizId = `biz_${Date.now()}`;
    const newUserId = `usr_${Date.now()}`;

    const newBusiness = await db.createBusiness({
      id: newBizId,
      name: businessName,
      ownerName,
      email,
      phone: phone || '',
      address: '',
      city: city || '',
      state: state || '',
      country: 'India',
      currency: currency || 'INR',
      currencySymbol: currency === 'USD' ? '$' : currency === 'EUR' ? '€' : '₹',
      invoicePrefix: (invoicePrefix || businessName.substring(0, 4)).toUpperCase().replace(/[^A-Z]/g, '') || 'INV',
      nextInvoiceSequence: 1,
      businessType: businessType || 'General Retail',
      active: true,
      plan: 'Free',
      createdAt: now,
      updatedAt: now,
    });

    const newUser = await db.createUser({
      id: newUserId,
      businessId: newBizId,
      name: ownerName,
      email,
      phone: phone || '',
      passwordHash: password || 'pass123',
      role: 'owner',
      active: true,
      createdAt: now,
    });

    // Seed default initial products for new business so they can test immediately
    await db.createProduct({
      id: `prod_${newBizId}_01`,
      businessId: newBizId,
      name: 'Signature Item / Special',
      category: 'General',
      price: 100,
      stock: 50,
      lowStockLimit: 10,
      sku: 'GEN-01',
      taxPercent: 5,
      description: 'Default store product',
      active: true,
      createdAt: now,
      updatedAt: now,
    });

    await db.addAuditLog({
      businessId: newBizId,
      userId: newUserId,
      userName: ownerName,
      action: 'BUSINESS_REGISTERED',
      details: `New business "${businessName}" registered on Free plan.`,
    });

    return res.status(201).json({
      user: newUser,
      business: newBusiness,
      token: `token_${newUser.id}`,
    });
  } catch (err: any) {
    console.error('Registration error:', err);
    return res.status(500).json({ error: 'Failed to create business account' });
  }
});

app.get('/api/auth/me', (req: Request, res: Response) => {
  const session = getSession(req);
  const user = db.getUserById(session.userId);
  const business = session.businessId ? db.getBusiness(session.businessId) : null;
  return res.json({ user, business });
});

// ==========================================
// 2. BUSINESS PROFILE & SETTINGS
// ==========================================

app.get('/api/business/profile', (req: Request, res: Response) => {
  const session = getSession(req);
  if (!session.businessId) {
    return res.status(400).json({ error: 'No business context' });
  }
  const biz = db.getBusiness(session.businessId);
  return res.json(biz);
});

app.put('/api/business/profile', async (req: Request, res: Response) => {
  const session = getSession(req);
  if (!session.businessId) {
    return res.status(400).json({ error: 'No business context' });
  }
  const updated = await db.updateBusiness(session.businessId, req.body);
  db.addAuditLog({
    businessId: session.businessId,
    userId: session.userId,
    userName: session.name,
    action: 'BUSINESS_PROFILE_UPDATED',
    details: `Business profile settings updated by ${session.name}`,
  });
  return res.json(updated);
});

// Staff management
app.get('/api/business/staff', (req: Request, res: Response) => {
  const session = getSession(req);
  if (!session.businessId) return res.status(400).json({ error: 'No business context' });
  const staff = db.getBusinessUsers(session.businessId);
  return res.json(staff);
});

app.post('/api/business/staff', async (req: Request, res: Response) => {
  const session = getSession(req);
  if (!session.businessId) return res.status(400).json({ error: 'No business context' });
  if (session.role !== 'owner' && session.role !== 'manager') {
    return res.status(403).json({ error: 'Only owners and managers can add staff members' });
  }

  const { name, email, phone, role, password } = req.body;
  if (!name || !email || !role) {
    return res.status(400).json({ error: 'Name, email, and role are required' });
  }

  const existing = db.getUserByEmail(email);
  if (existing) return res.status(400).json({ error: 'User with this email already exists' });

  const newUser = await db.createUser({
    id: `usr_staff_${Date.now()}`,
    businessId: session.businessId,
    name,
    email,
    phone: phone || '',
    passwordHash: password || 'staff123',
    role,
    active: true,
    createdAt: new Date().toISOString(),
  });

  return res.status(201).json(newUser);
});

// ==========================================
// 3. PRODUCT MANAGEMENT
// ==========================================

app.get('/api/products', (req: Request, res: Response) => {
  const session = getSession(req);
  if (!session.businessId) return res.status(400).json({ error: 'No business context' });

  let products = db.getProducts(session.businessId);
  const { search, category, lowStockOnly } = req.query;

  if (search) {
    const s = String(search).toLowerCase();
    products = products.filter(
      (p) =>
        p.name.toLowerCase().includes(s) ||
        p.sku.toLowerCase().includes(s) ||
        (p.barcode && p.barcode.includes(s))
    );
  }

  if (category && category !== 'All') {
    products = products.filter((p) => p.category === category);
  }

  if (lowStockOnly === 'true') {
    products = products.filter((p) => p.stock <= p.lowStockLimit);
  }

  return res.json(products);
});

app.post('/api/products', async (req: Request, res: Response) => {
  const session = getSession(req);
  if (!session.businessId) return res.status(400).json({ error: 'No business context' });

  const { name, category, price, stock, lowStockLimit, sku, barcode, taxPercent, description } = req.body;
  if (!name || price === undefined) {
    return res.status(400).json({ error: 'Product name and price are required' });
  }

  const now = new Date().toISOString();
  const newProduct = await db.createProduct({
    id: `prod_${session.businessId}_${Date.now()}`,
    businessId: session.businessId,
    name,
    category: category || 'General',
    price: Number(price),
    stock: Number(stock) || 0,
    lowStockLimit: Number(lowStockLimit) || 5,
    sku: sku || `SKU-${Date.now().toString().slice(-4)}`,
    barcode: barcode || '',
    taxPercent: Number(taxPercent) || 0,
    description: description || '',
    active: true,
    createdAt: now,
    updatedAt: now,
  });

  db.addAuditLog({
    businessId: session.businessId,
    userId: session.userId,
    userName: session.name,
    action: 'PRODUCT_CREATED',
    details: `Added new product "${newProduct.name}" (Price: ${newProduct.price}, Stock: ${newProduct.stock})`,
  });

  return res.status(201).json(newProduct);
});

app.put('/api/products/:id', async (req: Request, res: Response) => {
  const session = getSession(req);
  if (!session.businessId) return res.status(400).json({ error: 'No business context' });

  const updated = await db.updateProduct(session.businessId, req.params.id, req.body);
  if (!updated) return res.status(404).json({ error: 'Product not found' });

  db.addAuditLog({
    businessId: session.businessId,
    userId: session.userId,
    userName: session.name,
    action: 'PRODUCT_UPDATED',
    details: `Updated product "${updated.name}"`,
  });

  return res.json(updated);
});

app.delete('/api/products/:id', async (req: Request, res: Response) => {
  const session = getSession(req);
  if (!session.businessId) return res.status(400).json({ error: 'No business context' });

  const deleted = await db.deleteProduct(session.businessId, req.params.id);
  if (!deleted) return res.status(404).json({ error: 'Product not found' });

  db.addAuditLog({
    businessId: session.businessId,
    userId: session.userId,
    userName: session.name,
    action: 'PRODUCT_DELETED',
    details: `Deleted product ID ${req.params.id}`,
  });

  return res.json({ success: true });
});

// ==========================================
// 4. AI QUICK PHOTO BILLING ENDPOINT
// ==========================================

app.post('/api/ai/recognize-products', async (req: Request, res: Response) => {
  const session = getSession(req);
  if (!session.businessId) return res.status(400).json({ error: 'No business context' });

  const { imageBase64, mimeType } = req.body;
  if (!imageBase64) {
    return res.status(400).json({ error: 'Image data is required for product recognition' });
  }

  try {
    const catalog = db.getProducts(session.businessId);
    const recognition = await recognizeProductsFromImage(imageBase64, mimeType, catalog);

    db.addAuditLog({
      businessId: session.businessId,
      userId: session.userId,
      userName: session.name,
      action: 'AI_PHOTO_BILL_SCAN',
      details: `Processed photo recognition (${recognition.draftItems.length} items draft, ${recognition.processingTimeMs}ms)`,
    });

    return res.json(recognition);
  } catch (err: any) {
    console.error('AI Recognition Error:', err);
    return res.status(500).json({
      error: 'Unable to analyze image. Please try again or switch to Manual Billing.',
      details: err.message,
    });
  }
});

// ==========================================
// 5. INVOICE CREATION & CONCURRENCY-SAFE BILLING
// ==========================================

app.post('/api/invoices/create', async (req: Request, res: Response) => {
  const session = getSession(req);
  if (!session.businessId) return res.status(400).json({ error: 'No business context' });

  const {
    items,
    customerName,
    customerPhone,
    paymentMethod,
    discountTotal,
    taxTotal,
    subtotal,
    grandTotal,
    notes,
  } = req.body;

  if (!items || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'Cannot create bill with empty item list' });
  }

  try {
    const invoice = await db.createInvoiceAtomic(session.businessId, {
      businessId: session.businessId,
      customerName: customerName || '',
      customerPhone: customerPhone || '',
      items,
      subtotal: Number(subtotal) || 0,
      discountTotal: Number(discountTotal) || 0,
      taxTotal: Number(taxTotal) || 0,
      grandTotal: Number(grandTotal) || 0,
      paymentMethod: paymentMethod || 'Cash',
      notes: notes || '',
      createdByUserId: session.userId,
      createdByName: session.name,
    });

    return res.status(201).json(invoice);
  } catch (err: any) {
    console.error('Invoice Creation Error:', err);
    return res.status(500).json({
      error: 'Unable to save bill. Please check your connection and retry.',
      details: err.message,
    });
  }
});

app.get('/api/invoices', (req: Request, res: Response) => {
  const session = getSession(req);
  if (!session.businessId) return res.status(400).json({ error: 'No business context' });

  let invoices = db.getInvoices(session.businessId);
  const { search, paymentMethod, date, limit } = req.query;

  if (search) {
    const s = String(search).toLowerCase();
    invoices = invoices.filter(
      (inv) =>
        inv.invoiceNumber.toLowerCase().includes(s) ||
        (inv.customerName && inv.customerName.toLowerCase().includes(s)) ||
        (inv.customerPhone && inv.customerPhone.includes(s)) ||
        inv.items.some((item) => item.name.toLowerCase().includes(s))
    );
  }

  if (paymentMethod && paymentMethod !== 'All') {
    invoices = invoices.filter((inv) => inv.paymentMethod === paymentMethod);
  }

  if (date) {
    invoices = invoices.filter((inv) => inv.createdAt.startsWith(String(date)));
  }

  if (limit) {
    invoices = invoices.slice(0, Number(limit));
  }

  return res.json(invoices);
});

app.get('/api/invoices/:id', (req: Request, res: Response) => {
  const invoice = db.getInvoiceById(req.params.id);
  if (!invoice) return res.status(404).json({ error: 'Invoice not found' });
  const business = db.getBusiness(invoice.businessId);
  return res.json({ invoice, business });
});

// Bill correction with audit trail & stock reversal
app.put('/api/invoices/:id/correct', async (req: Request, res: Response) => {
  const session = getSession(req);
  if (!session.businessId) return res.status(400).json({ error: 'No business context' });

  const { reason, items, paymentMethod, customerName, customerPhone } = req.body;
  if (!reason || !items || items.length === 0) {
    return res.status(400).json({ error: 'Correction reason and updated items are mandatory' });
  }

  try {
    const corrected = await db.correctInvoice(
      req.params.id,
      session.businessId,
      session.userId,
      session.name,
      reason,
      items,
      paymentMethod,
      customerName,
      customerPhone
    );
    return res.json(corrected);
  } catch (err: any) {
    console.error('Invoice Correction Error:', err);
    return res.status(500).json({ error: err.message || 'Failed to correct invoice' });
  }
});

// ==========================================
// 6. INVENTORY & STOCK TRACKING
// ==========================================

app.get('/api/inventory/status', (req: Request, res: Response) => {
  const session = getSession(req);
  if (!session.businessId) return res.status(400).json({ error: 'No business context' });

  const products = db.getProducts(session.businessId);
  const movements = db.getInventoryMovements(session.businessId);

  const lowStock = products.filter((p) => p.stock <= p.lowStockLimit);
  const outOfStock = products.filter((p) => p.stock === 0);
  const totalItems = products.reduce((acc, p) => acc + p.stock, 0);
  const totalValue = products.reduce((acc, p) => acc + p.stock * p.price, 0);

  return res.json({
    products,
    recentMovements: movements.slice(0, 30),
    summary: {
      totalProductsCount: products.length,
      totalStockUnits: totalItems,
      totalInventoryValue: totalValue,
      lowStockCount: lowStock.length,
      outOfStockCount: outOfStock.length,
    },
  });
});

app.post('/api/inventory/adjust', async (req: Request, res: Response) => {
  const session = getSession(req);
  if (!session.businessId) return res.status(400).json({ error: 'No business context' });

  const { productId, changeQty, reason } = req.body;
  if (!productId || changeQty === undefined) {
    return res.status(400).json({ error: 'Product ID and change quantity are required' });
  }

  const updated = await db.adjustStock(
    session.businessId,
    productId,
    Number(changeQty),
    reason,
    session.userId,
    session.name
  );

  if (!updated) return res.status(404).json({ error: 'Product not found' });
  return res.json(updated);
});

// ==========================================
// 7. CUSTOMERS & PURCHASE HISTORY
// ==========================================

app.get('/api/customers', (req: Request, res: Response) => {
  const session = getSession(req);
  if (!session.businessId) return res.status(400).json({ error: 'No business context' });

  let customers = db.getCustomers(session.businessId);
  const { search } = req.query;

  if (search) {
    const s = String(search).toLowerCase();
    customers = customers.filter(
      (c) => c.name.toLowerCase().includes(s) || c.phone.includes(s)
    );
  }

  return res.json(customers);
});

app.get('/api/customers/:phone/history', (req: Request, res: Response) => {
  const session = getSession(req);
  if (!session.businessId) return res.status(400).json({ error: 'No business context' });

  const customer = db.getCustomerByPhone(session.businessId, req.params.phone);
  const invoices = db.getInvoices(session.businessId).filter((inv) => inv.customerPhone === req.params.phone);

  return res.json({ customer, invoices });
});

// ==========================================
// 8. SALES REPORTING & ANALYTICS
// ==========================================

app.get('/api/reports/daily', (req: Request, res: Response) => {
  const session = getSession(req);
  if (!session.businessId) return res.status(400).json({ error: 'No business context' });

  const targetDateStr = (req.query.date as string) || new Date().toISOString().slice(0, 10);
  const allInvoices = db.getInvoices(session.businessId);

  const todayInvoices = allInvoices.filter((inv) => inv.createdAt.startsWith(targetDateStr));

  let totalRevenue = 0;
  let totalItemsSold = 0;
  const productSalesMap: Record<string, { name: string; qty: number; revenue: number }> = {};
  const categorySalesMap: Record<string, { qty: number; revenue: number }> = {};
  const paymentMethodsBreakdown: Record<string, number> = { Cash: 0, UPI: 0, Card: 0, Other: 0 };

  for (const inv of todayInvoices) {
    totalRevenue += inv.grandTotal;
    paymentMethodsBreakdown[inv.paymentMethod] = (paymentMethodsBreakdown[inv.paymentMethod] || 0) + inv.grandTotal;

    for (const item of inv.items) {
      totalItemsSold += item.quantity;
      if (!productSalesMap[item.productId]) {
        productSalesMap[item.productId] = { name: item.name, qty: 0, revenue: 0 };
      }
      productSalesMap[item.productId].qty += item.quantity;
      productSalesMap[item.productId].revenue += item.total;
    }
  }

  const topProducts = Object.values(productSalesMap).sort((a, b) => b.qty - a.qty);
  const topProduct = topProducts[0] || null;

  return res.json({
    date: targetDateStr,
    totalBills: todayInvoices.length,
    totalRevenue,
    totalItemsSold,
    averageBillValue: todayInvoices.length > 0 ? Math.round(totalRevenue / todayInvoices.length) : 0,
    topProduct,
    topProductsList: topProducts.slice(0, 10),
    paymentMethodsBreakdown,
    invoices: todayInvoices,
  });
});

app.get('/api/reports/analytics', (req: Request, res: Response) => {
  const session = getSession(req);
  if (!session.businessId) return res.status(400).json({ error: 'No business context' });

  const allInvoices = db.getInvoices(session.businessId);
  const products = db.getProducts(session.businessId);

  // Group by day for the last 30 days
  const dailyData: Record<string, { date: string; revenue: number; bills: number }> = {};
  const now = new Date();

  for (let i = 29; i >= 0; i--) {
    const d = new Date(now.getTime() - i * 24 * 3600 * 1000);
    const key = d.toISOString().slice(0, 10);
    dailyData[key] = { date: key, revenue: 0, bills: 0 };
  }

  const productAgg: Record<string, { name: string; category: string; quantity: number; revenue: number }> = {};
  const categoryAgg: Record<string, number> = {};

  for (const inv of allInvoices) {
    const dayKey = inv.createdAt.slice(0, 10);
    if (dailyData[dayKey]) {
      dailyData[dayKey].revenue += inv.grandTotal;
      dailyData[dayKey].bills += 1;
    }

    for (const item of inv.items) {
      if (!productAgg[item.name]) {
        const prod = products.find((p) => p.id === item.productId);
        productAgg[item.name] = {
          name: item.name,
          category: prod?.category || 'General',
          quantity: 0,
          revenue: 0,
        };
      }
      productAgg[item.name].quantity += item.quantity;
      productAgg[item.name].revenue += item.total;

      const cat = productAgg[item.name].category;
      categoryAgg[cat] = (categoryAgg[cat] || 0) + item.total;
    }
  }

  const topSellingProducts = Object.values(productAgg).sort((a, b) => b.revenue - a.revenue);

  return res.json({
    dailyTrend: Object.values(dailyData),
    categoryBreakdown: categoryAgg,
    topSellingProducts: topSellingProducts.slice(0, 8),
    totalInvoicesRecorded: allInvoices.length,
    overallGrossVolume: allInvoices.reduce((a, b) => a + b.grandTotal, 0),
  });
});

// Audit logs
app.get('/api/audit-logs', (req: Request, res: Response) => {
  const session = getSession(req);
  if (!session.businessId) return res.status(400).json({ error: 'No business context' });
  const logs = db.getAuditLogs(session.businessId);
  return res.json(logs.slice(0, 50));
});

// ==========================================
// 9. SUPER ADMIN SYSTEM
// ==========================================

app.post('/api/admin/login', (req: Request, res: Response) => {
  const { email, password } = req.body;
  if (email === 'admin@billpulse.io' && (password === 'SuperAdmin2026!' || password === 'admin123')) {
    const adminUser = db.getUserByEmail('admin@billpulse.io');
    return res.json({
      success: true,
      token: 'superadmin_token_pulse',
      user: adminUser,
    });
  }
  return res.status(401).json({ error: 'Invalid Super Admin credentials' });
});

app.get('/api/admin/metrics', (req: Request, res: Response) => {
  const metrics = db.getPlatformMetrics();
  const recentAudit = db.getAuditLogs().slice(0, 20);
  return res.json({
    ...metrics,
    recentAudit,
  });
});

app.get('/api/admin/businesses', (req: Request, res: Response) => {
  const businesses = db.getBusinesses();
  const invoices = db.getBusinesses().map((b) => {
    const bizInvoices = db.getInvoices(b.id);
    const totalVolume = bizInvoices.reduce((acc, inv) => acc + inv.grandTotal, 0);
    return {
      ...b,
      billCount: bizInvoices.length,
      totalVolume,
    };
  });
  return res.json(invoices);
});

app.post('/api/admin/businesses/:id/toggle-status', async (req: Request, res: Response) => {
  const biz = db.getBusiness(req.params.id);
  if (!biz) return res.status(404).json({ error: 'Business not found' });

  const updated = await db.updateBusiness(req.params.id, { active: !biz.active });
  db.addAuditLog({
    businessId: null,
    userId: 'user_admin_00',
    userName: 'Super Admin',
    action: 'ADMIN_BUSINESS_STATUS_TOGGLED',
    details: `Business ${biz.name} (${biz.id}) status changed to ${updated?.active ? 'ACTIVE' : 'INACTIVE'}`,
  });

  return res.json(updated);
});

app.post('/api/admin/businesses/:id/plan', async (req: Request, res: Response) => {
  const { plan } = req.body;
  if (!['Free', 'Pro', 'Business', 'Enterprise'].includes(plan)) {
    return res.status(400).json({ error: 'Invalid plan' });
  }

  const updated = await db.updateBusiness(req.params.id, { plan });
  db.addAuditLog({
    businessId: null,
    userId: 'user_admin_00',
    userName: 'Super Admin',
    action: 'ADMIN_PLAN_MODIFIED',
    details: `Business ${updated?.name} plan updated to ${plan}`,
  });

  return res.json(updated);
});

// ==========================================
// 10. VITE DEV SERVER MOUNTING & PRODUCTION
// ==========================================

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);

    // Fallback for HTML5 history API navigation
    app.use('*', async (req: Request, res: Response, next: NextFunction) => {
      if (req.originalUrl.startsWith('/api')) {
        return next();
      }
      try {
        const indexHtml = fs.readFileSync(path.resolve(__dirname, 'index.html'), 'utf-8');
        const transformedHtml = await vite.transformIndexHtml(req.originalUrl, indexHtml);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(transformedHtml);
      } catch (err) {
        next(err);
      }
    });
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  // Global Express error handler returning JSON
  app.use((err: any, req: Request, res: Response, next: NextFunction) => {
    console.error('[Server Error]', err);
    if (!res.headersSent) {
      res.status(500).json({ error: err.message || 'Internal Server Error' });
    }
  });

  const listenPort = Number(PORT) || 3000;
  app.listen(listenPort, '0.0.0.0', () => {
    console.log(`[BillPulse AI Server] Listening on http://0.0.0.0:${listenPort}`);
  });
}

startServer();
