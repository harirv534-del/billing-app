import fs from 'fs';
import path from 'path';

export interface Business {
  id: string;
  name: string;
  ownerName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  country: string;
  gstNumber?: string;
  taxInfo?: string;
  currency: string;
  currencySymbol: string;
  invoicePrefix: string;
  nextInvoiceSequence: number;
  businessType: string;
  logoUrl?: string;
  active: boolean;
  plan: 'Free' | 'Pro' | 'Business' | 'Enterprise';
  createdAt: string;
  updatedAt: string;
}

export interface User {
  id: string;
  businessId: string | null; // null for super_admin
  name: string;
  email: string;
  phone: string;
  passwordHash: string;
  role: 'super_admin' | 'owner' | 'manager' | 'cashier' | 'staff';
  active: boolean;
  createdAt: string;
}

export interface Product {
  id: string;
  businessId: string;
  name: string;
  category: string;
  price: number;
  stock: number;
  lowStockLimit: number;
  sku: string;
  barcode?: string;
  taxPercent: number;
  description?: string;
  imageUrl?: string;
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Customer {
  id: string;
  businessId: string;
  name: string;
  phone: string;
  totalPurchases: number;
  totalSpent: number;
  lastPurchaseDate: string;
  invoicesCount: number;
  createdAt: string;
}

export interface InvoiceItem {
  productId: string;
  name: string;
  sku?: string;
  quantity: number;
  unitPrice: number;
  taxPercent: number;
  discountPercent: number;
  subtotal: number;
  taxAmount: number;
  discountAmount: number;
  total: number;
}

export interface InvoiceCorrection {
  correctedAt: string;
  correctedBy: string;
  reason: string;
  previousGrandTotal: number;
  newGrandTotal: number;
  previousItems: InvoiceItem[];
  newItems: InvoiceItem[];
}

export interface Invoice {
  id: string;
  businessId: string;
  invoiceNumber: string;
  sequence: number;
  customerName?: string;
  customerPhone?: string;
  items: InvoiceItem[];
  subtotal: number;
  discountTotal: number;
  taxTotal: number;
  grandTotal: number;
  paymentMethod: 'Cash' | 'UPI' | 'Card' | 'Other';
  status: 'confirmed' | 'corrected' | 'cancelled';
  notes?: string;
  createdByUserId: string;
  createdByName: string;
  correctionHistory: InvoiceCorrection[];
  createdAt: string;
  updatedAt: string;
}

export interface InventoryMovement {
  id: string;
  businessId: string;
  productId: string;
  productName: string;
  type: 'sold' | 'added' | 'adjustment' | 'correction_reversal' | 'correction_reapply';
  quantityChange: number;
  previousStock: number;
  newStock: number;
  referenceId?: string; // invoiceId
  notes: string;
  timestamp: string;
}

export interface AuditLog {
  id: string;
  businessId?: string | null;
  userId: string;
  userName: string;
  action: string;
  details: string;
  timestamp: string;
}

export interface DatabaseSchema {
  businesses: Business[];
  users: User[];
  products: Product[];
  customers: Customer[];
  invoices: Invoice[];
  inventoryMovements: InventoryMovement[];
  auditLogs: AuditLog[];
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'store.json');

class DatabaseStore {
  private data: DatabaseSchema;
  private writeLock: Promise<void> = Promise.resolve();

  constructor() {
    this.ensureDataDir();
    this.data = this.loadOrSeed();
  }

  private ensureDataDir() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
  }

  private loadOrSeed(): DatabaseSchema {
    if (fs.existsSync(DB_FILE)) {
      try {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        return JSON.parse(raw);
      } catch (err) {
        console.error('Failed reading existing store.json, re-seeding...', err);
      }
    }
    const initial = this.getSeedData();
    this.saveSync(initial);
    return initial;
  }

  private saveSync(dataToSave: DatabaseSchema) {
    try {
      const tempPath = `${DB_FILE}.tmp.${Date.now()}`;
      fs.writeFileSync(tempPath, JSON.stringify(dataToSave, null, 2), 'utf-8');
      fs.renameSync(tempPath, DB_FILE);
    } catch (err) {
      console.error('Error saving database:', err);
    }
  }

  public async persist(): Promise<void> {
    this.writeLock = this.writeLock.then(async () => {
      this.saveSync(this.data);
    });
    return this.writeLock;
  }

  private getSeedData(): DatabaseSchema {
    const now = new Date().toISOString();

    const businesses: Business[] = [
      {
        id: 'biz_cafe_01',
        name: 'Madurai Spice Cafe & Bistro',
        ownerName: 'Karthik Raja',
        email: 'karthik@maduraispice.com',
        phone: '9876543210',
        address: '12 West Masi Street, Opp. Meenakshi Temple',
        city: 'Madurai',
        state: 'Tamil Nadu',
        country: 'India',
        gstNumber: '33AAAAA0000A1Z5',
        taxInfo: 'GST 5% Food & Beverage',
        currency: 'INR',
        currencySymbol: '₹',
        invoicePrefix: 'CAFE',
        nextInvoiceSequence: 1043,
        businessType: 'Cafe / Restaurant',
        active: true,
        plan: 'Business',
        createdAt: new Date(Date.now() - 60 * 24 * 3600 * 1000).toISOString(),
        updatedAt: now,
      },
      {
        id: 'biz_mart_02',
        name: 'City SuperMarket & Grocery',
        ownerName: 'Priya Sharma',
        email: 'priya@cityhypermarket.com',
        phone: '9876501234',
        address: '88 Commercial Ring Road, Sector 4',
        city: 'Bengaluru',
        state: 'Karnataka',
        country: 'India',
        gstNumber: '29BBBBB1111B1Z2',
        taxInfo: 'Composite Retail GST',
        currency: 'INR',
        currencySymbol: '₹',
        invoicePrefix: 'MART',
        nextInvoiceSequence: 382,
        businessType: 'Supermarket / Retail',
        active: true,
        plan: 'Pro',
        createdAt: new Date(Date.now() - 45 * 24 * 3600 * 1000).toISOString(),
        updatedAt: now,
      },
      {
        id: 'biz_salon_03',
        name: 'Aura Luxury Salon & Wellness',
        ownerName: 'Ananya Roy',
        email: 'ananya@aurasalon.com',
        phone: '9876512345',
        address: '42 Park Street, 2nd Floor',
        city: 'Kolkata',
        state: 'West Bengal',
        country: 'India',
        gstNumber: '19CCCCC2222C1Z8',
        currency: 'INR',
        currencySymbol: '₹',
        invoicePrefix: 'AURA',
        nextInvoiceSequence: 154,
        businessType: 'Salon & Spa',
        active: true,
        plan: 'Free',
        createdAt: new Date(Date.now() - 30 * 24 * 3600 * 1000).toISOString(),
        updatedAt: now,
      },
    ];

    const users: User[] = [
      {
        id: 'user_admin_00',
        businessId: null,
        name: 'Super Admin',
        email: 'admin@billpulse.io',
        phone: '1800100200',
        passwordHash: 'admin123', // In demo/prod allows fast login
        role: 'super_admin',
        active: true,
        createdAt: now,
      },
      {
        id: 'user_karthik_01',
        businessId: 'biz_cafe_01',
        name: 'Karthik Raja',
        email: 'karthik@maduraispice.com',
        phone: '9876543210',
        passwordHash: 'cafe123',
        role: 'owner',
        active: true,
        createdAt: now,
      },
      {
        id: 'user_cashier_01',
        businessId: 'biz_cafe_01',
        name: 'Ramesh Kumar (Cashier)',
        email: 'ramesh@maduraispice.com',
        phone: '9876543211',
        passwordHash: 'cashier123',
        role: 'cashier',
        active: true,
        createdAt: now,
      },
      {
        id: 'user_priya_02',
        businessId: 'biz_mart_02',
        name: 'Priya Sharma',
        email: 'priya@cityhypermarket.com',
        phone: '9876501234',
        passwordHash: 'mart123',
        role: 'owner',
        active: true,
        createdAt: now,
      },
      {
        id: 'user_ananya_03',
        businessId: 'biz_salon_03',
        name: 'Ananya Roy',
        email: 'ananya@aurasalon.com',
        phone: '9876512345',
        passwordHash: 'salon123',
        role: 'owner',
        active: true,
        createdAt: now,
      },
    ];

    const products: Product[] = [
      // Cafe Products
      {
        id: 'prod_cafe_01',
        businessId: 'biz_cafe_01',
        name: 'Lays Classic Salted (52g)',
        category: 'Snacks & Packets',
        price: 20,
        stock: 85,
        lowStockLimit: 15,
        sku: 'SNK-LAY-01',
        barcode: '8901491101837',
        taxPercent: 5,
        description: 'Classic salted potato chips pouch',
        active: true,
        createdAt: now,
        updatedAt: now,
      },
      {
        id: 'prod_cafe_02',
        businessId: 'biz_cafe_01',
        name: 'Bun Biscuit / Butter Cookies',
        category: 'Bakery',
        price: 30,
        stock: 45,
        lowStockLimit: 10,
        sku: 'BAK-BIS-02',
        barcode: '8901063012921',
        taxPercent: 5,
        description: 'Freshly baked butter tea bun biscuit',
        active: true,
        createdAt: now,
        updatedAt: now,
      },
      {
        id: 'prod_cafe_03',
        businessId: 'biz_cafe_01',
        name: 'Special Cutting Tea / Chai',
        category: 'Beverages',
        price: 20,
        stock: 500,
        lowStockLimit: 50,
        sku: 'BEV-TEA-03',
        taxPercent: 5,
        description: 'Cardamom infused hot ginger milk tea',
        active: true,
        createdAt: now,
        updatedAt: now,
      },
      {
        id: 'prod_cafe_04',
        businessId: 'biz_cafe_01',
        name: 'South Indian Filter Coffee',
        category: 'Beverages',
        price: 30,
        stock: 350,
        lowStockLimit: 40,
        sku: 'BEV-COF-04',
        taxPercent: 5,
        description: 'Traditional decoction filter coffee',
        active: true,
        createdAt: now,
        updatedAt: now,
      },
      {
        id: 'prod_cafe_05',
        businessId: 'biz_cafe_01',
        name: 'Hot Crispy Veg Puff',
        category: 'Bakery',
        price: 25,
        stock: 28,
        lowStockLimit: 8,
        sku: 'BAK-PUF-05',
        taxPercent: 5,
        description: 'Flaky pastry filled with spiced potato and peas',
        active: true,
        createdAt: now,
        updatedAt: now,
      },
      {
        id: 'prod_cafe_06',
        businessId: 'biz_cafe_01',
        name: 'Chocolate Cheesecake Slice',
        category: 'Desserts',
        price: 120,
        stock: 18,
        lowStockLimit: 5,
        sku: 'DST-CHK-06',
        taxPercent: 5,
        description: 'Belgian rich dark chocolate cheesecake',
        active: true,
        createdAt: now,
        updatedAt: now,
      },
      {
        id: 'prod_cafe_07',
        businessId: 'biz_cafe_01',
        name: 'Paneer Tikka Grilled Sandwich',
        category: 'Fast Food',
        price: 90,
        stock: 40,
        lowStockLimit: 10,
        sku: 'FST-SND-07',
        taxPercent: 5,
        description: 'Marinated paneer slices, mint chutney on multi-grain bread',
        active: true,
        createdAt: now,
        updatedAt: now,
      },
      {
        id: 'prod_cafe_08',
        businessId: 'biz_cafe_01',
        name: 'Fresh Mango Milkshake',
        category: 'Beverages',
        price: 70,
        stock: 30,
        lowStockLimit: 5,
        sku: 'BEV-SHK-08',
        taxPercent: 5,
        description: 'Alphonso mango pulp blended with chilled milk',
        active: true,
        createdAt: now,
        updatedAt: now,
      },
      {
        id: 'prod_cafe_09',
        businessId: 'biz_cafe_01',
        name: 'Crispy Punjabi Samosa (2 pcs)',
        category: 'Snacks & Packets',
        price: 30,
        stock: 6, // Low stock demo!
        lowStockLimit: 10,
        sku: 'SNK-SAM-09',
        taxPercent: 5,
        description: 'Hot deep fried potato & cashew stuffed samosas',
        active: true,
        createdAt: now,
        updatedAt: now,
      },
      {
        id: 'prod_cafe_10',
        businessId: 'biz_cafe_01',
        name: 'Bread Packet (400g White)',
        category: 'Bakery',
        price: 40,
        stock: 22,
        lowStockLimit: 10,
        sku: 'BAK-BRD-10',
        barcode: '8901063140020',
        taxPercent: 0,
        description: 'Soft sliced sandwich bread loaf',
        active: true,
        createdAt: now,
        updatedAt: now,
      },
      {
        id: 'prod_cafe_11',
        businessId: 'biz_cafe_01',
        name: 'Fresh Lime Mint Soda',
        category: 'Beverages',
        price: 45,
        stock: 90,
        lowStockLimit: 15,
        sku: 'BEV-LME-11',
        taxPercent: 5,
        description: 'Sparkling soda with fresh lemon and crushed mint',
        active: true,
        createdAt: now,
        updatedAt: now,
      },

      // Supermarket Products
      {
        id: 'prod_mart_01',
        businessId: 'biz_mart_02',
        name: 'Lays American Style Cream & Onion',
        category: 'Snacks',
        price: 20,
        stock: 140,
        lowStockLimit: 20,
        sku: 'GRC-LAY-01',
        barcode: '8901491101844',
        taxPercent: 12,
        active: true,
        createdAt: now,
        updatedAt: now,
      },
      {
        id: 'prod_mart_02',
        businessId: 'biz_mart_02',
        name: 'Amul Taaza Milk (500ml Pouch)',
        category: 'Dairy',
        price: 32,
        stock: 45,
        lowStockLimit: 15,
        sku: 'DRY-AML-02',
        taxPercent: 0,
        active: true,
        createdAt: now,
        updatedAt: now,
      },
      {
        id: 'prod_mart_03',
        businessId: 'biz_mart_02',
        name: 'Tata Salt Vacuum Evaporated (1kg)',
        category: 'Pantry',
        price: 28,
        stock: 120,
        lowStockLimit: 25,
        sku: 'PAN-TAT-03',
        barcode: '8901058852204',
        taxPercent: 0,
        active: true,
        createdAt: now,
        updatedAt: now,
      },
      {
        id: 'prod_mart_04',
        businessId: 'biz_mart_02',
        name: 'Aashirvaad Shudh Chakki Atta (5kg)',
        category: 'Pantry',
        price: 265,
        stock: 38,
        lowStockLimit: 10,
        sku: 'PAN-ASH-04',
        barcode: '8901725114510',
        taxPercent: 0,
        active: true,
        createdAt: now,
        updatedAt: now,
      },
      {
        id: 'prod_mart_05',
        businessId: 'biz_mart_02',
        name: 'Maggi 2-Minute Masala Noodles (4-Pack)',
        category: 'Instant Food',
        price: 56,
        stock: 80,
        lowStockLimit: 15,
        sku: 'INS-MAG-05',
        barcode: '8901058860216',
        taxPercent: 12,
        active: true,
        createdAt: now,
        updatedAt: now,
      },

      // Salon Products
      {
        id: 'prod_sal_01',
        businessId: 'biz_salon_03',
        name: 'Haircut & Styling (Master Stylist)',
        category: 'Hair Care',
        price: 350,
        stock: 999,
        lowStockLimit: 10,
        sku: 'SLN-HC-01',
        taxPercent: 18,
        active: true,
        createdAt: now,
        updatedAt: now,
      },
      {
        id: 'prod_sal_02',
        businessId: 'biz_salon_03',
        name: 'Organic Fruit Facial & Glow Spa',
        category: 'Skin Care',
        price: 800,
        stock: 999,
        lowStockLimit: 10,
        sku: 'SLN-FC-02',
        taxPercent: 18,
        active: true,
        createdAt: now,
        updatedAt: now,
      },
    ];

    const customers: Customer[] = [
      {
        id: 'cust_01',
        businessId: 'biz_cafe_01',
        name: 'Arun Balaji',
        phone: '9840123456',
        totalPurchases: 4,
        totalSpent: 840,
        lastPurchaseDate: new Date(Date.now() - 2 * 24 * 3600 * 1000).toISOString(),
        invoicesCount: 4,
        createdAt: now,
      },
      {
        id: 'cust_02',
        businessId: 'biz_cafe_01',
        name: 'Meena Sundaram',
        phone: '9443219876',
        totalPurchases: 2,
        totalSpent: 410,
        lastPurchaseDate: new Date(Date.now() - 5 * 24 * 3600 * 1000).toISOString(),
        invoicesCount: 2,
        createdAt: now,
      },
    ];

    // Seed recent invoices for realistic 30-day reporting and instant charts
    const invoices: Invoice[] = [];
    const inventoryMovements: InventoryMovement[] = [];
    const auditLogs: AuditLog[] = [];

    // Generate 12 past invoices over the last 15 days for Cafe
    const paymentMethods: Array<'Cash' | 'UPI' | 'Card'> = ['UPI', 'Cash', 'Card', 'UPI', 'UPI'];
    for (let i = 1; i <= 12; i++) {
      const daysAgo = Math.floor((12 - i) * 1.2);
      const invoiceDate = new Date(Date.now() - daysAgo * 24 * 3600 * 1000 - (i * 3600 * 1000)).toISOString();
      const seq = 1030 + i;
      const invoiceNumber = `CAFE-2026-${String(seq).padStart(6, '0')}`;
      
      const item1 = products[0]; // Lays
      const item2 = products[2]; // Tea
      const qty1 = (i % 3) + 1;
      const qty2 = (i % 2) + 2;

      const subtotal = (item1.price * qty1) + (item2.price * qty2);
      const taxTotal = Math.round(subtotal * 0.05);
      const grandTotal = subtotal + taxTotal;

      const invoice: Invoice = {
        id: `inv_seed_${i}`,
        businessId: 'biz_cafe_01',
        invoiceNumber,
        sequence: seq,
        customerName: i % 2 === 0 ? 'Arun Balaji' : 'Walk-in Guest',
        customerPhone: i % 2 === 0 ? '9840123456' : '',
        items: [
          {
            productId: item1.id,
            name: item1.name,
            sku: item1.sku,
            quantity: qty1,
            unitPrice: item1.price,
            taxPercent: 5,
            discountPercent: 0,
            subtotal: item1.price * qty1,
            taxAmount: Math.round(item1.price * qty1 * 0.05),
            discountAmount: 0,
            total: item1.price * qty1 + Math.round(item1.price * qty1 * 0.05),
          },
          {
            productId: item2.id,
            name: item2.name,
            sku: item2.sku,
            quantity: qty2,
            unitPrice: item2.price,
            taxPercent: 5,
            discountPercent: 0,
            subtotal: item2.price * qty2,
            taxAmount: Math.round(item2.price * qty2 * 0.05),
            discountAmount: 0,
            total: item2.price * qty2 + Math.round(item2.price * qty2 * 0.05),
          },
        ],
        subtotal,
        discountTotal: 0,
        taxTotal,
        grandTotal,
        paymentMethod: paymentMethods[i % paymentMethods.length],
        status: 'confirmed',
        createdByUserId: 'user_karthik_01',
        createdByName: 'Karthik Raja',
        correctionHistory: [],
        createdAt: invoiceDate,
        updatedAt: invoiceDate,
      };

      invoices.push(invoice);

      inventoryMovements.push({
        id: `mov_seed_${i}_1`,
        businessId: 'biz_cafe_01',
        productId: item1.id,
        productName: item1.name,
        type: 'sold',
        quantityChange: -qty1,
        previousStock: item1.stock + qty1,
        newStock: item1.stock,
        referenceId: invoice.id,
        notes: `Billed in ${invoiceNumber}`,
        timestamp: invoiceDate,
      });
    }

    auditLogs.push({
      id: 'log_01',
      businessId: 'biz_cafe_01',
      userId: 'user_karthik_01',
      userName: 'Karthik Raja',
      action: 'SYSTEM_INITIALIZED',
      details: 'Madurai Spice Cafe & Bistro business workspace initialized',
      timestamp: now,
    });

    return {
      businesses,
      users,
      products,
      customers,
      invoices,
      inventoryMovements,
      auditLogs,
    };
  }

  // --- Multi-tenant query methods ---
  public getBusinesses() {
    return this.data.businesses;
  }

  public getBusiness(id: string) {
    return this.data.businesses.find((b) => b.id === id);
  }

  public async updateBusiness(id: string, updates: Partial<Business>): Promise<Business | null> {
    const idx = this.data.businesses.findIndex((b) => b.id === id);
    if (idx === -1) return null;
    this.data.businesses[idx] = {
      ...this.data.businesses[idx],
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    await this.persist();
    return this.data.businesses[idx];
  }

  public async createBusiness(biz: Business): Promise<Business> {
    this.data.businesses.push(biz);
    await this.persist();
    return biz;
  }

  // Users
  public getUsers() {
    return this.data.users;
  }

  public getUserByEmail(email: string) {
    return this.data.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  }

  public getUserById(id: string) {
    return this.data.users.find((u) => u.id === id);
  }

  public getBusinessUsers(businessId: string) {
    return this.data.users.filter((u) => u.businessId === businessId);
  }

  public async createUser(user: User): Promise<User> {
    this.data.users.push(user);
    await this.persist();
    return user;
  }

  public async updateUser(id: string, updates: Partial<User>): Promise<User | null> {
    const idx = this.data.users.findIndex((u) => u.id === id);
    if (idx === -1) return null;
    this.data.users[idx] = { ...this.data.users[idx], ...updates };
    await this.persist();
    return this.data.users[idx];
  }

  // Products
  public getProducts(businessId: string) {
    return this.data.products.filter((p) => p.businessId === businessId);
  }

  public getProduct(businessId: string, productId: string) {
    return this.data.products.find((p) => p.businessId === businessId && p.id === productId);
  }

  public async createProduct(product: Product): Promise<Product> {
    this.data.products.push(product);
    await this.persist();
    return product;
  }

  public async updateProduct(businessId: string, productId: string, updates: Partial<Product>): Promise<Product | null> {
    const idx = this.data.products.findIndex((p) => p.businessId === businessId && p.id === productId);
    if (idx === -1) return null;
    this.data.products[idx] = {
      ...this.data.products[idx],
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    await this.persist();
    return this.data.products[idx];
  }

  public async deleteProduct(businessId: string, productId: string): Promise<boolean> {
    const idx = this.data.products.findIndex((p) => p.businessId === businessId && p.id === productId);
    if (idx === -1) return false;
    this.data.products.splice(idx, 1);
    await this.persist();
    return true;
  }

  // Customers
  public getCustomers(businessId: string) {
    return this.data.customers.filter((c) => c.businessId === businessId);
  }

  public getCustomerByPhone(businessId: string, phone: string) {
    return this.data.customers.find((c) => c.businessId === businessId && c.phone === phone);
  }

  public async recordCustomerTransaction(businessId: string, name: string, phone: string, amount: number): Promise<Customer | null> {
    if (!phone) return null;
    const now = new Date().toISOString();
    let customer = this.getCustomerByPhone(businessId, phone);
    if (customer) {
      customer.totalPurchases += 1;
      customer.totalSpent += amount;
      customer.lastPurchaseDate = now;
      customer.invoicesCount += 1;
      if (name && name.trim()) customer.name = name;
    } else {
      customer = {
        id: `cust_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        businessId,
        name: name || 'Valued Guest',
        phone,
        totalPurchases: 1,
        totalSpent: amount,
        lastPurchaseDate: now,
        invoicesCount: 1,
        createdAt: now,
      };
      this.data.customers.push(customer);
    }
    await this.persist();
    return customer;
  }

  // Invoices & Safe Concurrent Sequence
  public getInvoices(businessId: string) {
    return this.data.invoices
      .filter((inv) => inv.businessId === businessId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  public getInvoiceById(id: string) {
    return this.data.invoices.find((inv) => inv.id === id);
  }

  public async createInvoiceAtomic(
    businessId: string,
    invoiceData: Omit<Invoice, 'id' | 'invoiceNumber' | 'sequence' | 'createdAt' | 'updatedAt' | 'correctionHistory' | 'status'>
  ): Promise<Invoice> {
    const business = this.getBusiness(businessId);
    if (!business) {
      throw new Error(`Business not found: ${businessId}`);
    }

    const now = new Date().toISOString();
    const currentYear = new Date().getFullYear();

    // Atomic increment of invoice sequence
    const nextSeq = business.nextInvoiceSequence;
    business.nextInvoiceSequence += 1;
    business.updatedAt = now;

    const invoiceNumber = `${business.invoicePrefix}-${currentYear}-${String(nextSeq).padStart(6, '0')}`;
    const invoiceId = `inv_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

    // Stock deduction & movement logging
    for (const item of invoiceData.items) {
      const prod = this.getProduct(businessId, item.productId);
      if (prod) {
        const prev = prod.stock;
        prod.stock = Math.max(0, prod.stock - item.quantity);
        prod.updatedAt = now;

        this.data.inventoryMovements.push({
          id: `mov_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
          businessId,
          productId: prod.id,
          productName: prod.name,
          type: 'sold',
          quantityChange: -item.quantity,
          previousStock: prev,
          newStock: prod.stock,
          referenceId: invoiceId,
          notes: `Billed in invoice ${invoiceNumber}`,
          timestamp: now,
        });
      }
    }

    // Customer record update
    if (invoiceData.customerPhone) {
      await this.recordCustomerTransaction(
        businessId,
        invoiceData.customerName || '',
        invoiceData.customerPhone,
        invoiceData.grandTotal
      );
    }

    const fullInvoice: Invoice = {
      ...invoiceData,
      id: invoiceId,
      invoiceNumber,
      sequence: nextSeq,
      status: 'confirmed',
      correctionHistory: [],
      createdAt: now,
      updatedAt: now,
    };

    this.data.invoices.unshift(fullInvoice);

    // Audit log
    this.data.auditLogs.push({
      id: `log_${Date.now()}`,
      businessId,
      userId: invoiceData.createdByUserId,
      userName: invoiceData.createdByName,
      action: 'BILL_CREATED',
      details: `Generated invoice ${invoiceNumber} for amount ${business.currencySymbol}${invoiceData.grandTotal} (${invoiceData.paymentMethod})`,
      timestamp: now,
    });

    await this.persist();
    return fullInvoice;
  }

  // Bill Correction with full stock reversal and reapply
  public async correctInvoice(
    invoiceId: string,
    businessId: string,
    userId: string,
    userName: string,
    reason: string,
    newItems: InvoiceItem[],
    newPaymentMethod?: 'Cash' | 'UPI' | 'Card' | 'Other',
    newCustomerName?: string,
    newCustomerPhone?: string
  ): Promise<Invoice> {
    const invoice = this.data.invoices.find((inv) => inv.id === invoiceId && inv.businessId === businessId);
    if (!invoice) {
      throw new Error(`Invoice not found or access denied`);
    }

    const now = new Date().toISOString();

    // 1. Reverse previous stock deductions
    for (const oldItem of invoice.items) {
      const prod = this.getProduct(businessId, oldItem.productId);
      if (prod) {
        const prev = prod.stock;
        prod.stock += oldItem.quantity;
        prod.updatedAt = now;

        this.data.inventoryMovements.push({
          id: `mov_rev_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
          businessId,
          productId: prod.id,
          productName: prod.name,
          type: 'correction_reversal',
          quantityChange: oldItem.quantity,
          previousStock: prev,
          newStock: prod.stock,
          referenceId: invoiceId,
          notes: `Reversal for correction on ${invoice.invoiceNumber}: ${reason}`,
          timestamp: now,
        });
      }
    }

    // 2. Apply new stock deductions
    for (const newItem of newItems) {
      const prod = this.getProduct(businessId, newItem.productId);
      if (prod) {
        const prev = prod.stock;
        prod.stock = Math.max(0, prod.stock - newItem.quantity);
        prod.updatedAt = now;

        this.data.inventoryMovements.push({
          id: `mov_app_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
          businessId,
          productId: prod.id,
          productName: prod.name,
          type: 'correction_reapply',
          quantityChange: -newItem.quantity,
          previousStock: prev,
          newStock: prod.stock,
          referenceId: invoiceId,
          notes: `Re-applied corrected item for ${invoice.invoiceNumber}`,
          timestamp: now,
        });
      }
    }

    // Calculate new totals
    let subtotal = 0;
    let taxTotal = 0;
    let discountTotal = 0;

    for (const item of newItems) {
      subtotal += item.subtotal;
      taxTotal += item.taxAmount;
      discountTotal += item.discountAmount;
    }
    const grandTotal = subtotal + taxTotal - discountTotal;

    const previousGrandTotal = invoice.grandTotal;
    const previousItemsCopy = JSON.parse(JSON.stringify(invoice.items));

    invoice.items = newItems;
    invoice.subtotal = subtotal;
    invoice.taxTotal = taxTotal;
    invoice.discountTotal = discountTotal;
    invoice.grandTotal = grandTotal;
    if (newPaymentMethod) invoice.paymentMethod = newPaymentMethod;
    if (newCustomerName !== undefined) invoice.customerName = newCustomerName;
    if (newCustomerPhone !== undefined) invoice.customerPhone = newCustomerPhone;
    invoice.status = 'corrected';
    invoice.updatedAt = now;

    invoice.correctionHistory.push({
      correctedAt: now,
      correctedBy: userName,
      reason,
      previousGrandTotal,
      newGrandTotal: grandTotal,
      previousItems: previousItemsCopy,
      newItems: JSON.parse(JSON.stringify(newItems)),
    });

    // Audit log
    this.data.auditLogs.push({
      id: `log_corr_${Date.now()}`,
      businessId,
      userId,
      userName,
      action: 'BILL_CORRECTED',
      details: `Corrected ${invoice.invoiceNumber}. Amount changed from ${previousGrandTotal} to ${grandTotal}. Reason: ${reason}`,
      timestamp: now,
    });

    await this.persist();
    return invoice;
  }

  // Stock Adjustment directly from Inventory
  public async adjustStock(
    businessId: string,
    productId: string,
    changeQty: number,
    reason: string,
    userId: string,
    userName: string
  ): Promise<Product | null> {
    const prod = this.getProduct(businessId, productId);
    if (!prod) return null;

    const now = new Date().toISOString();
    const prev = prod.stock;
    const newStock = Math.max(0, prod.stock + changeQty);
    prod.stock = newStock;
    prod.updatedAt = now;

    this.data.inventoryMovements.push({
      id: `mov_adj_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      businessId,
      productId: prod.id,
      productName: prod.name,
      type: changeQty > 0 ? 'added' : 'adjustment',
      quantityChange: changeQty,
      previousStock: prev,
      newStock,
      notes: reason || 'Manual stock update',
      timestamp: now,
    });

    this.data.auditLogs.push({
      id: `log_stk_${Date.now()}`,
      businessId,
      userId,
      userName,
      action: 'STOCK_ADJUSTED',
      details: `Stock for ${prod.name} adjusted by ${changeQty > 0 ? '+' : ''}${changeQty} (${prev} -> ${newStock}). Reason: ${reason}`,
      timestamp: now,
    });

    await this.persist();
    return prod;
  }

  // Inventory Movements
  public getInventoryMovements(businessId: string) {
    return this.data.inventoryMovements
      .filter((m) => m.businessId === businessId)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  // Audit Logs
  public getAuditLogs(businessId?: string) {
    if (businessId) {
      return this.data.auditLogs
        .filter((l) => l.businessId === businessId)
        .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    }
    return this.data.auditLogs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  public async addAuditLog(log: Omit<AuditLog, 'id' | 'timestamp'>): Promise<AuditLog> {
    const fullLog: AuditLog = {
      ...log,
      id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
      timestamp: new Date().toISOString(),
    };
    this.data.auditLogs.push(fullLog);
    await this.persist();
    return fullLog;
  }

  // Super Admin Platform Aggregates
  public getPlatformMetrics() {
    const totalBusinesses = this.data.businesses.length;
    const activeBusinesses = this.data.businesses.filter((b) => b.active).length;
    const inactiveBusinesses = totalBusinesses - activeBusinesses;
    const totalUsers = this.data.users.length;
    const totalBills = this.data.invoices.length;
    const totalRevenue = this.data.invoices.reduce((acc, inv) => acc + inv.grandTotal, 0);

    const planDistribution = {
      Free: this.data.businesses.filter((b) => b.plan === 'Free').length,
      Pro: this.data.businesses.filter((b) => b.plan === 'Pro').length,
      Business: this.data.businesses.filter((b) => b.plan === 'Business').length,
      Enterprise: this.data.businesses.filter((b) => b.plan === 'Enterprise').length,
    };

    return {
      totalBusinesses,
      activeBusinesses,
      inactiveBusinesses,
      totalUsers,
      totalBills,
      totalRevenue,
      planDistribution,
    };
  }
}

export const db = new DatabaseStore();
