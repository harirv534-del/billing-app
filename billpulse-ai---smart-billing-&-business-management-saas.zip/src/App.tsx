import React, { useState, useEffect } from 'react';
import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';
import { ManualBilling } from './components/billing/ManualBilling';
import { AiPhotoBilling } from './components/billing/AiPhotoBilling';
import { InvoiceList } from './components/invoices/InvoiceList';
import { ProductManager } from './components/products/ProductManager';
import { InventoryManager } from './components/inventory/InventoryManager';
import { CustomerManager } from './components/customers/CustomerManager';
import { DailyReportView } from './components/reports/DailyReportView';
import { AnalyticsView } from './components/reports/AnalyticsView';
import { StaffManager } from './components/staff/StaffManager';
import { BusinessSettings } from './components/settings/BusinessSettings';
import { SuperAdminDashboard } from './components/admin/SuperAdminDashboard';
import { AuthModal } from './components/auth/AuthModal';
import { Business, User, Product, Invoice } from './types';
import { api } from './services/api';

export default function App() {
  const [currentBusiness, setCurrentBusiness] = useState<Business | null>(null);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [allBusinesses, setAllBusinesses] = useState<Business[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [activeTab, setActiveTab] = useState<string>('billing');
  const [isSuperAdminMode, setIsSuperAdminMode] = useState<boolean>(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [initialLoading, setInitialLoading] = useState<boolean>(true);

  // Initialize session and load tenant data
  const initializeApp = async () => {
    try {
      // Fetch current session
      const me = await api.getMe();
      if (me.user) setCurrentUser(me.user);
      if (me.business) setCurrentBusiness(me.business);

      // Fetch all businesses for multi-tenant switcher
      const adminBiz = await api.getAdminBusinesses().catch(() => []);
      if (adminBiz.length > 0) {
        setAllBusinesses(adminBiz);
        if (!me.business) {
          setCurrentBusiness(adminBiz[0]);
        }
      }

      // Fetch products for current tenant
      await refreshProducts();
    } catch (err) {
      console.error('Initialization error:', err);
    } finally {
      setInitialLoading(false);
    }
  };

  const refreshProducts = async () => {
    try {
      const prods = await api.getProducts();
      setProducts(prods);
    } catch (err) {
      console.error('Failed to load products:', err);
    }
  };

  useEffect(() => {
    initializeApp();
  }, []);

  // Switch Business Tenant
  const handleSwitchBusiness = async (bizId: string) => {
    const selected = allBusinesses.find((b) => b.id === bizId);
    if (!selected) return;

    api.setSession(selected.id, currentUser?.id || 'user_karthik_01', 'token_switched');
    setCurrentBusiness(selected);
    await refreshProducts();
  };

  // Auth success
  const handleAuthSuccess = async (user: User, business: Business | null) => {
    setCurrentUser(user);
    if (business) {
      setCurrentBusiness(business);
      setIsSuperAdminMode(false);
      setActiveTab('billing');
    } else if (user.role === 'super_admin') {
      setIsSuperAdminMode(true);
      setActiveTab('super_admin');
    }
    await refreshProducts();
  };

  const handleLogout = () => {
    api.clearSession();
    setCurrentUser(null);
    setIsSuperAdminMode(false);
    setIsAuthModalOpen(true);
  };

  const handleOpenSuperAdmin = () => {
    setIsSuperAdminMode(true);
    setActiveTab('super_admin');
  };

  const handleExitSuperAdmin = () => {
    setIsSuperAdminMode(false);
    setActiveTab('billing');
  };

  if (initialLoading) {
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center text-white">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center font-black text-xl shadow-xl shadow-blue-500/25 animate-pulse mb-4">
          BP
        </div>
        <div className="text-base font-extrabold tracking-tight">BillPulse AI</div>
        <p className="text-xs text-slate-400 mt-1">Starting POS Engine & Multitenant Workspace...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-900 flex flex-col font-sans">
      
      {/* Top Navigation */}
      <Navbar
        currentBusiness={currentBusiness}
        currentUser={currentUser}
        onSwitchBusiness={handleSwitchBusiness}
        onOpenSuperAdmin={handleOpenSuperAdmin}
        onOpenAuth={() => setIsAuthModalOpen(true)}
        onLogout={handleLogout}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        allBusinesses={allBusinesses}
      />

      {/* Main Layout Area */}
      <div className="flex grow">
        
        {/* Sidebar */}
        <Sidebar
          activeTab={activeTab}
          setActiveTab={(tab) => {
            if (tab === 'super_admin' || tab === 'admin_businesses' || tab === 'admin_subscriptions' || tab === 'admin_audit') {
              setIsSuperAdminMode(true);
            } else {
              setIsSuperAdminMode(false);
            }
            setActiveTab(tab);
          }}
          userRole={currentUser?.role}
          isSuperAdminPortal={isSuperAdminMode}
        />

        {/* Content View Container */}
        <main className="flex-1 p-3 sm:p-6 pb-20 md:pb-8 overflow-y-auto">
          {isSuperAdminMode || activeTab === 'super_admin' ? (
            <SuperAdminDashboard onExitSuperAdmin={handleExitSuperAdmin} />
          ) : !currentBusiness ? (
            <div className="py-20 text-center">
              <p className="text-sm font-bold text-slate-700">No active business account found.</p>
              <button
                onClick={() => setIsAuthModalOpen(true)}
                className="mt-3 px-4 py-2 rounded-xl bg-blue-600 text-white font-bold text-xs"
              >
                Sign In / Select Business
              </button>
            </div>
          ) : (
            <>
              {activeTab === 'billing' && (
                <ManualBilling
                  business={currentBusiness}
                  products={products}
                  onBillConfirmed={() => refreshProducts()}
                  onSwitchToAiBilling={() => setActiveTab('ai_billing')}
                />
              )}

              {activeTab === 'ai_billing' && (
                <AiPhotoBilling
                  business={currentBusiness}
                  products={products}
                  onBillConfirmed={() => refreshProducts()}
                />
              )}

              {activeTab === 'invoices' && (
                <InvoiceList
                  business={currentBusiness}
                  products={products}
                  onInvoiceUpdated={() => refreshProducts()}
                />
              )}

              {activeTab === 'products' && (
                <ProductManager
                  business={currentBusiness}
                  products={products}
                  onProductsUpdated={() => refreshProducts()}
                />
              )}

              {activeTab === 'inventory' && (
                <InventoryManager
                  business={currentBusiness}
                  onStockUpdated={() => refreshProducts()}
                />
              )}

              {activeTab === 'customers' && (
                <CustomerManager business={currentBusiness} />
              )}

              {activeTab === 'reports' && (
                <DailyReportView business={currentBusiness} />
              )}

              {activeTab === 'analytics' && (
                <AnalyticsView business={currentBusiness} />
              )}

              {activeTab === 'staff' && (
                <StaffManager
                  business={currentBusiness}
                  currentUser={currentUser}
                />
              )}

              {activeTab === 'settings' && (
                <BusinessSettings
                  business={currentBusiness}
                  onBusinessUpdated={(updated) => {
                    setCurrentBusiness(updated);
                    setAllBusinesses((prev) =>
                      prev.map((b) => (b.id === updated.id ? updated : b))
                    );
                  }}
                />
              )}
            </>
          )}
        </main>
      </div>

      {/* Auth Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onAuthSuccess={handleAuthSuccess}
      />
    </div>
  );
}
