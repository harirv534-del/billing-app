import React, { useState, useEffect } from 'react';
import {
  Calendar,
  DollarSign,
  Receipt,
  ShoppingBag,
  TrendingUp,
  Download,
  Share2,
  FileText,
  CreditCard,
  Banknote,
  Smartphone,
  RefreshCw,
} from 'lucide-react';
import { Business, Invoice } from '../../types';
import { api } from '../../services/api';
import { downloadInvoicePDF } from '../../utils/pdfGenerator';
import { shareViaWhatsApp } from '../../utils/whatsappShare';

interface DailyReportProps {
  business: Business;
}

export const DailyReportView: React.FC<DailyReportProps> = ({ business }) => {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().slice(0, 10));
  const [loading, setLoading] = useState(true);
  const [report, setReport] = useState<{
    date: string;
    totalBills: number;
    totalRevenue: number;
    totalItemsSold: number;
    averageBillValue: number;
    topProduct: { name: string; qty: number; revenue: number } | null;
    topProductsList: Array<{ name: string; qty: number; revenue: number }>;
    paymentMethodsBreakdown: Record<string, number>;
    invoices: Invoice[];
  } | null>(null);

  const loadReport = async () => {
    setLoading(true);
    try {
      const data = await api.getDailyReport(selectedDate);
      setReport(data);
    } catch (err) {
      console.error('Failed to load daily report:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadReport();
  }, [selectedDate]);

  return (
    <div className="max-w-7xl mx-auto space-y-5">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
        <div>
          <h1 className="text-lg font-black text-slate-900 flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-600" />
            <span>Daily Sales & EOD Performance Report</span>
          </h1>
          <p className="text-xs text-slate-500">
            Real-time daily transaction summary, top items sold, and payment collection breakup
          </p>
        </div>

        {/* Date Selector */}
        <div className="flex items-center gap-2">
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="px-3 py-1.5 text-xs font-bold rounded-xl border border-slate-300 bg-white focus:ring-2 focus:ring-blue-500"
          />
          <button
            onClick={loadReport}
            className="p-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-600"
            title="Refresh Report"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {loading ? (
        <div className="py-20 text-center text-slate-400">
          <div className="w-8 h-8 rounded-full border-2 border-blue-600 border-t-transparent animate-spin mx-auto mb-2"></div>
          <p className="text-xs font-semibold">Compiling day's transactions...</p>
        </div>
      ) : report ? (
        <>
          {/* Key Metrics Grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
            <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Total Revenue
              </span>
              <div className="text-2xl font-black text-blue-600 mt-1">
                {business.currencySymbol}{report.totalRevenue.toLocaleString()}
              </div>
              <p className="text-[11px] text-slate-500 mt-0.5">{report.totalBills} bills generated</p>
            </div>

            <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Items Sold
              </span>
              <div className="text-2xl font-black text-slate-900 mt-1">
                {report.totalItemsSold} <span className="text-xs text-slate-500 font-normal">units</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-0.5">Physical items dispensed</p>
            </div>

            <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Average Bill Value
              </span>
              <div className="text-2xl font-black text-slate-900 mt-1">
                {business.currencySymbol}{report.averageBillValue}
              </div>
              <p className="text-[11px] text-slate-500 mt-0.5">Per customer ticket</p>
            </div>

            <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Top Selling Product
              </span>
              <div className="text-lg font-black text-slate-900 mt-1 truncate">
                {report.topProduct ? report.topProduct.name : 'N/A'}
              </div>
              <p className="text-[11px] text-emerald-600 font-semibold mt-0.5">
                {report.topProduct ? `${report.topProduct.qty} sold (${business.currencySymbol}${report.topProduct.revenue})` : 'No sales today'}
              </p>
            </div>
          </div>

          {/* Payment Method Split & Top Sellers Breakdown */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            
            {/* Payment Modes */}
            <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs space-y-3">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Payment Collection Breakup
              </h3>
              <div className="grid grid-cols-3 gap-2.5">
                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80 text-center">
                  <Smartphone className="w-5 h-5 text-indigo-600 mx-auto mb-1" />
                  <span className="text-[11px] text-slate-500 font-medium block">UPI / QR</span>
                  <span className="text-sm font-black text-slate-900">
                    {business.currencySymbol}{report.paymentMethodsBreakdown.UPI || 0}
                  </span>
                </div>

                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80 text-center">
                  <Banknote className="w-5 h-5 text-emerald-600 mx-auto mb-1" />
                  <span className="text-[11px] text-slate-500 font-medium block">Cash</span>
                  <span className="text-sm font-black text-slate-900">
                    {business.currencySymbol}{report.paymentMethodsBreakdown.Cash || 0}
                  </span>
                </div>

                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80 text-center">
                  <CreditCard className="w-5 h-5 text-blue-600 mx-auto mb-1" />
                  <span className="text-[11px] text-slate-500 font-medium block">Card / POS</span>
                  <span className="text-sm font-black text-slate-900">
                    {business.currencySymbol}{report.paymentMethodsBreakdown.Card || 0}
                  </span>
                </div>
              </div>
            </div>

            {/* Top Products Ranking */}
            <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs space-y-3">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Top Products Dispensed Today
              </h3>
              <div className="space-y-2 max-h-[160px] overflow-y-auto pr-1">
                {report.topProductsList.length === 0 ? (
                  <p className="text-xs text-slate-400 py-4 text-center">No products billed on this date</p>
                ) : (
                  report.topProductsList.map((item, idx) => (
                    <div key={idx} className="flex justify-between items-center text-xs py-1 border-b border-slate-100 last:border-0">
                      <span className="font-bold text-slate-900 truncate pr-2">
                        {idx + 1}. {item.name}
                      </span>
                      <span className="font-semibold text-slate-700 shrink-0">
                        {item.qty} units • <strong className="text-blue-600">{business.currencySymbol}{item.revenue}</strong>
                      </span>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Today's Transactions List */}
          <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Detailed Bills for {selectedDate} ({report.invoices.length})
              </h3>
            </div>

            {report.invoices.length === 0 ? (
              <div className="py-12 text-center text-xs text-slate-400">
                No invoices recorded on {selectedDate}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider text-[10px] border-b border-slate-200">
                    <tr>
                      <th className="py-2.5 px-4">Invoice #</th>
                      <th className="py-2.5 px-4">Time</th>
                      <th className="py-2.5 px-4">Customer</th>
                      <th className="py-2.5 px-4">Items Summary</th>
                      <th className="py-2.5 px-4">Payment</th>
                      <th className="py-2.5 px-4 text-right">Amount</th>
                      <th className="py-2.5 px-4 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                    {report.invoices.map((inv) => (
                      <tr key={inv.id} className="hover:bg-slate-50">
                        <td className="py-2.5 px-4 font-mono font-bold text-slate-900">
                          {inv.invoiceNumber}
                        </td>
                        <td className="py-2.5 px-4 text-slate-500">
                          {new Date(inv.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </td>
                        <td className="py-2.5 px-4">{inv.customerName || 'Walk-in'}</td>
                        <td className="py-2.5 px-4 text-slate-500 truncate max-w-xs">
                          {inv.items.map((i) => `${i.name} (x${i.quantity})`).join(', ')}
                        </td>
                        <td className="py-2.5 px-4">{inv.paymentMethod}</td>
                        <td className="py-2.5 px-4 text-right font-black text-slate-900">
                          {business.currencySymbol}{inv.grandTotal}
                        </td>
                        <td className="py-2.5 px-4 text-right">
                          <button
                            onClick={() => downloadInvoicePDF(inv, business)}
                            className="text-xs text-blue-600 font-semibold hover:underline"
                          >
                            PDF
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      ) : null}
    </div>
  );
};
