import React, { useState, useEffect } from 'react';
import {
  BarChart3,
  TrendingUp,
  PieChart,
  ShoppingBag,
  Layers,
  Calendar,
  DollarSign,
  Receipt,
  RefreshCw,
} from 'lucide-react';
import { Business } from '../../types';
import { api } from '../../services/api';

interface AnalyticsViewProps {
  business: Business;
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({ business }) => {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<{
    dailyTrend: Array<{ date: string; revenue: number; bills: number }>;
    categoryBreakdown: Record<string, number>;
    topSellingProducts: Array<{ name: string; category: string; quantity: number; revenue: number }>;
    totalInvoicesRecorded: number;
    overallGrossVolume: number;
  } | null>(null);

  const loadAnalytics = async () => {
    setLoading(true);
    try {
      const res = await api.getAnalytics();
      setData(res);
    } catch (err) {
      console.error('Failed to load analytics:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAnalytics();
  }, []);

  // Compute maximum revenue day for chart scaling
  const maxRevenueDay = data?.dailyTrend
    ? Math.max(...data.dailyTrend.map((d) => d.revenue), 100)
    : 100;

  return (
    <div className="max-w-7xl mx-auto space-y-5">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
        <div>
          <h1 className="text-lg font-black text-slate-900 flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-blue-600" />
            <span>30-Day Sales Analytics & Performance Trajectory</span>
          </h1>
          <p className="text-xs text-slate-500">
            Visual trends, category market share, and revenue momentum for {business.name}
          </p>
        </div>

        <button
          onClick={loadAnalytics}
          className="p-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs font-semibold flex items-center gap-1.5 self-start sm:self-auto"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Refresh Analytics</span>
        </button>
      </div>

      {loading ? (
        <div className="py-20 text-center text-slate-400">
          <div className="w-8 h-8 rounded-full border-2 border-blue-600 border-t-transparent animate-spin mx-auto mb-2"></div>
          <p className="text-xs font-semibold">Generating visual charts...</p>
        </div>
      ) : data ? (
        <>
          {/* Lifetime Platform Totals for this tenant */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-5 rounded-3xl bg-gradient-to-br from-blue-600 to-indigo-700 text-white shadow-md">
              <span className="text-[11px] font-bold text-blue-200 uppercase tracking-wider block">
                Total Gross Volume
              </span>
              <div className="text-3xl font-black mt-1">
                {business.currencySymbol}{data.overallGrossVolume.toLocaleString()}
              </div>
              <p className="text-xs text-blue-100 mt-1">From {data.totalInvoicesRecorded} confirmed bills</p>
            </div>

            <div className="p-5 rounded-3xl bg-white border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                30-Day Total Invoices
              </span>
              <div className="text-3xl font-black text-slate-900 mt-1">
                {data.dailyTrend.reduce((a, b) => a + b.bills, 0)}
              </div>
              <p className="text-xs text-slate-500 mt-1">Unique customer receipts</p>
            </div>

            <div className="p-5 rounded-3xl bg-white border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Top Revenue Category
              </span>
              <div className="text-2xl font-black text-slate-900 mt-1 truncate">
                {Object.keys(data.categoryBreakdown)[0] || 'General'}
              </div>
              <p className="text-xs text-emerald-600 font-semibold mt-1">
                {business.currencySymbol}{Object.values(data.categoryBreakdown)[0]?.toLocaleString() || 0} collected
              </p>
            </div>
          </div>

          {/* 30-Day Daily Sales Visual Bar Chart */}
          <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-extrabold text-slate-900">
                  Daily Revenue Trajectory (Last 30 Days)
                </h3>
                <p className="text-xs text-slate-500">Day-by-day bill collection comparison</p>
              </div>
              <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2.5 py-1 rounded-lg">
                Max Day: {business.currencySymbol}{maxRevenueDay}
              </span>
            </div>

            {/* SVG Responsive Bar Chart */}
            <div className="h-60 w-full flex items-end gap-1.5 pt-6 pb-2 px-1 border-b border-slate-200 overflow-x-auto">
              {data.dailyTrend.map((day, idx) => {
                const heightPercent = maxRevenueDay > 0 ? (day.revenue / maxRevenueDay) * 100 : 0;
                const isToday = idx === data.dailyTrend.length - 1;

                return (
                  <div
                    key={day.date}
                    className="flex-1 min-w-[20px] flex flex-col items-center gap-1 group relative h-full justify-end"
                  >
                    {/* Tooltip */}
                    <div className="absolute -top-10 scale-0 group-hover:scale-100 transition-transform bg-slate-900 text-white text-[10px] font-bold px-2 py-1 rounded-md shadow-lg pointer-events-none whitespace-nowrap z-20">
                      {day.date}: {business.currencySymbol}{day.revenue} ({day.bills} bills)
                    </div>

                    {/* Bar */}
                    <div
                      style={{ height: `${Math.max(6, heightPercent)}%` }}
                      className={`w-full rounded-t-md transition-all ${
                        isToday
                          ? 'bg-blue-600 group-hover:bg-blue-700'
                          : day.revenue > 0
                          ? 'bg-indigo-300 group-hover:bg-blue-500'
                          : 'bg-slate-100'
                      }`}
                    ></div>

                    {/* Label every 5 days */}
                    {idx % 5 === 0 && (
                      <span className="text-[9px] text-slate-400 font-mono rotate-45 origin-left mt-2">
                        {day.date.slice(5)}
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Product Rankings and Category Share */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            
            {/* Top Selling Products */}
            <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs space-y-3">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <ShoppingBag className="w-4 h-4 text-blue-600" />
                <span>Product Revenue Champions</span>
              </h3>

              <div className="space-y-2.5">
                {data.topSellingProducts.map((p, idx) => (
                  <div key={idx} className="flex justify-between items-center text-xs py-1.5 border-b border-slate-100 last:border-0">
                    <div>
                      <span className="font-bold text-slate-900">
                        {idx + 1}. {p.name}
                      </span>
                      <span className="block text-[11px] text-slate-400">{p.category}</span>
                    </div>

                    <div className="text-right">
                      <span className="font-black text-slate-900 block">
                        {business.currencySymbol}{p.revenue.toLocaleString()}
                      </span>
                      <span className="text-[10px] text-slate-500">{p.quantity} units sold</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Category Breakdown */}
            <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs space-y-3">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <PieChart className="w-4 h-4 text-indigo-600" />
                <span>Revenue Share by Category</span>
              </h3>

              <div className="space-y-2.5">
                {Object.entries(data.categoryBreakdown).map(([cat, rev], idx) => {
                  const pct = data.overallGrossVolume > 0 ? Math.round((rev / data.overallGrossVolume) * 100) : 0;
                  return (
                    <div key={cat} className="space-y-1">
                      <div className="flex justify-between text-xs font-bold">
                        <span className="text-slate-800">{cat}</span>
                        <span className="text-slate-900">{business.currencySymbol}{rev.toLocaleString()} ({pct}%)</span>
                      </div>
                      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                        <div
                          style={{ width: `${pct}%` }}
                          className="bg-blue-600 h-full rounded-full"
                        ></div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
};
