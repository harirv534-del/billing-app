import React, { useState, useEffect } from 'react';
import {
  UserCheck,
  Shield,
  Plus,
  Mail,
  Phone,
  CheckCircle,
  X,
  Lock,
} from 'lucide-react';
import { User, Business, Role } from '../../types';
import { api } from '../../services/api';

interface StaffManagerProps {
  business: Business;
  currentUser: User | null;
}

export const StaffManager: React.FC<StaffManagerProps> = ({
  business,
  currentUser,
}) => {
  const [staff, setStaff] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    role: 'cashier' as Role,
    password: '',
  });
  const [isSaving, setIsSaving] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const loadStaff = async () => {
    setLoading(true);
    try {
      const data = await api.getStaff();
      setStaff(data);
    } catch (err) {
      console.error('Failed to load staff:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadStaff();
  }, []);

  const handleAddStaff = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email) return;

    setIsSaving(true);
    setErrorMsg(null);

    try {
      await api.addStaff(formData);
      setIsModalOpen(false);
      setFormData({
        name: '',
        email: '',
        phone: '',
        role: 'cashier',
        password: '',
      });
      loadStaff();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to add staff member');
    } finally {
      setIsSaving(false);
    }
  };

  const isOwner = currentUser?.role === 'owner' || currentUser?.role === 'manager';

  return (
    <div className="max-w-7xl mx-auto space-y-5">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
        <div>
          <h1 className="text-lg font-black text-slate-900 flex items-center gap-2">
            <UserCheck className="w-5 h-5 text-blue-600" />
            <span>Staff Members & Role Permissions (RBAC)</span>
          </h1>
          <p className="text-xs text-slate-500">
            Multi-user cashier and manager accounts isolated to {business.name}
          </p>
        </div>

        {isOwner && (
          <button
            onClick={() => setIsModalOpen(true)}
            className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-2 shadow-xs transition self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Add Staff Account</span>
          </button>
        )}
      </div>

      {/* Permissions Matrix Overview */}
      <div className="p-4 rounded-3xl bg-slate-50 border border-slate-200 text-xs">
        <h3 className="font-bold text-slate-800 mb-2">Role Permissions Matrix:</h3>
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
          <div className="p-3 rounded-2xl bg-white border border-slate-200">
            <span className="font-black text-blue-700 uppercase tracking-wider text-[11px] block">
              Owner
            </span>
            <p className="text-[11px] text-slate-500 mt-1">Full control over billing, products, staff, profile, pricing & deletion.</p>
          </div>
          <div className="p-3 rounded-2xl bg-white border border-slate-200">
            <span className="font-black text-indigo-700 uppercase tracking-wider text-[11px] block">
              Manager
            </span>
            <p className="text-[11px] text-slate-500 mt-1">Can generate bills, adjust inventory, view daily sales reports and manage products.</p>
          </div>
          <div className="p-3 rounded-2xl bg-white border border-slate-200">
            <span className="font-black text-emerald-700 uppercase tracking-wider text-[11px] block">
              Cashier
            </span>
            <p className="text-[11px] text-slate-500 mt-1">High-speed point of sale, generate receipts, AI photo scans, share on WhatsApp.</p>
          </div>
          <div className="p-3 rounded-2xl bg-white border border-slate-200">
            <span className="font-black text-slate-700 uppercase tracking-wider text-[11px] block">
              Staff
            </span>
            <p className="text-[11px] text-slate-500 mt-1">Inventory stock counts, order fulfillment and product viewing.</p>
          </div>
        </div>
      </div>

      {/* Staff Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider text-[10px] border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Staff Member</th>
                <th className="py-3 px-4">Email</th>
                <th className="py-3 px-4">Phone</th>
                <th className="py-3 px-4 text-center">Assigned Role</th>
                <th className="py-3 px-4 text-center">Account Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {staff.map((u) => (
                <tr key={u.id} className="hover:bg-slate-50/80 transition">
                  <td className="py-3 px-4 font-bold text-slate-900">{u.name}</td>
                  <td className="py-3 px-4 text-slate-600 font-mono text-[11px]">{u.email}</td>
                  <td className="py-3 px-4 text-slate-500">{u.phone || 'N/A'}</td>
                  <td className="py-3 px-4 text-center">
                    <span className="capitalize px-2.5 py-1 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800">
                      {u.role}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span className="inline-flex items-center gap-1 text-emerald-700 text-[11px] font-bold">
                      <CheckCircle className="w-3.5 h-3.5" />
                      Active
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Staff Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-md rounded-3xl bg-white p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-extrabold text-slate-900">Add Staff Account</h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 rounded-full text-slate-400 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {errorMsg && (
              <div className="p-3 rounded-xl bg-red-50 text-red-700 text-xs font-semibold">
                {errorMsg}
              </div>
            )}

            <form onSubmit={handleAddStaff} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Ramesh Kumar"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Email</label>
                <input
                  type="email"
                  required
                  placeholder="e.g. ramesh@store.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Phone Number</label>
                <input
                  type="tel"
                  placeholder="e.g. 9876543211"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Role & Permissions</label>
                <select
                  value={formData.role}
                  onChange={(e) => setFormData({ ...formData, role: e.target.value as Role })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                >
                  <option value="cashier">Cashier (Point-of-Sale Billing)</option>
                  <option value="manager">Manager (Reports, Inventory, Catalog)</option>
                  <option value="staff">Staff (Stock & View)</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Password</label>
                <input
                  type="password"
                  placeholder="Temporary login password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                />
              </div>

              <div className="pt-2 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl font-bold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold shadow-xs transition"
                >
                  {isSaving ? 'Creating...' : 'Create Account'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
