import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Building,
  Users,
  Receipt,
  DollarSign,
  Layers,
  Power,
  CreditCard,
  History,
  RefreshCw,
  Search,
  CheckCircle,
  AlertTriangle,
  Lock,
} from 'lucide-react';
import { Business } from '../../types';
import { api } from '../../services/api';

interface SuperAdminDashboardProps {
  onExitSuperAdmin: () => void;
}

export const SuperAdminDashboard: React.FC<SuperAdminDashboardProps> = ({
  onExitSuperAdmin,
}) => {
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(
    localStorage.getItem('billpulse_is_admin') === 'true'
  );
  const [passwordInput, setPasswordInput] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);

  const [metrics, setMetrics] = useState<any>(null);
  const [businesses, setBusinesses] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    try {
      await api.adminLogin(passwordInput);
      setIsAdminLoggedIn(true);
      localStorage.setItem('billpulse_is_admin', 'true');
      loadAdminData();
    } catch (err: any) {
      setLoginError(err.message || 'Invalid Super Admin password (Try "SuperAdmin2026!" or "admin123")');
    }
  };

  const loadAdminData = async () => {
    setLoading(true);
    try {
      const [met, biz] = await Promise.all([
        api.getAdminMetrics(),
        api.getAdminBusinesses(),
      ]);
      setMetrics(met);
      setBusinesses(biz);
    } catch (err) {
      console.error('Failed to load admin data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAdminLoggedIn) {
      loadAdminData();
    }
  }, [isAdminLoggedIn]);

  const toggleBusiness = async (bizId: string) => {
    try {
      await api.toggleBusinessStatus(bizId);
      loadAdminData();
    } catch (err) {
      console.error('Failed to toggle status:', err);
    }
  };

  const changePlan = async (bizId: string, plan: string) => {
    try {
      await api.updateBusinessPlan(bizId, plan);
      loadAdminData();
    } catch (err) {
      console.error('Failed to change plan:', err);
    }
  };

  const handleAdminLogout = () => {
    localStorage.removeItem('billpulse_is_admin');
    setIsAdminLoggedIn(false);
    onExitSuperAdmin();
  };

  // If not logged into Super Admin portal, show password prompt
  if (!isAdminLoggedIn) {
    return (
      <div className="max-w-md mx-auto my-12 bg-white p-8 rounded-3xl border border-slate-200 shadow-xl space-y-5 animate-in fade-in">
        <div className="text-center space-y-2">
          <div className="w-14 h-14 rounded-2xl bg-slate-900 text-amber-400 mx-auto flex items-center justify-center shadow-lg">
            <ShieldCheck className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-black text-slate-900">Super Admin SaaS Control</h2>
          <p className="text-xs text-slate-500">
            Secure administrative platform portal. Manage all business tenants, subscriptions, and platform telemetry.
          </p>
        </div>

        {loginError && (
          <div className="p-3 rounded-xl bg-red-50 text-red-700 text-xs font-semibold">
            {loginError}
          </div>
        )}

        <form onSubmit={handleAdminLogin} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 mb-1">Super Admin Password</label>
            <input
              type="password"
              placeholder="Enter master admin password"
              value={passwordInput}
              onChange={(e) => setPasswordInput(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-slate-900 focus:outline-hidden"
            />
            <span className="text-[10px] text-slate-400 mt-1 block">
              Default password: <code className="font-mono text-slate-600">SuperAdmin2026!</code> or <code className="font-mono text-slate-600">admin123</code>
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onExitSuperAdmin}
              className="flex-1 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-700 hover:bg-slate-50 transition"
            >
              Back to Store
            </button>
            <button
              type="submit"
              className="flex-1 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold transition shadow-md"
            >
              Sign In as Super Admin
            </button>
          </div>
        </form>
      </div>
    );
  }

  const filteredBusinesses = businesses.filter((b) => {
    const q = searchQuery.toLowerCase();
    return b.name.toLowerCase().includes(q) || b.ownerName.toLowerCase().includes(q) || b.email.toLowerCase().includes(q);
  });

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      
      {/* Super Admin Top Control Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 text-white p-6 rounded-3xl shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
            <ShieldCheck className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-black tracking-tight">Super Admin SaaS Control Plane</h1>
              <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-amber-400 text-slate-950 uppercase">
                Platform Root
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Cross-tenant monitoring, account activations, subscription management and platform health
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={loadAdminData}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh Metrics</span>
          </button>

          <button
            onClick={handleAdminLogout}
            className="px-3.5 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold transition"
          >
            Exit Admin
          </button>
        </div>
      </div>

      {loading && !metrics ? (
        <div className="py-20 text-center text-slate-400">Loading master platform data...</div>
      ) : metrics ? (
        <>
          {/* Master Platform Metric Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-3.5">
            <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Total Businesses
              </span>
              <div className="text-2xl font-black text-slate-900 mt-1">{metrics.totalBusinesses}</div>
              <p className="text-[11px] text-emerald-600 font-semibold mt-0.5">
                {metrics.activeBusinesses} active • {metrics.inactiveBusinesses} paused
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Platform Users
              </span>
              <div className="text-2xl font-black text-slate-900 mt-1">{metrics.totalUsers}</div>
              <p className="text-[11px] text-slate-500 mt-0.5">Owners, managers & cashiers</p>
            </div>

            <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Total Bills Generated
              </span>
              <div className="text-2xl font-black text-slate-900 mt-1">{metrics.totalBills}</div>
              <p className="text-[11px] text-blue-600 font-semibold mt-0.5">All tenants combined</p>
            </div>

            <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Platform Gross Volume
              </span>
              <div className="text-2xl font-black text-blue-600 mt-1">
                ₹{metrics.totalRevenue.toLocaleString()}
              </div>
              <p className="text-[11px] text-slate-500 mt-0.5">Processed invoices total</p>
            </div>

            <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs col-span-2 lg:col-span-1">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Plan Distribution
              </span>
              <div className="text-xs font-bold text-slate-700 mt-2 space-y-1">
                <div>Free: <span className="text-blue-600">{metrics.planDistribution.Free}</span></div>
                <div>Pro: <span className="text-indigo-600">{metrics.planDistribution.Pro}</span></div>
                <div>Business: <span className="text-emerald-600">{metrics.planDistribution.Business}</span></div>
              </div>
            </div>
          </div>

          {/* Business Tenant Management Table */}
          <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden space-y-3">
            <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-extrabold text-slate-900">
                  Registered Business Tenants
                </h3>
                <p className="text-xs text-slate-500">
                  Inspect tenant isolation, activate/deactivate accounts, and update subscription plan tier
                </p>
              </div>

              <div className="relative w-full sm:w-64">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Filter businesses..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider text-[10px] border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-4">Business Tenant</th>
                    <th className="py-3 px-4">Owner & Contact</th>
                    <th className="py-3 px-4">Type & Location</th>
                    <th className="py-3 px-4 text-center">Plan Tier</th>
                    <th className="py-3 px-4 text-right">Bills / Volume</th>
                    <th className="py-3 px-4 text-center">Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                  {filteredBusinesses.map((b) => (
                    <tr key={b.id} className="hover:bg-slate-50/80 transition">
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-900">{b.name}</div>
                        <div className="font-mono text-[10px] text-slate-400">ID: {b.id}</div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-800">{b.ownerName}</div>
                        <div className="text-[11px] text-slate-400">{b.email}</div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="text-slate-800">{b.businessType}</div>
                        <div className="text-[11px] text-slate-400">{b.city || 'India'}</div>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <select
                          value={b.plan}
                          onChange={(e) => changePlan(b.id, e.target.value)}
                          className="px-2 py-1 rounded-lg border border-slate-300 text-xs font-bold text-slate-800 bg-white"
                        >
                          <option value="Free">Free</option>
                          <option value="Pro">Pro</option>
                          <option value="Business">Business</option>
                          <option value="Enterprise">Enterprise</option>
                        </select>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="font-bold text-slate-900">{b.billCount || 0} bills</div>
                        <div className="text-[11px] text-blue-600 font-semibold">
                          ₹{(b.totalVolume || 0).toLocaleString()}
                        </div>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                            b.active
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-red-100 text-red-800'
                          }`}
                        >
                          {b.active ? 'Active' : 'Inactive'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={() => toggleBusiness(b.id)}
                          className={`px-2.5 py-1 rounded-lg text-xs font-bold transition ${
                            b.active
                              ? 'bg-red-50 text-red-700 hover:bg-red-100'
                              : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                          }`}
                        >
                          {b.active ? 'Deactivate' : 'Activate'}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* System Audit Logs Stream */}
          {metrics.recentAudit && (
            <div className="bg-white rounded-3xl border border-slate-200 shadow-xs p-5 space-y-3">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-2">
                <History className="w-4 h-4 text-slate-600" />
                <span>Global System Audit Logs (Last 20 Actions)</span>
              </h3>

              <div className="space-y-2 max-h-[240px] overflow-y-auto pr-1 text-xs">
                {metrics.recentAudit.map((log: any) => (
                  <div key={log.id} className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-between">
                    <div>
                      <span className="font-bold text-slate-900">{log.action}</span>
                      <span className="text-slate-600 block text-[11px] mt-0.5">{log.details}</span>
                    </div>
                    <div className="text-right text-[11px] text-slate-400 shrink-0">
                      <div>{log.userName}</div>
                      <div>{new Date(log.timestamp).toLocaleTimeString()}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      ) : null}
    </div>
  );
};
