import React, { useState } from 'react';
import {
  X,
  Store,
  User,
  Phone,
  Mail,
  Lock,
  ArrowRight,
  ShieldCheck,
  CheckCircle,
} from 'lucide-react';
import { api } from '../../services/api';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAuthSuccess: (user: any, business: any) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onAuthSuccess,
}) => {
  const [isRegister, setIsRegister] = useState(false);
  const [emailOrPhone, setEmailOrPhone] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Registration Fields
  const [regData, setRegData] = useState({
    businessName: '',
    ownerName: '',
    email: '',
    phone: '',
    password: '',
    businessType: 'Cafe / Restaurant',
    city: 'Madurai',
    currency: 'INR',
    invoicePrefix: 'CAFE',
  });

  if (!isOpen) return null;

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailOrPhone) return;

    setLoading(true);
    setErrorMsg(null);

    try {
      const res = await api.login(emailOrPhone, password);
      onAuthSuccess(res.user, res.business);
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Login failed. Please check credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!regData.businessName || !regData.ownerName || !regData.email) return;

    setLoading(true);
    setErrorMsg(null);

    try {
      const res = await api.register(regData);
      onAuthSuccess(res.user, res.business);
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  // Quick 1-click Demo credentials
  const demoLogin = async (email: string) => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const res = await api.login(email);
      onAuthSuccess(res.user, res.business);
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Demo login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
      <div className="w-full max-w-lg rounded-3xl bg-white p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto animate-in zoom-in-95">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-lg font-black text-slate-900">
              {isRegister ? 'Register Your Business' : 'Business Owner & Staff Login'}
            </h2>
            <p className="text-xs text-slate-500">
              Multi-tenant isolated billing & stock workspace
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-xl bg-red-50 text-red-700 text-xs font-semibold">
            {errorMsg}
          </div>
        )}

        {/* 1-Click Fast Demo Switcher */}
        {!isRegister && (
          <div className="p-3 rounded-2xl bg-blue-50/70 border border-blue-100 text-xs space-y-2">
            <span className="font-bold text-blue-900 block text-[11px] uppercase tracking-wider">
              1-Click Demo Accounts:
            </span>
            <div className="grid grid-cols-2 gap-1.5">
              <button
                type="button"
                onClick={() => demoLogin('karthik@maduraispice.com')}
                className="p-2 rounded-xl bg-white hover:bg-blue-100/60 border border-blue-200 text-left transition"
              >
                <div className="font-bold text-slate-900">Madurai Spice Cafe</div>
                <div className="text-[10px] text-slate-500">Karthik Raja (Owner)</div>
              </button>

              <button
                type="button"
                onClick={() => demoLogin('priya@cityhypermarket.com')}
                className="p-2 rounded-xl bg-white hover:bg-blue-100/60 border border-blue-200 text-left transition"
              >
                <div className="font-bold text-slate-900">City SuperMarket</div>
                <div className="text-[10px] text-slate-500">Priya Sharma (Retail)</div>
              </button>

              <button
                type="button"
                onClick={() => demoLogin('ramesh@maduraispice.com')}
                className="p-2 rounded-xl bg-white hover:bg-blue-100/60 border border-blue-200 text-left transition"
              >
                <div className="font-bold text-slate-900">Cafe Cashier Desk</div>
                <div className="text-[10px] text-slate-500">Ramesh Kumar (Cashier)</div>
              </button>

              <button
                type="button"
                onClick={() => demoLogin('admin@billpulse.io')}
                className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-left transition"
              >
                <div className="font-bold text-amber-400">Super Admin Portal</div>
                <div className="text-[10px] text-slate-300">SaaS Platform Owner</div>
              </button>
            </div>
          </div>
        )}

        {!isRegister ? (
          /* Login Form */
          <form onSubmit={handleLogin} className="space-y-3.5 text-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Email or Mobile Number</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  required
                  placeholder="e.g. karthik@maduraispice.com or 9876543210"
                  value={emailOrPhone}
                  onChange={(e) => setEmailOrPhone(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Password</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="password"
                  placeholder="Enter password (or demo preset)"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md active:scale-98 transition flex items-center justify-center gap-1.5"
            >
              <span>{loading ? 'Authenticating...' : 'Sign In to Business'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="text-center pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsRegister(true)}
                className="text-xs text-blue-600 font-bold hover:underline"
              >
                New business owner? Register your store for free →
              </button>
            </div>
          </form>
        ) : (
          /* Registration Form */
          <form onSubmit={handleRegister} className="space-y-3 text-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Store / Business Name *</label>
              <input
                type="text"
                required
                placeholder="e.g. Chennai Chai & Bakery"
                value={regData.businessName}
                onChange={(e) => setRegData({ ...regData, businessName: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Owner Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Suresh Kumar"
                  value={regData.ownerName}
                  onChange={(e) => setRegData({ ...regData, ownerName: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Business Type</label>
                <select
                  value={regData.businessType}
                  onChange={(e) => setRegData({ ...regData, businessType: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                >
                  <option value="Cafe / Restaurant">Cafe / Restaurant</option>
                  <option value="Supermarket / Grocery">Supermarket / Grocery</option>
                  <option value="Bakery / Sweets">Bakery / Sweets</option>
                  <option value="Tea / Juice Shop">Tea / Juice Shop</option>
                  <option value="Salon / Spa">Salon / Spa</option>
                  <option value="Retail / Apparel">Retail / Apparel</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Email *</label>
                <input
                  type="email"
                  required
                  placeholder="suresh@store.com"
                  value={regData.email}
                  onChange={(e) => setRegData({ ...regData, email: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Mobile Number</label>
                <input
                  type="tel"
                  placeholder="9876543210"
                  value={regData.phone}
                  onChange={(e) => setRegData({ ...regData, phone: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Invoice Prefix</label>
                <input
                  type="text"
                  maxLength={5}
                  placeholder="e.g. CHAI"
                  value={regData.invoicePrefix}
                  onChange={(e) => setRegData({ ...regData, invoicePrefix: e.target.value.toUpperCase() })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 font-mono uppercase"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Password</label>
                <input
                  type="password"
                  placeholder="Create secure password"
                  value={regData.password}
                  onChange={(e) => setRegData({ ...regData, password: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md active:scale-98 transition flex items-center justify-center gap-1.5"
            >
              <span>{loading ? 'Creating Business Workspace...' : 'Register & Start Billing'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="text-center pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsRegister(false)}
                className="text-xs text-blue-600 font-bold hover:underline"
              >
                Already have an account? Sign in here →
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
