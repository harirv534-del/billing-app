import React, { useState } from 'react';
import {
  Zap,
  Store,
  ShieldCheck,
  User as UserIcon,
  LogOut,
  ChevronDown,
  Sparkles,
  Receipt,
  Layers,
  CheckCircle,
} from 'lucide-react';
import { Business, User } from '../../types';
import { PWAInstallButton, OfflineIndicator } from '../common/PWAInstallButton';

interface NavbarProps {
  currentBusiness: Business | null;
  currentUser: User | null;
  onSwitchBusiness: (bizId: string) => void;
  onOpenSuperAdmin: () => void;
  onOpenAuth: () => void;
  onLogout: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  allBusinesses: Business[];
}

export const Navbar: React.FC<NavbarProps> = ({
  currentBusiness,
  currentUser,
  onSwitchBusiness,
  onOpenSuperAdmin,
  onOpenAuth,
  onLogout,
  activeTab,
  setActiveTab,
  allBusinesses,
}) => {
  const [showBizDropdown, setShowBizDropdown] = useState(false);
  const [showUserDropdown, setShowUserDropdown] = useState(false);

  const isSuperAdmin = currentUser?.role === 'super_admin';

  return (
    <>
      <OfflineIndicator />
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 h-16 flex items-center justify-between gap-2 sm:gap-4">
          
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab('billing')}
              className="flex items-center gap-2 text-left focus:outline-hidden group"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-700 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform">
                <Receipt className="w-5 h-5" />
              </div>
              <div className="hidden xs:block">
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold text-lg tracking-tight text-slate-900">
                    Bill<span className="text-blue-600">Pulse</span>
                  </span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-100 text-blue-700 uppercase tracking-wider">
                    AI POS
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 hidden sm:block">Smart Billing & Business SaaS</p>
              </div>
            </button>

            {/* Business Selector (Multi-Tenant Switcher) */}
            {currentBusiness && !isSuperAdmin && (
              <div className="relative">
                <button
                  onClick={() => setShowBizDropdown(!showBizDropdown)}
                  className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200/80 text-slate-800 text-xs sm:text-sm font-medium transition"
                >
                  <Store className="w-4 h-4 text-blue-600 shrink-0" />
                  <span className="max-w-[120px] sm:max-w-[180px] truncate font-semibold">
                    {currentBusiness.name}
                  </span>
                  <span className="text-[10px] font-semibold px-1.5 py-0.2 rounded bg-blue-600 text-white hidden md:inline">
                    {currentBusiness.plan}
                  </span>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
                </button>

                {showBizDropdown && (
                  <div className="absolute left-0 mt-2 w-72 rounded-2xl bg-white border border-slate-200 shadow-xl py-2 z-50 animate-in fade-in zoom-in-95">
                    <div className="px-3 py-1.5 border-b border-slate-100 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                      Switch Business Tenant
                    </div>
                    {allBusinesses.map((biz) => (
                      <button
                        key={biz.id}
                        onClick={() => {
                          onSwitchBusiness(biz.id);
                          setShowBizDropdown(false);
                        }}
                        className={`w-full px-3 py-2.5 flex items-center justify-between text-left hover:bg-slate-50 transition ${
                          biz.id === currentBusiness.id ? 'bg-blue-50/60 font-semibold text-blue-700' : 'text-slate-700'
                        }`}
                      >
                        <div className="truncate pr-2">
                          <div className="text-xs font-bold text-slate-900 truncate">{biz.name}</div>
                          <div className="text-[11px] text-slate-500">
                            {biz.businessType} • Prefix: {biz.invoicePrefix}
                          </div>
                        </div>
                        {biz.id === currentBusiness.id && <CheckCircle className="w-4 h-4 text-blue-600 shrink-0" />}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Quick Action Tabs for Desktop */}
          <div className="hidden lg:flex items-center gap-1 bg-slate-100/90 p-1 rounded-xl">
            <button
              onClick={() => setActiveTab('billing')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                activeTab === 'billing'
                  ? 'bg-white text-blue-600 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Receipt className="w-3.5 h-3.5" />
              Manual POS
            </button>
            <button
              onClick={() => setActiveTab('ai_billing')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                activeTab === 'ai_billing'
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-xs'
                  : 'text-indigo-600 hover:text-indigo-800'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 animate-pulse" />
              AI Photo Billing
            </button>
            <button
              onClick={() => setActiveTab('invoices')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                activeTab === 'invoices' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Invoices
            </button>
            <button
              onClick={() => setActiveTab('inventory')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                activeTab === 'inventory' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Inventory
            </button>
            <button
              onClick={() => setActiveTab('reports')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                activeTab === 'reports' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Daily Report
            </button>
          </div>

          {/* Right Controls: PWA, Super Admin button, User Account */}
          <div className="flex items-center gap-2 sm:gap-3">
            <PWAInstallButton />

            {/* Super Admin Toggle Button */}
            <button
              onClick={onOpenSuperAdmin}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-bold border transition ${
                activeTab === 'super_admin'
                  ? 'bg-slate-900 text-white border-slate-900 shadow-sm'
                  : 'border-slate-200 text-slate-700 bg-white hover:bg-slate-50'
              }`}
              title="Super Admin SaaS Management Portal"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-amber-500" />
              <span className="hidden sm:inline">Super Admin</span>
            </button>

            {/* User Account / Role dropdown */}
            {currentUser ? (
              <div className="relative">
                <button
                  onClick={() => setShowUserDropdown(!showUserDropdown)}
                  className="flex items-center gap-2 p-1.5 sm:px-2.5 sm:py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 transition"
                >
                  <div className="w-7 h-7 rounded-full bg-blue-100 text-blue-700 font-bold text-xs flex items-center justify-center">
                    {currentUser.name.charAt(0)}
                  </div>
                  <div className="hidden md:block text-left">
                    <div className="text-xs font-bold text-slate-900 leading-tight">{currentUser.name}</div>
                    <div className="text-[10px] text-slate-500 capitalize">{currentUser.role}</div>
                  </div>
                  <ChevronDown className="w-3 h-3 text-slate-400" />
                </button>

                {showUserDropdown && (
                  <div className="absolute right-0 mt-2 w-56 rounded-2xl bg-white border border-slate-200 shadow-xl py-2 z-50 animate-in fade-in zoom-in-95">
                    <div className="px-3 py-2 border-b border-slate-100">
                      <div className="text-xs font-bold text-slate-900">{currentUser.name}</div>
                      <div className="text-[11px] text-slate-500 truncate">{currentUser.email}</div>
                      <span className="inline-block mt-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-blue-50 text-blue-700 uppercase">
                        Role: {currentUser.role}
                      </span>
                    </div>

                    <button
                      onClick={() => {
                        setActiveTab('settings');
                        setShowUserDropdown(false);
                      }}
                      className="w-full px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 flex items-center gap-2 text-left"
                    >
                      <Store className="w-4 h-4 text-slate-400" />
                      Business Profile & Settings
                    </button>

                    <button
                      onClick={() => {
                        setActiveTab('staff');
                        setShowUserDropdown(false);
                      }}
                      className="w-full px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 flex items-center gap-2 text-left"
                    >
                      <UserIcon className="w-4 h-4 text-slate-400" />
                      Staff & Access Permissions
                    </button>

                    <div className="my-1 border-t border-slate-100"></div>

                    <button
                      onClick={() => {
                        setShowUserDropdown(false);
                        onLogout();
                      }}
                      className="w-full px-3 py-2 text-xs font-medium text-red-600 hover:bg-red-50 flex items-center gap-2 text-left"
                    >
                      <LogOut className="w-4 h-4 text-red-500" />
                      Sign Out
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={onOpenAuth}
                className="px-3.5 py-1.5 text-xs font-bold rounded-lg bg-blue-600 text-white hover:bg-blue-700 shadow-xs transition"
              >
                Sign In
              </button>
            )}
          </div>
        </div>
      </header>
    </>
  );
};
