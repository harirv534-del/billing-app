import React from 'react';
import {
  Receipt,
  Sparkles,
  Layers,
  Archive,
  Users,
  FileText,
  BarChart3,
  Settings,
  ShieldCheck,
  UserCheck,
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  userRole?: string;
  isSuperAdminPortal: boolean;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  userRole,
  isSuperAdminPortal,
}) => {
  const isCashier = userRole === 'cashier';

  const navItems = isSuperAdminPortal
    ? [
        { id: 'super_admin', label: 'Platform Overview', icon: ShieldCheck },
        { id: 'admin_businesses', label: 'Registered Businesses', icon: Layers },
        { id: 'admin_subscriptions', label: 'Subscriptions & Plans', icon: FileText },
        { id: 'admin_audit', label: 'Global Audit Logs', icon: BarChart3 },
      ]
    : [
        { id: 'billing', label: 'Manual Billing', icon: Receipt, hotkey: 'POS' },
        { id: 'ai_billing', label: 'AI Quick Billing', icon: Sparkles, badge: 'AI' },
        { id: 'invoices', label: 'Invoices & Receipts', icon: FileText },
        { id: 'products', label: 'Products & Menu', icon: Layers },
        { id: 'inventory', label: 'Inventory & Stock', icon: Archive },
        { id: 'customers', label: 'Customers CRM', icon: Users },
        { id: 'reports', label: 'Daily Sales Report', icon: FileText },
        { id: 'analytics', label: '30-Day Analytics', icon: BarChart3 },
        ...(!isCashier ? [{ id: 'staff', label: 'Staff & Roles', icon: UserCheck }] : []),
        { id: 'settings', label: 'Business Profile', icon: Settings },
      ];

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 bg-white border-r border-slate-200 shrink-0 min-h-[calc(100vh-4rem)] p-4 justify-between">
        <div className="space-y-1">
          <div className="px-3 py-2 text-[11px] font-bold tracking-wider text-slate-400 uppercase">
            {isSuperAdminPortal ? 'Super Admin SaaS' : 'Business Management'}
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            const isAi = item.id === 'ai_billing';

            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all group ${
                  isActive
                    ? isAi
                      ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-md shadow-blue-500/20'
                      : 'bg-blue-50 text-blue-700 font-bold'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon
                    className={`w-4 h-4 transition-transform group-hover:scale-110 ${
                      isActive ? (isAi ? 'text-white' : 'text-blue-600') : 'text-slate-400'
                    }`}
                  />
                  <span>{item.label}</span>
                </div>

                {item.badge && (
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                      isActive
                        ? 'bg-white/20 text-white'
                        : 'bg-indigo-100 text-indigo-700 animate-pulse'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Quick status footer in sidebar */}
        <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80 text-center">
          <div className="flex items-center justify-center gap-1.5 text-xs font-bold text-slate-800">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
            <span>Real-time POS Engine</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">Atomic Invoicing • Multi-Tenant</p>
        </div>
      </aside>

      {/* Mobile Bottom Navigation Bar */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 px-2 py-1.5 flex items-center justify-around shadow-lg">
        <button
          onClick={() => setActiveTab('billing')}
          className={`flex flex-col items-center gap-1 py-1 px-2 rounded-lg text-[10px] font-bold ${
            activeTab === 'billing' ? 'text-blue-600' : 'text-slate-500'
          }`}
        >
          <Receipt className="w-5 h-5" />
          <span>POS</span>
        </button>

        <button
          onClick={() => setActiveTab('ai_billing')}
          className={`flex flex-col items-center gap-1 py-1 px-2 rounded-lg text-[10px] font-bold ${
            activeTab === 'ai_billing' ? 'text-indigo-600 font-extrabold' : 'text-indigo-500'
          }`}
        >
          <div className="relative">
            <Sparkles className="w-5 h-5 animate-pulse" />
            <span className="absolute -top-1 -right-2 w-2 h-2 rounded-full bg-blue-600"></span>
          </div>
          <span>AI Photo</span>
        </button>

        <button
          onClick={() => setActiveTab('invoices')}
          className={`flex flex-col items-center gap-1 py-1 px-2 rounded-lg text-[10px] font-bold ${
            activeTab === 'invoices' ? 'text-blue-600' : 'text-slate-500'
          }`}
        >
          <FileText className="w-5 h-5" />
          <span>Bills</span>
        </button>

        <button
          onClick={() => setActiveTab('inventory')}
          className={`flex flex-col items-center gap-1 py-1 px-2 rounded-lg text-[10px] font-bold ${
            activeTab === 'inventory' ? 'text-blue-600' : 'text-slate-500'
          }`}
        >
          <Archive className="w-5 h-5" />
          <span>Stock</span>
        </button>

        <button
          onClick={() => setActiveTab('reports')}
          className={`flex flex-col items-center gap-1 py-1 px-2 rounded-lg text-[10px] font-bold ${
            activeTab === 'reports' ? 'text-blue-600' : 'text-slate-500'
          }`}
        >
          <BarChart3 className="w-5 h-5" />
          <span>Reports</span>
        </button>
      </nav>
    </>
  );
};
