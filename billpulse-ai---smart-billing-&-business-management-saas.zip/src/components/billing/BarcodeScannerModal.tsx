import React, { useState, useEffect, useRef } from 'react';
import {
  Camera,
  Barcode,
  X,
  CheckCircle,
  AlertTriangle,
  RefreshCw,
  Sparkles,
  Zap,
  Volume2,
} from 'lucide-react';
import { Product, Business } from '../../types';
import { playScannerBeep } from '../../utils/sound';

interface BarcodeScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  business: Business;
  onProductScanned: (product: Product) => void;
}

export const BarcodeScannerModal: React.FC<BarcodeScannerModalProps> = ({
  isOpen,
  onClose,
  products,
  business,
  onProductScanned,
}) => {
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [lastScannedItem, setLastScannedItem] = useState<{ product: Product; time: Date } | null>(null);
  const [continuousMode, setContinuousMode] = useState(true);
  const [manualCode, setManualCode] = useState('');
  const [scanCount, setScanCount] = useState(0);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const isProcessingRef = useRef(false);

  // Products with barcodes in catalog
  const catalogBarcodes = products.filter((p) => p.barcode && p.barcode.trim());

  useEffect(() => {
    if (isOpen) {
      startCamera();
      setScanCount(0);
      setLastScannedItem(null);
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [isOpen]);

  const startCamera = async () => {
    setCameraError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: 'environment' },
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
      });

      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setCameraActive(true);

      // Start BarcodeDetector loop if supported
      setupBarcodeDetector();
    } catch (err: any) {
      console.warn('Camera access not granted or unavailable:', err);
      setCameraError(
        'Unable to access device camera. You can still scan using a handheld USB barcode scanner or select quick test barcodes below.'
      );
      setCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
  };

  const setupBarcodeDetector = () => {
    if (typeof window === 'undefined') return;

    // Check if BarcodeDetector is supported natively in browser
    const BarcodeDetectorClass = (window as any).BarcodeDetector;
    if (BarcodeDetectorClass) {
      try {
        const detector = new BarcodeDetectorClass({
          formats: ['ean_13', 'ean_8', 'upc_a', 'upc_e', 'code_128', 'code_39', 'qr_code'],
        });

        const detectFrame = async () => {
          if (!videoRef.current || videoRef.current.readyState < 2) {
            animationFrameRef.current = requestAnimationFrame(detectFrame);
            return;
          }

          if (!isProcessingRef.current) {
            isProcessingRef.current = true;
            try {
              const barcodes = await detector.detect(videoRef.current);
              if (barcodes && barcodes.length > 0) {
                const rawValue = barcodes[0].rawValue;
                if (rawValue) {
                  processBarcodeScan(rawValue);
                }
              }
            } catch (e) {
              // frame drop, ignore
            } finally {
              // Rate limit detection cycles
              setTimeout(() => {
                isProcessingRef.current = false;
              }, 600);
            }
          }

          animationFrameRef.current = requestAnimationFrame(detectFrame);
        };

        animationFrameRef.current = requestAnimationFrame(detectFrame);
      } catch (err) {
        console.warn('BarcodeDetector initialization:', err);
      }
    }
  };

  const processBarcodeScan = (code: string) => {
    const cleanCode = code.trim().toLowerCase();
    if (!cleanCode) return;

    // Look for product by barcode or SKU
    const matched = products.find(
      (p) =>
        (p.barcode && p.barcode.toLowerCase() === cleanCode) ||
        p.sku.toLowerCase() === cleanCode ||
        p.name.toLowerCase().includes(cleanCode)
    );

    if (matched) {
      playScannerBeep(true);
      onProductScanned(matched);
      setLastScannedItem({ product: matched, time: new Date() });
      setScanCount((prev) => prev + 1);

      if (!continuousMode) {
        setTimeout(() => {
          onClose();
        }, 400);
      }
    } else {
      playScannerBeep(false);
      setCameraError(`Barcode "${code}" not found in ${business.name} catalog.`);
      setTimeout(() => setCameraError(null), 3500);
    }
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualCode.trim()) return;
    processBarcodeScan(manualCode);
    setManualCode('');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-3 sm:p-4 animate-in fade-in">
      <div className="w-full max-w-xl rounded-3xl bg-white shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="p-4 sm:p-5 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-600/30 text-blue-400 border border-blue-500/30 flex items-center justify-center">
              <Barcode className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-extrabold flex items-center gap-2">
                <span>POS Barcode Scanner</span>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-500 text-white uppercase">
                  Live
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">Aim counter camera or barcode reader at product code</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setContinuousMode(!continuousMode)}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold border transition ${
                continuousMode
                  ? 'bg-blue-600 border-blue-500 text-white'
                  : 'bg-slate-800 border-slate-700 text-slate-300'
              }`}
              title="Keep scanner open to scan multiple items consecutively"
            >
              Continuous: {continuousMode ? 'ON' : 'OFF'}
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Viewfinder Section */}
        <div className="relative bg-black flex items-center justify-center min-h-[240px] sm:min-h-[300px] overflow-hidden">
          {cameraActive ? (
            <>
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover max-h-[320px]"
              />

              {/* Aiming Reticle with Animated Laser Line */}
              <div className="absolute inset-0 pointer-events-none flex items-center justify-center p-6">
                <div className="relative w-64 h-36 sm:w-80 sm:h-44 border-2 border-blue-400/80 rounded-2xl shadow-[0_0_0_9999px_rgba(0,0,0,0.45)] flex items-center justify-center">
                  
                  {/* Corner accents */}
                  <div className="absolute top-0 left-0 w-4 h-4 border-t-4 border-l-4 border-white rounded-tl-lg"></div>
                  <div className="absolute top-0 right-0 w-4 h-4 border-t-4 border-r-4 border-white rounded-tr-lg"></div>
                  <div className="absolute bottom-0 left-0 w-4 h-4 border-b-4 border-l-4 border-white rounded-bl-lg"></div>
                  <div className="absolute bottom-0 right-0 w-4 h-4 border-b-4 border-r-4 border-white rounded-br-lg"></div>

                  {/* Red/Green Laser Scanner Beam */}
                  <div className="w-full h-0.5 bg-red-500 shadow-[0_0_8px_#ef4444] animate-pulse"></div>

                  <span className="absolute bottom-2 bg-black/60 backdrop-blur-xs text-[10px] text-white font-semibold px-2 py-0.5 rounded-full">
                    Align Barcode Within Frame
                  </span>
                </div>
              </div>
            </>
          ) : (
            <div className="text-center p-6 text-slate-400">
              <Camera className="w-10 h-10 text-slate-600 mx-auto mb-2" />
              <p className="text-xs font-semibold text-slate-300">Camera Viewfinder Paused</p>
              <button
                onClick={startCamera}
                className="mt-2 px-3 py-1.5 rounded-xl bg-blue-600 text-white text-xs font-bold hover:bg-blue-700 transition"
              >
                Start Camera
              </button>
            </div>
          )}

          {/* Success Scan Flash Overlay */}
          {lastScannedItem && (
            <div className="absolute top-3 inset-x-4 bg-emerald-600 text-white p-2.5 rounded-2xl shadow-xl flex items-center justify-between text-xs font-bold animate-in fade-in slide-in-from-top-2">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-200 shrink-0" />
                <span className="truncate">
                  Added: <strong>{lastScannedItem.product.name}</strong> ({business.currencySymbol}{lastScannedItem.product.price})
                </span>
              </div>
              <span className="px-2 py-0.5 rounded-md bg-white/20 text-[10px]">
                {scanCount} scanned
              </span>
            </div>
          )}

          {/* Error Banner */}
          {cameraError && (
            <div className="absolute bottom-3 inset-x-4 bg-red-600/90 backdrop-blur-xs text-white p-2.5 rounded-2xl shadow-xl flex items-center gap-2 text-xs font-bold animate-in fade-in">
              <AlertTriangle className="w-4 h-4 text-amber-300 shrink-0" />
              <span className="text-[11px]">{cameraError}</span>
            </div>
          )}
        </div>

        {/* Manual Barcode Input & Quick Test Simulation Bar */}
        <div className="p-4 sm:p-5 bg-white space-y-3.5 overflow-y-auto">
          
          {/* Quick Barcode Keypad / Handheld Gun Input */}
          <form onSubmit={handleManualSubmit} className="flex gap-2">
            <div className="relative flex-1">
              <Barcode className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                autoFocus
                placeholder="Enter barcode digits or scan with handheld gun..."
                value={manualCode}
                onChange={(e) => setManualCode(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 font-mono focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
              />
            </div>
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition"
            >
              Add to Cart
            </button>
          </form>

          {/* 1-Click Simulation Buttons for Catalog Barcodes */}
          {catalogBarcodes.length > 0 && (
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                <span className="flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                  Quick Test Barcodes ({catalogBarcodes.length} registered):
                </span>
                <span className="text-[10px] text-slate-400 font-normal">Click to simulate scan</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-36 overflow-y-auto pr-1">
                {catalogBarcodes.map((prod) => (
                  <button
                    key={prod.id}
                    type="button"
                    onClick={() => processBarcodeScan(prod.barcode!)}
                    className="p-2 rounded-xl border border-slate-200 bg-slate-50 hover:bg-blue-50 hover:border-blue-300 text-left transition flex items-center justify-between group"
                  >
                    <div className="truncate pr-2">
                      <div className="text-xs font-bold text-slate-900 group-hover:text-blue-700 truncate">
                        {prod.name}
                      </div>
                      <div className="text-[10px] text-slate-500 font-mono">
                        Code: {prod.barcode}
                      </div>
                    </div>
                    <span className="text-xs font-black text-slate-800 shrink-0">
                      {business.currencySymbol}{prod.price}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Footer Actions */}
          <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-slate-500">
              Total Scanned in this session: <strong className="text-slate-900">{scanCount} items</strong>
            </span>

            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition"
            >
              Done Scanning
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
