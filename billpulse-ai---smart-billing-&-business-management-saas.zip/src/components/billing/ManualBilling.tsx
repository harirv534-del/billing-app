import React, { useState, useMemo } from 'react';
import {
  Search,
  Plus,
  Minus,
  Trash2,
  Receipt,
  User,
  Phone,
  CheckCircle,
  Share2,
  Download,
  Percent,
  Sparkles,
  CreditCard,
  Banknote,
  Smartphone,
  AlertCircle,
  Barcode,
  Scan,
} from 'lucide-react';
import { Product, Business, InvoiceItem, Invoice } from '../../types';
import { api } from '../../services/api';
import { downloadInvoicePDF } from '../../utils/pdfGenerator';
import {
  shareViaWhatsApp,
  shareInvoiceNative,
  cleanWhatsAppPhone,
  getWhatsAppUrl,
} from '../../utils/whatsappShare';
import { playScannerBeep } from '../../utils/sound';
import { BarcodeScannerModal } from './BarcodeScannerModal';

interface ManualBillingProps {
  business: Business;
  products: Product[];
  onBillConfirmed?: (invoice: Invoice) => void;
  onSwitchToAiBilling?: () => void;
}

interface CartItem extends InvoiceItem {
  stockAvailable: number;
}

export const ManualBilling: React.FC<ManualBillingProps> = ({
  business,
  products,
  onBillConfirmed,
  onSwitchToAiBilling,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'Cash' | 'UPI' | 'Card' | 'Other'>('Cash');
  const [globalDiscountPercent, setGlobalDiscountPercent] = useState<number>(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [generatedInvoice, setGeneratedInvoice] = useState<Invoice | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isBarcodeModalOpen, setIsBarcodeModalOpen] = useState(false);
  const [barcodeInput, setBarcodeInput] = useState('');
  const [scanToast, setScanToast] = useState<{ message: string; productName: string } | null>(null);
  const [autoSendWhatsApp, setAutoSendWhatsApp] = useState(true);
  const [modalPhone, setModalPhone] = useState('');

  // Barcode quick search & add handler
  const scanBarcode = (code: string) => {
    const cleanCode = code.trim().toLowerCase();
    if (!cleanCode) return;

    const matched = products.find(
      (p) =>
        (p.barcode && p.barcode.toLowerCase() === cleanCode) ||
        p.sku.toLowerCase() === cleanCode ||
        p.name.toLowerCase() === cleanCode
    );

    if (matched) {
      if (matched.stock <= 0) {
        playScannerBeep(false);
        setErrorMessage(`"${matched.name}" is out of stock!`);
        return;
      }
      addToCart(matched);
      playScannerBeep(true);
      setScanToast({
        message: `Scanned & Added (+1)`,
        productName: `${matched.name} (${business.currencySymbol}${matched.price})`,
      });
      setErrorMessage(null);
      setTimeout(() => setScanToast(null), 2500);
    } else {
      playScannerBeep(false);
      setErrorMessage(`No product found with barcode or SKU "${code}"`);
      setTimeout(() => setErrorMessage(null), 3500);
    }
  };

  // Categories list
  const categories = useMemo(() => {
    const set = new Set(products.map((p) => p.category));
    return ['All', ...Array.from(set)];
  }, [products]);

  // Filtered products
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      if (!p.active) return false;
      const matchesCat = selectedCategory === 'All' || p.category === selectedCategory;
      const q = searchQuery.toLowerCase();
      const matchesSearch =
        p.name.toLowerCase().includes(q) ||
        p.sku.toLowerCase().includes(q) ||
        (p.barcode && p.barcode.includes(q));
      return matchesCat && matchesSearch;
    });
  }, [products, selectedCategory, searchQuery]);

  // Cart operations
  const addToCart = (product: Product) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.productId === product.id);
      if (existing) {
        return prev.map((item) => {
          if (item.productId === product.id) {
            const newQty = item.quantity + 1;
            const subtotal = newQty * item.unitPrice;
            const discountAmt = Math.round((subtotal * item.discountPercent) / 100);
            const taxable = subtotal - discountAmt;
            const taxAmt = Math.round((taxable * item.taxPercent) / 100);
            return {
              ...item,
              quantity: newQty,
              subtotal,
              discountAmount: discountAmt,
              taxAmount: taxAmt,
              total: taxable + taxAmt,
            };
          }
          return item;
        });
      }

      const unitPrice = product.price;
      const taxPercent = product.taxPercent || 0;
      const subtotal = unitPrice * 1;
      const taxAmt = Math.round((subtotal * taxPercent) / 100);

      const newItem: CartItem = {
        productId: product.id,
        name: product.name,
        sku: product.sku,
        quantity: 1,
        unitPrice,
        taxPercent,
        discountPercent: 0,
        subtotal,
        discountAmount: 0,
        taxAmount: taxAmt,
        total: subtotal + taxAmt,
        stockAvailable: product.stock,
      };

      return [...prev, newItem];
    });
  };

  const updateCartQty = (productId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.productId === productId) {
            const newQty = item.quantity + delta;
            if (newQty <= 0) return null;
            const subtotal = newQty * item.unitPrice;
            const discountAmt = Math.round((subtotal * item.discountPercent) / 100);
            const taxable = subtotal - discountAmt;
            const taxAmt = Math.round((taxable * item.taxPercent) / 100);
            return {
              ...item,
              quantity: newQty,
              subtotal,
              discountAmount: discountAmt,
              taxAmount: taxAmt,
              total: taxable + taxAmt,
            };
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.productId !== productId));
  };

  const clearCart = () => {
    setCart([]);
    setCustomerPhone('');
    setCustomerName('');
    setGlobalDiscountPercent(0);
    setErrorMessage(null);
  };

  // Calculations
  const rawSubtotal = cart.reduce((acc, i) => acc + i.subtotal, 0);
  const baseDiscount = cart.reduce((acc, i) => acc + i.discountAmount, 0);
  const additionalGlobalDiscount = Math.round((rawSubtotal * globalDiscountPercent) / 100);
  const totalDiscount = baseDiscount + additionalGlobalDiscount;
  const totalTax = cart.reduce((acc, i) => acc + i.taxAmount, 0);
  const grandTotal = Math.max(0, rawSubtotal - totalDiscount + totalTax);

  // Submit Bill with Direct WhatsApp Sending support
  const handleGenerateBill = async (forceWhatsApp?: boolean) => {
    if (cart.length === 0) {
      setErrorMessage('Please select products to bill');
      return;
    }

    const trimmedPhone = customerPhone.trim();
    const willSendWhatsApp = forceWhatsApp ?? (autoSendWhatsApp && !!trimmedPhone);

    // Bypass browser popup blockers: synchronously pre-open a blank tab in the user click event
    let preWin: Window | null = null;
    if (willSendWhatsApp && trimmedPhone) {
      try {
        preWin = window.open('about:blank', '_blank');
      } catch (e) {
        preWin = null;
      }
    }

    setIsSubmitting(true);
    setErrorMessage(null);

    try {
      const itemsPayload: InvoiceItem[] = cart.map((i) => ({
        productId: i.productId,
        name: i.name,
        sku: i.sku,
        quantity: i.quantity,
        unitPrice: i.unitPrice,
        taxPercent: i.taxPercent,
        discountPercent: i.discountPercent,
        subtotal: i.subtotal,
        taxAmount: i.taxAmount,
        discountAmount: i.discountAmount,
        total: i.total,
      }));

      const invoice = await api.createInvoice({
        items: itemsPayload,
        customerName: customerName.trim(),
        customerPhone: trimmedPhone,
        paymentMethod,
        subtotal: rawSubtotal,
        taxTotal: totalTax,
        discountTotal: totalDiscount,
        grandTotal,
      });

      setGeneratedInvoice(invoice);
      setModalPhone(trimmedPhone);
      if (onBillConfirmed) onBillConfirmed(invoice);

      // Auto-dispatch directly to the WhatsApp number entered in the bill
      if (willSendWhatsApp && trimmedPhone) {
        shareViaWhatsApp(invoice, business, trimmedPhone, preWin);
      } else if (preWin && !preWin.closed) {
        preWin.close();
      }
    } catch (err: any) {
      if (preWin && !preWin.closed) {
        preWin.close();
      }
      console.error('Billing error:', err);
      setErrorMessage(err.message || 'Unable to complete billing. Please retry.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-4">
      
      {/* Top Banner with Quick Switch to AI Photo Billing */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <h1 className="text-lg font-extrabold text-slate-900 flex items-center gap-2">
            <Receipt className="w-5 h-5 text-blue-600" />
            <span>Fast POS Billing</span>
          </h1>
          <p className="text-xs text-slate-500">
            {business.name} • Invoice Prefix: <strong className="text-slate-800">{business.invoicePrefix}</strong>
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsBarcodeModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow-xs transition"
            title="Open camera or hardware barcode reader"
          >
            <Barcode className="w-3.5 h-3.5 text-blue-400" />
            <span>Barcode Scanner</span>
          </button>

          {onSwitchToAiBilling && (
            <button
              onClick={onSwitchToAiBilling}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-xs shadow-xs transition"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>AI Photo Billing</span>
            </button>
          )}
        </div>
      </div>

      {errorMessage && (
        <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs font-semibold flex items-center gap-2 animate-in fade-in">
          <AlertCircle className="w-4 h-4 shrink-0 text-red-500" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Main Split: Left Catalog Grid, Right Live Invoice Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        
        {/* LEFT COLUMN: Product Catalog (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          
          {/* Search & Barcode Quick-Scan Bar */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="text"
                  placeholder="Search name, SKU, or scan barcode with USB scanner..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && searchQuery.trim()) {
                      e.preventDefault();
                      // Try direct barcode / SKU match
                      const matched = products.find(
                        (p) =>
                          (p.barcode && p.barcode.toLowerCase() === searchQuery.trim().toLowerCase()) ||
                          p.sku.toLowerCase() === searchQuery.trim().toLowerCase()
                      );
                      if (matched) {
                        scanBarcode(searchQuery.trim());
                        setSearchQuery('');
                      } else if (filteredProducts.length === 1) {
                        // If exact single search match, add to cart
                        scanBarcode(filteredProducts[0].barcode || filteredProducts[0].sku);
                        setSearchQuery('');
                      }
                    }
                  }}
                  className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                />
              </div>

              {/* Camera Scanner Trigger Button */}
              <button
                type="button"
                onClick={() => setIsBarcodeModalOpen(true)}
                className="px-3.5 py-2 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold text-xs flex items-center gap-1.5 border border-blue-200/80 transition"
                title="Scan barcode with camera or test catalog codes"
              >
                <Barcode className="w-4 h-4 text-blue-600" />
                <span className="hidden sm:inline">Camera Scan</span>
              </button>
            </div>

            {/* Quick 1-Click Barcode Test Chips for Catalog */}
            {products.some((p) => p.barcode) && (
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px] scrollbar-none">
                <span className="text-slate-400 font-bold uppercase tracking-wider shrink-0 text-[10px] flex items-center gap-1">
                  <Barcode className="w-3 h-3 text-slate-400" />
                  Quick Scan:
                </span>
                {products
                  .filter((p) => p.barcode)
                  .slice(0, 4)
                  .map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => scanBarcode(p.barcode!)}
                      className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-blue-50 hover:text-blue-700 hover:border-blue-300 border border-slate-200 text-slate-700 shrink-0 font-medium transition"
                      title={`Simulate scan of ${p.name}`}
                    >
                      {p.name.split(' ')[0]} <span className="font-mono text-[10px] text-slate-400">({p.barcode})</span>
                    </button>
                  ))}
              </div>
            )}

            {/* Category pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs scrollbar-none">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 rounded-lg font-semibold shrink-0 transition ${
                    selectedCategory === cat
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Product Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 max-h-[560px] overflow-y-auto pr-1">
            {filteredProducts.map((p) => {
              const inCartItem = cart.find((i) => i.productId === p.id);
              const isLowStock = p.stock <= p.lowStockLimit && p.stock > 0;
              const isOutOfStock = p.stock === 0;

              return (
                <button
                  key={p.id}
                  onClick={() => !isOutOfStock && addToCart(p)}
                  disabled={isOutOfStock}
                  className={`p-3 rounded-2xl border text-left flex flex-col justify-between transition-all group relative ${
                    isOutOfStock
                      ? 'bg-slate-50 border-slate-200 opacity-60 cursor-not-allowed'
                      : inCartItem
                      ? 'bg-blue-50/60 border-blue-400 shadow-xs'
                      : 'bg-white border-slate-200 hover:border-blue-300 hover:shadow-xs'
                  }`}
                >
                  {/* In Cart quantity badge */}
                  {inCartItem && (
                    <span className="absolute top-2 right-2 w-5 h-5 rounded-full bg-blue-600 text-white font-extrabold text-[10px] flex items-center justify-center shadow-xs">
                      {inCartItem.quantity}
                    </span>
                  )}

                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                      {p.category}
                    </span>
                    <h3 className="text-xs font-bold text-slate-900 group-hover:text-blue-600 transition-colors line-clamp-2 mt-0.5">
                      {p.name}
                    </h3>
                  </div>

                  <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-sm font-black text-slate-900">
                      {business.currencySymbol}{p.price}
                    </span>
                    
                    <span
                      className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${
                        isOutOfStock
                          ? 'bg-red-100 text-red-700'
                          : isLowStock
                          ? 'bg-amber-100 text-amber-700'
                          : 'bg-slate-100 text-slate-500'
                      }`}
                    >
                      {isOutOfStock ? 'Out of stock' : `${p.stock} left`}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* RIGHT COLUMN: Live Order Cart (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm space-y-4 flex flex-col h-full">
            
            {/* Cart Header with Bill / Invoice Number preview */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-600"></span>
                <div>
                  <h2 className="text-sm font-extrabold text-slate-900 flex items-center gap-1.5">
                    <span>Active Order</span>
                    <span className="text-xs text-slate-400 font-semibold">({cart.length} items)</span>
                  </h2>
                  <div className="text-[11px] font-mono text-slate-500 flex items-center gap-1">
                    <Receipt className="w-3 h-3 text-slate-400" />
                    <span>Bill No:</span>
                    <strong className="text-slate-800 bg-slate-100 px-1.5 py-0.5 rounded text-[10px]">
                      {business.invoicePrefix}-{new Date().getFullYear()}-{String(business.nextInvoiceSequence || 1001).padStart(6, '0')}
                    </strong>
                  </div>
                </div>
              </div>
              {cart.length > 0 && (
                <button
                  onClick={clearCart}
                  className="text-xs text-red-600 hover:underline font-semibold"
                >
                  Clear All
                </button>
              )}
            </div>

            {/* Customer & WhatsApp Input Section */}
            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-2.5">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Customer WhatsApp Number</span>
                </label>
                {customerPhone.trim() ? (
                  <span className="px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[10px] flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                    Direct Send Ready
                  </span>
                ) : (
                  <span className="text-[10px] text-slate-400">Direct bill delivery</span>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div className="relative">
                  <div className="absolute left-2.5 top-2 text-slate-500 font-bold text-xs flex items-center gap-1 border-r border-slate-200 pr-1.5">
                    <span className="text-xs">🇮🇳</span>
                    <span>+91</span>
                  </div>
                  <input
                    type="tel"
                    placeholder="Enter WhatsApp No"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    className="w-full pl-16 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden font-medium text-slate-900"
                  />
                </div>

                <div className="relative">
                  <User className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                  <input
                    type="text"
                    placeholder="Customer Name (optional)"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full pl-8 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 bg-white focus:ring-2 focus:ring-blue-500 focus:outline-hidden font-medium text-slate-900"
                  />
                </div>
              </div>

              {/* Direct WhatsApp auto-dispatch toggle */}
              <div className="flex items-center justify-between pt-1 border-t border-slate-200/60 text-[11px]">
                <label className="flex items-center gap-1.5 cursor-pointer text-slate-600 font-medium select-none">
                  <input
                    type="checkbox"
                    checked={autoSendWhatsApp}
                    onChange={(e) => setAutoSendWhatsApp(e.target.checked)}
                    className="rounded text-emerald-600 focus:ring-emerald-500 w-3.5 h-3.5"
                  />
                  <span>Send bill direct to WhatsApp upon generate</span>
                </label>
                {customerPhone.trim() && (
                  <span className="text-emerald-700 font-bold text-[10px]">
                    To: {cleanWhatsAppPhone(customerPhone.trim())}
                  </span>
                )}
              </div>
            </div>

            {/* Cart Items List */}
            <div className="grow space-y-2.5 max-h-[280px] overflow-y-auto pr-1">
              {cart.length === 0 ? (
                <div className="py-12 text-center text-slate-400">
                  <Receipt className="w-8 h-8 mx-auto text-slate-300 mb-1" />
                  <p className="text-xs font-semibold">Cart is currently empty</p>
                  <p className="text-[11px] text-slate-500">Tap products on the left to add items</p>
                </div>
              ) : (
                cart.map((item) => (
                  <div
                    key={item.productId}
                    className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-between text-xs"
                  >
                    <div className="truncate pr-2">
                      <div className="font-bold text-slate-900 truncate">{item.name}</div>
                      <div className="text-[11px] text-slate-500">
                        {business.currencySymbol}{item.unitPrice} × {item.quantity} = <strong className="text-slate-800">{business.currencySymbol}{item.total}</strong>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <div className="flex items-center border border-slate-300 rounded-lg bg-white overflow-hidden shadow-2xs">
                        <button
                          onClick={() => updateCartQty(item.productId, -1)}
                          className="px-1.5 py-0.5 text-slate-600 hover:bg-slate-100"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="w-6 text-center font-bold text-slate-900 text-xs">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateCartQty(item.productId, 1)}
                          className="px-1.5 py-0.5 text-slate-600 hover:bg-slate-100"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      <button
                        onClick={() => removeFromCart(item.productId)}
                        className="p-1 text-slate-400 hover:text-red-600"
                        title="Delete"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Payment Method Selector */}
            <div className="space-y-1.5 pt-2 border-t border-slate-100">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                Payment Method
              </span>
              <div className="grid grid-cols-4 gap-1.5">
                {[
                  { id: 'Cash', icon: Banknote },
                  { id: 'UPI', icon: Smartphone },
                  { id: 'Card', icon: CreditCard },
                  { id: 'Other', icon: Receipt },
                ].map((m) => {
                  const Icon = m.icon;
                  return (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setPaymentMethod(m.id as any)}
                      className={`py-2 px-1 rounded-xl text-xs font-bold border flex flex-col items-center gap-1 transition ${
                        paymentMethod === m.id
                          ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                          : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      <span>{m.id}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Calculations Breakdown */}
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-1.5">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal:</span>
                <span className="font-semibold text-slate-900">{business.currencySymbol}{rawSubtotal}</span>
              </div>

              {totalDiscount > 0 && (
                <div className="flex justify-between text-red-600">
                  <span>Discount:</span>
                  <span className="font-semibold">-{business.currencySymbol}{totalDiscount}</span>
                </div>
              )}

              <div className="flex justify-between text-slate-600">
                <span>Tax (GST):</span>
                <span className="font-semibold text-slate-900">{business.currencySymbol}{totalTax}</span>
              </div>

              <div className="flex justify-between text-base font-black text-slate-900 pt-2 border-t border-slate-200">
                <span>Grand Total:</span>
                <span className="text-blue-600">{business.currencySymbol}{grandTotal}</span>
              </div>
            </div>

            {/* Action Buttons: Direct WhatsApp Send vs Standard Bill */}
            <div className="space-y-2 pt-1">
              <button
                type="button"
                onClick={() => handleGenerateBill(true)}
                disabled={isSubmitting || cart.length === 0}
                className={`w-full py-3.5 rounded-2xl font-black text-sm shadow-md transition-all flex items-center justify-center gap-2 ${
                  cart.length === 0
                    ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                    : 'bg-emerald-600 hover:bg-emerald-700 text-white active:scale-98 shadow-emerald-600/25 ring-2 ring-emerald-500/20'
                }`}
              >
                {isSubmitting ? (
                  <>
                    <div className="w-4 h-4 rounded-full border-2 border-white border-t-transparent animate-spin"></div>
                    <span>Processing & Dispatching to WhatsApp...</span>
                  </>
                ) : (
                  <>
                    <Share2 className="w-4 h-4 text-emerald-200" />
                    <span>
                      {customerPhone.trim()
                        ? `⚡ Generate & Send to WhatsApp (${cleanWhatsAppPhone(customerPhone.trim())})`
                        : `⚡ Generate & Send Direct to WhatsApp`}
                    </span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => handleGenerateBill(false)}
                disabled={isSubmitting || cart.length === 0}
                className={`w-full py-2.5 rounded-xl font-bold text-xs transition border flex items-center justify-center gap-1.5 ${
                  cart.length === 0
                    ? 'border-slate-200 text-slate-400 cursor-not-allowed'
                    : 'border-slate-300 hover:bg-slate-100 text-slate-700 active:scale-98'
                }`}
              >
                <CheckCircle className="w-3.5 h-3.5 text-blue-600" />
                <span>Save Bill Only ({business.currencySymbol}{grandTotal})</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Post-Bill Success Modal with Direct WhatsApp Confirmation */}
      {generatedInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-md rounded-3xl bg-white p-6 shadow-2xl space-y-4 animate-in zoom-in-95">
            <div className="text-center space-y-1.5">
              <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center">
                <CheckCircle className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-black text-slate-900">Bill Saved Successfully</h3>
              <p className="text-xs text-slate-500">
                Invoice No: <strong className="text-slate-900">{generatedInvoice.invoiceNumber}</strong>
              </p>
            </div>

            {/* Direct WhatsApp Delivery Status & 1-Click Open */}
            {modalPhone ? (
              <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-950 text-xs space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                    <span className="font-bold">Dispatched Direct to WhatsApp:</span>
                  </div>
                  <span className="font-mono font-black text-emerald-800 bg-white/80 px-2 py-0.5 rounded-md border border-emerald-200">
                    +{cleanWhatsAppPhone(modalPhone)}
                  </span>
                </div>
                <p className="text-[11px] text-emerald-700 leading-relaxed">
                  Tax invoice with full itemized breakdown, taxes, and amounts was linked directly to customer WhatsApp.
                </p>
                <a
                  href={getWhatsAppUrl(generatedInvoice, business, modalPhone)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs flex items-center justify-center gap-2 shadow-xs transition"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>Open WhatsApp Chat Directly (+{cleanWhatsAppPhone(modalPhone)})</span>
                </a>
              </div>
            ) : (
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
                <label className="font-bold text-slate-700 flex items-center gap-1.5">
                  <Share2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Send Bill Direct to WhatsApp Number:</span>
                </label>
                <div className="flex gap-2">
                  <input
                    type="tel"
                    placeholder="Enter WhatsApp mobile (e.g. 9876543210)"
                    value={modalPhone}
                    onChange={(e) => setModalPhone(e.target.value)}
                    className="flex-1 px-3 py-1.5 rounded-lg border border-slate-300 text-xs bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden font-medium"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (modalPhone.trim()) {
                        shareViaWhatsApp(generatedInvoice, business, modalPhone.trim());
                      }
                    }}
                    className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shrink-0 flex items-center gap-1 shadow-xs"
                  >
                    <span>Send</span>
                  </button>
                </div>
              </div>
            )}

            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-1.5">
              <div className="flex justify-between">
                <span className="text-slate-500">Total Items:</span>
                <span className="font-bold text-slate-900">{generatedInvoice.items.length} items</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Payment Mode:</span>
                <span className="font-bold text-slate-900">{generatedInvoice.paymentMethod}</span>
              </div>
              <div className="flex justify-between text-sm font-black text-blue-600 pt-1.5 border-t border-slate-200">
                <span>Grand Total:</span>
                <span>{business.currencySymbol}{generatedInvoice.grandTotal}</span>
              </div>
            </div>

            <div className="space-y-2">
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => downloadInvoicePDF(generatedInvoice, business)}
                  className="py-2.5 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-800 font-bold text-xs flex items-center justify-center gap-1.5"
                >
                  <Download className="w-4 h-4 text-blue-600" />
                  <span>Download PDF</span>
                </button>

                <button
                  onClick={() => shareInvoiceNative(generatedInvoice, business)}
                  className="py-2.5 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-800 font-bold text-xs flex items-center justify-center gap-1.5"
                >
                  <Share2 className="w-4 h-4 text-indigo-600" />
                  <span>Device Share</span>
                </button>
              </div>

              <button
                onClick={() => {
                  setGeneratedInvoice(null);
                  clearCart();
                }}
                className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition"
              >
                Start Next Bill
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Barcode Scanner Viewfinder Modal */}
      <BarcodeScannerModal
        isOpen={isBarcodeModalOpen}
        onClose={() => setIsBarcodeModalOpen(false)}
        products={products}
        business={business}
        onProductScanned={(product) => {
          scanBarcode(product.barcode || product.sku);
        }}
      />

      {/* Floating Scan Toast Alert */}
      {scanToast && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-3 rounded-2xl bg-slate-900/95 backdrop-blur-md text-white px-4 py-3 shadow-2xl border border-slate-700 animate-in fade-in slide-in-from-bottom-4">
          <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 border border-emerald-500/30">
            <Barcode className="w-4 h-4" />
          </div>
          <div>
            <span className="text-xs font-bold text-emerald-400 block">{scanToast.message}</span>
            <span className="text-[11px] text-slate-300 font-semibold">{scanToast.productName}</span>
          </div>
        </div>
      )}
    </div>
  );
};
