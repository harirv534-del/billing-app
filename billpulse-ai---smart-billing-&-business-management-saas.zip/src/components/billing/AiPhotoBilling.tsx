import React, { useState, useRef } from 'react';
import {
  Camera,
  Upload,
  Sparkles,
  CheckCircle,
  AlertTriangle,
  Trash2,
  Plus,
  Minus,
  RefreshCw,
  FileText,
  Share2,
  Download,
  Receipt,
  Edit2,
  Info,
  DollarSign,
  ArrowRight,
} from 'lucide-react';
import { Product, Business, InvoiceItem, Invoice } from '../../types';
import { api } from '../../services/api';
import { downloadInvoicePDF } from '../../utils/pdfGenerator';
import {
  shareViaWhatsApp,
  shareInvoiceNative,
  cleanWhatsAppPhone,
  getWhatsAppUrl,
} from '../../utils/whatsappShare';

interface AiPhotoBillingProps {
  business: Business;
  products: Product[];
  onBillConfirmed?: (invoice: Invoice) => void;
}

interface DraftItemRow {
  id: string;
  productId: string;
  name: string;
  detectedLabel: string;
  confidence: number;
  quantity: number;
  unitPrice: number;
  taxPercent: number;
  discountPercent: number;
  notes: string;
  needsVerification: boolean;
}

export const AiPhotoBilling: React.FC<AiPhotoBillingProps> = ({
  business,
  products,
  onBillConfirmed,
}) => {
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [mimeType, setMimeType] = useState<string>('image/jpeg');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [sceneSummary, setSceneSummary] = useState<string>('');
  const [lowConfidenceWarning, setLowConfidenceWarning] = useState<string | null>(null);
  const [draftItems, setDraftItems] = useState<DraftItemRow[]>([]);
  const [isConfirmedStep, setIsConfirmedStep] = useState(false);

  // Customer & Payment details for billing
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'Cash' | 'UPI' | 'Card' | 'Other'>('UPI');
  const [notes, setNotes] = useState('');

  // Generation status
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedInvoice, setGeneratedInvoice] = useState<Invoice | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Camera stream
  const [isCameraActive, setIsCameraActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Start Camera
  const startCamera = async () => {
    try {
      setErrorMessage(null);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
      setIsCameraActive(true);
    } catch (err: any) {
      console.error('Camera access error:', err);
      setErrorMessage('Unable to open camera. You can upload a photo from your gallery or use sample presets.');
    }
  };

  // Stop Camera
  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setIsCameraActive(false);
  };

  // Capture Photo from Camera
  const capturePhoto = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 640;
    canvas.height = videoRef.current.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
      setImagePreview(dataUrl);
      setMimeType('image/jpeg');
      stopCamera();
      analyzePhoto(dataUrl, 'image/jpeg');
    }
  };

  // File Upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      setImagePreview(dataUrl);
      setMimeType(file.type || 'image/jpeg');
      stopCamera();
      analyzePhoto(dataUrl, file.type || 'image/jpeg');
    };
    reader.readAsDataURL(file);
  };

  // Preset Sample generator for fast testing
  const loadPresetScenario = (type: 'supermarket' | 'cafe') => {
    stopCamera();
    // Create a representative SVG graphic for the basket
    const canvas = document.createElement('canvas');
    canvas.width = 600;
    canvas.height = 400;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(0, 0, 600, 400);

      // Draw counter surface
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(0, 200, 600, 200);

      ctx.fillStyle = '#38bdf8';
      ctx.font = 'bold 24px sans-serif';
      ctx.fillText(
        type === 'supermarket' ? '🛒 Sample Counter: 5 Lays + 3 Biscuits + 2 Bread' : '☕ Sample Cafe Tray: 2 Chai + 1 Puff + 1 Cheesecake',
        30,
        70
      );

      ctx.fillStyle = '#94a3b8';
      ctx.font = '14px sans-serif';
      ctx.fillText('Simulated multi-product photo capture for Gemini AI recognition test', 30, 105);

      // Draw mock product packets
      ctx.fillStyle = '#eab308';
      ctx.fillRect(60, 220, 110, 140);
      ctx.fillStyle = '#000';
      ctx.font = 'bold 16px sans-serif';
      ctx.fillText('LAYS x5', 80, 290);

      ctx.fillStyle = '#f97316';
      ctx.fillRect(200, 240, 120, 120);
      ctx.fillStyle = '#fff';
      ctx.fillText('BISCUIT x3', 215, 305);

      ctx.fillStyle = '#e2e8f0';
      ctx.fillRect(350, 200, 140, 160);
      ctx.fillStyle = '#000';
      ctx.fillText('BREAD x2', 380, 280);

      const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
      setImagePreview(dataUrl);
      setMimeType('image/jpeg');
      analyzePhoto(dataUrl, 'image/jpeg');
    }
  };

  // Analyze Photo with server-side Gemini
  const analyzePhoto = async (base64Img: string, mime: string) => {
    setIsAnalyzing(true);
    setErrorMessage(null);
    setGeneratedInvoice(null);
    try {
      const result = await api.recognizeProductsAI(base64Img, mime);
      setSceneSummary(result.sceneSummary);
      setLowConfidenceWarning(result.lowConfidenceWarning);

      // Map recognized draft items to rows
      const mappedRows: DraftItemRow[] = result.draftItems.map((item, idx) => {
        let matchedProd = products.find((p) => p.id === item.matchedProductId);
        if (!matchedProd && item.matchedProductName) {
          matchedProd = products.find((p) => p.name.toLowerCase() === item.matchedProductName.toLowerCase());
        }

        const price = matchedProd ? matchedProd.price : item.unitPrice || 0;
        const tax = matchedProd ? matchedProd.taxPercent : item.taxPercent || 5;

        return {
          id: `draft_${Date.now()}_${idx}`,
          productId: matchedProd ? matchedProd.id : item.matchedProductId || products[0]?.id || '',
          name: matchedProd ? matchedProd.name : item.matchedProductName || item.detectedLabel,
          detectedLabel: item.detectedLabel,
          confidence: item.confidence,
          quantity: item.quantity || 1,
          unitPrice: price,
          taxPercent: tax,
          discountPercent: 0,
          notes: item.notes,
          needsVerification: item.needsVerification || item.confidence < 75,
        };
      });

      setDraftItems(mappedRows);
    } catch (err: any) {
      console.error('AI Recognition Error:', err);
      setErrorMessage(err.message || 'Failed to analyze photo. You can manually add products below.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Handlers for Human Confirmation Editing (Section 7)
  const updateQuantity = (id: string, delta: number) => {
    setDraftItems((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, quantity: Math.max(1, item.quantity + delta) } : item
      )
    );
  };

  const updateUnitPrice = (id: string, price: number) => {
    setDraftItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, unitPrice: Math.max(0, price) } : item))
    );
  };

  const updateProductMatch = (id: string, productId: string) => {
    const prod = products.find((p) => p.id === productId);
    if (!prod) return;
    setDraftItems((prev) =>
      prev.map((item) =>
        item.id === id
          ? {
              ...item,
              productId: prod.id,
              name: prod.name,
              unitPrice: prod.price,
              taxPercent: prod.taxPercent,
              needsVerification: false,
              confidence: 99,
              notes: 'Manually verified item',
            }
          : item
      )
    );
  };

  const removeItem = (id: string) => {
    setDraftItems((prev) => prev.filter((item) => item.id !== id));
  };

  const addItemFromCatalog = () => {
    if (products.length === 0) return;
    const prod = products[0];
    setDraftItems((prev) => [
      ...prev,
      {
        id: `draft_${Date.now()}_add`,
        productId: prod.id,
        name: prod.name,
        detectedLabel: 'Manual Addition',
        confidence: 100,
        quantity: 1,
        unitPrice: prod.price,
        taxPercent: prod.taxPercent,
        discountPercent: 0,
        notes: 'Added by user',
        needsVerification: false,
      },
    ]);
  };

  // Calculations
  const calculatedItems: InvoiceItem[] = draftItems.map((item) => {
    const subtotal = item.quantity * item.unitPrice;
    const discountAmount = Math.round((subtotal * item.discountPercent) / 100);
    const taxable = subtotal - discountAmount;
    const taxAmount = Math.round((taxable * item.taxPercent) / 100);
    const total = taxable + taxAmount;
    return {
      productId: item.productId,
      name: item.name,
      quantity: item.quantity,
      unitPrice: item.unitPrice,
      taxPercent: item.taxPercent,
      discountPercent: item.discountPercent,
      subtotal,
      taxAmount,
      discountAmount,
      total,
    };
  });

  const subtotal = calculatedItems.reduce((acc, i) => acc + i.subtotal, 0);
  const discountTotal = calculatedItems.reduce((acc, i) => acc + i.discountAmount, 0);
  const taxTotal = calculatedItems.reduce((acc, i) => acc + i.taxAmount, 0);
  const grandTotal = subtotal - discountTotal + taxTotal;

  // HUMAN CONFIRMATION & BILL GENERATION (Section 7)
  const confirmAndGenerateBill = async () => {
    if (calculatedItems.length === 0) {
      setErrorMessage('Please add at least one item before generating a bill.');
      return;
    }

    const trimmedPhone = customerPhone.trim();

    // Bypass browser popup blockers: pre-open blank tab synchronously in user click handler
    let preWin: Window | null = null;
    if (trimmedPhone) {
      try {
        preWin = window.open('about:blank', '_blank');
      } catch (e) {
        preWin = null;
      }
    }

    setIsGenerating(true);
    setErrorMessage(null);

    try {
      const invoice = await api.createInvoice({
        items: calculatedItems,
        customerName: customerName.trim(),
        customerPhone: trimmedPhone,
        paymentMethod,
        subtotal,
        discountTotal,
        taxTotal,
        grandTotal,
        notes: `AI Photo Billing Verified • ${notes}`,
      });

      setGeneratedInvoice(invoice);
      if (onBillConfirmed) onBillConfirmed(invoice);

      // Auto-dispatch directly to the WhatsApp number entered in the bill
      if (trimmedPhone) {
        shareViaWhatsApp(invoice, business, trimmedPhone, preWin);
      } else if (preWin && !preWin.closed) {
        preWin.close();
      }
    } catch (err: any) {
      if (preWin && !preWin.closed) {
        preWin.close();
      }
      console.error('Invoice generation failed:', err);
      setErrorMessage(err.message || 'Unable to save bill. Please retry.');
    } finally {
      setIsGenerating(false);
    }
  };

  const resetAll = () => {
    setImagePreview(null);
    setDraftItems([]);
    setSceneSummary('');
    setLowConfidenceWarning(null);
    setGeneratedInvoice(null);
    setCustomerName('');
    setCustomerPhone('');
    setNotes('');
    stopCamera();
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      
      {/* Header Banner */}
      <div className="p-4 sm:p-6 rounded-3xl bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 rounded-full bg-blue-500/30 text-blue-300 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 border border-blue-400/20">
                <Sparkles className="w-3.5 h-3.5" />
                Gemini Vision POS
              </span>
              <span className="text-xs text-slate-300">Draft Verification Workflow</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black mt-2 tracking-tight">
              AI Photo Billing & Instant Recognition
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
              Snap one photo containing multiple shop products (e.g. 5 Lays, 3 biscuits, bread packets). Gemini AI identifies the items and counts, matching them with your registered catalog.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => loadPresetScenario('supermarket')}
              className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-bold border border-white/20 backdrop-blur-xs transition flex items-center gap-1.5"
              title="Loads simulated photo with 5 Lays + 3 Biscuits + 2 Breads"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>Test Retail Basket</span>
            </button>
            <button
              onClick={() => loadPresetScenario('cafe')}
              className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-bold border border-white/20 backdrop-blur-xs transition flex items-center gap-1.5"
              title="Loads simulated photo with Chai + Puff + Cheesecake"
            >
              <Sparkles className="w-3.5 h-3.5 text-blue-300" />
              <span>Test Cafe Tray</span>
            </button>
          </div>
        </div>
      </div>

      {errorMessage && (
        <div className="p-4 rounded-2xl bg-red-50 border border-red-200 text-red-700 text-xs sm:text-sm flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 shrink-0 text-red-500" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Main Grid: Capture / Photo on Left, Draft Confirmation Table on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">

        {/* LEFT COLUMN: Camera & Image Capture View */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm space-y-4">
            <h2 className="text-sm font-bold text-slate-900 flex items-center justify-between">
              <span>Step 1: Capture Product Photo</span>
              {imagePreview && (
                <button
                  onClick={resetAll}
                  className="text-xs text-blue-600 font-semibold hover:underline flex items-center gap-1"
                >
                  <RefreshCw className="w-3 h-3" />
                  Retake Photo
                </button>
              )}
            </h2>

            {/* Live Camera Viewfinder or Captured Preview */}
            <div className="relative aspect-4/3 w-full rounded-2xl bg-slate-900 overflow-hidden flex items-center justify-center border border-slate-800 shadow-inner">
              {isCameraActive ? (
                <>
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 border-2 border-dashed border-blue-400/60 pointer-events-none rounded-2xl m-4 flex items-center justify-center">
                    <span className="bg-black/60 backdrop-blur-md px-3 py-1 rounded-full text-[11px] font-semibold text-white tracking-wide">
                      Position Products Inside Counter Frame
                    </span>
                  </div>
                </>
              ) : imagePreview ? (
                <div className="relative w-full h-full">
                  <img
                    src={imagePreview}
                    alt="Captured Products"
                    className="w-full h-full object-cover"
                  />
                  {isAnalyzing && (
                    <div className="absolute inset-0 bg-black/70 backdrop-blur-xs flex flex-col items-center justify-center text-white p-4">
                      <div className="w-12 h-12 rounded-full border-4 border-blue-400 border-t-transparent animate-spin mb-3"></div>
                      <p className="font-bold text-sm text-center">Gemini AI Analyzing Scene...</p>
                      <p className="text-xs text-slate-300 mt-1">Matching items with {business.name} catalog</p>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center p-6 text-slate-400">
                  <div className="w-14 h-14 rounded-full bg-slate-800 mx-auto flex items-center justify-center text-slate-400 mb-3">
                    <Camera className="w-7 h-7" />
                  </div>
                  <p className="text-xs font-semibold text-slate-300">No Image Captured Yet</p>
                  <p className="text-[11px] text-slate-500 mt-1 max-w-xs mx-auto">
                    Take a photo of the counter or upload a photo of items to generate an instant draft bill.
                  </p>
                </div>
              )}
            </div>

            {/* Camera / Upload Action Buttons */}
            <div className="grid grid-cols-2 gap-3">
              {isCameraActive ? (
                <>
                  <button
                    onClick={capturePhoto}
                    className="col-span-2 py-3 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-md active:scale-98 transition flex items-center justify-center gap-2"
                  >
                    <div className="w-4 h-4 rounded-full bg-white animate-ping"></div>
                    Capture & Identify Products
                  </button>
                  <button
                    onClick={stopCamera}
                    className="col-span-2 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs transition"
                  >
                    Cancel Camera
                  </button>
                </>
              ) : (
                <>
                  <button
                    onClick={startCamera}
                    className="py-3 px-3 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm shadow-md active:scale-98 transition flex items-center justify-center gap-2"
                  >
                    <Camera className="w-4 h-4" />
                    <span>Open Camera</span>
                  </button>

                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="py-3 px-3 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs sm:text-sm border border-slate-200 active:scale-98 transition flex items-center justify-center gap-2"
                  >
                    <Upload className="w-4 h-4 text-blue-600" />
                    <span>Upload Photo</span>
                  </button>
                  <input
                    type="file"
                    ref={fileInputRef}
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </>
              )}
            </div>

            {/* Scene Summary Note */}
            {sceneSummary && (
              <div className="p-3.5 rounded-2xl bg-blue-50/70 border border-blue-100 text-slate-700 text-xs space-y-1">
                <div className="font-bold text-blue-900 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                  <span>AI Scene Analysis</span>
                </div>
                <p className="text-slate-600 leading-relaxed">{sceneSummary}</p>
              </div>
            )}
          </div>
        </div>

        {/* RIGHT COLUMN: Mandatory Human Confirmation & Draft Verification */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm space-y-4">
            
            {/* Draft Header with Warning */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base font-extrabold text-slate-900">
                    Step 2: Review Draft Bill
                  </h2>
                  <span className="px-2 py-0.5 rounded-md text-[10px] font-extrabold bg-amber-100 text-amber-800 uppercase tracking-wider">
                    Draft • Unconfirmed
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">
                  AI detected items below. You must inspect, adjust quantities, or swap items before confirmation.
                </p>
              </div>

              <button
                onClick={addItemFromCatalog}
                className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-xs font-bold text-slate-700 flex items-center gap-1 self-start sm:self-auto transition"
              >
                <Plus className="w-3.5 h-3.5 text-blue-600" />
                Add Item
              </button>
            </div>

            {lowConfidenceWarning && (
              <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-xs flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                <span>{lowConfidenceWarning}</span>
              </div>
            )}

            {/* Draft Items List */}
            {draftItems.length === 0 ? (
              <div className="py-12 text-center text-slate-400">
                <Receipt className="w-10 h-10 mx-auto text-slate-300 mb-2" />
                <p className="text-xs font-semibold">No products in draft bill</p>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Capture a photo or click "Test Retail Basket" above to generate items.
                </p>
              </div>
            ) : (
              <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
                {draftItems.map((item, idx) => {
                  const lineTotal = item.quantity * item.unitPrice;
                  return (
                    <div
                      key={item.id}
                      className={`p-3.5 rounded-2xl border transition-all ${
                        item.needsVerification
                          ? 'bg-amber-50/50 border-amber-300 shadow-xs'
                          : 'bg-slate-50/70 border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        
                        {/* Product Match Dropdown & Confidence */}
                        <div className="space-y-1 grow">
                          <div className="flex items-center gap-2">
                            <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-700 text-[11px] font-bold flex items-center justify-center shrink-0">
                              {idx + 1}
                            </span>
                            
                            {/* Product Selector */}
                            <select
                              value={item.productId}
                              onChange={(e) => updateProductMatch(item.id, e.target.value)}
                              className="text-xs font-bold text-slate-900 bg-white border border-slate-300 rounded-lg px-2 py-1 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                            >
                              {products.map((p) => (
                                <option key={p.id} value={p.id}>
                                  {p.name} ({business.currencySymbol}{p.price})
                                </option>
                              ))}
                            </select>

                            {/* Confidence pill */}
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-extrabold ${
                                item.confidence >= 85
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : item.confidence >= 65
                                  ? 'bg-amber-100 text-amber-800'
                                  : 'bg-red-100 text-red-800'
                              }`}
                              title={`AI Confidence Score: ${item.confidence}%`}
                            >
                              {item.confidence}% Match
                            </span>
                          </div>

                          <div className="text-[11px] text-slate-500 pl-7 flex items-center gap-2">
                            <span>Detected: <em>"{item.detectedLabel}"</em></span>
                            {item.notes && <span className="text-slate-400">• {item.notes}</span>}
                          </div>
                        </div>

                        {/* Quantity Stepper & Price */}
                        <div className="flex items-center justify-between sm:justify-end gap-3 pl-7 sm:pl-0">
                          
                          {/* Unit price input */}
                          <div className="flex items-center gap-1">
                            <span className="text-xs text-slate-500">{business.currencySymbol}</span>
                            <input
                              type="number"
                              min="0"
                              value={item.unitPrice}
                              onChange={(e) => updateUnitPrice(item.id, Number(e.target.value))}
                              className="w-16 px-1.5 py-1 text-xs font-bold text-slate-900 border border-slate-300 rounded-lg text-right"
                            />
                          </div>

                          {/* Stepper */}
                          <div className="flex items-center border border-slate-300 rounded-xl bg-white overflow-hidden shadow-2xs">
                            <button
                              onClick={() => updateQuantity(item.id, -1)}
                              className="px-2 py-1 text-slate-600 hover:bg-slate-100 active:bg-slate-200 transition"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="w-8 text-center text-xs font-bold text-slate-900">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => updateQuantity(item.id, 1)}
                              className="px-2 py-1 text-slate-600 hover:bg-slate-100 active:bg-slate-200 transition"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>

                          {/* Line total */}
                          <div className="w-16 text-right">
                            <span className="text-xs font-extrabold text-slate-900">
                              {business.currencySymbol}{lineTotal}
                            </span>
                          </div>

                          {/* Delete button */}
                          <button
                            onClick={() => removeItem(item.id)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 transition"
                            title="Remove Item"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Customer & Payment Inputs */}
            {draftItems.length > 0 && (
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      Customer Phone (WhatsApp)
                    </label>
                    <input
                      type="tel"
                      placeholder="e.g. 9876543210"
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 bg-white focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      Customer Name (Optional)
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Arun Balaji"
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 bg-white focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      Payment Mode
                    </label>
                    <div className="grid grid-cols-3 gap-1">
                      {(['UPI', 'Cash', 'Card'] as const).map((mode) => (
                        <button
                          key={mode}
                          type="button"
                          onClick={() => setPaymentMethod(mode)}
                          className={`py-1.5 text-xs font-bold rounded-lg border transition ${
                            paymentMethod === mode
                              ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                              : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          {mode}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Bill Summary Calculations */}
                <div className="pt-2 border-t border-slate-200/80 flex items-center justify-between text-xs">
                  <div className="space-x-4 text-slate-500">
                    <span>Subtotal: <strong className="text-slate-800">{business.currencySymbol}{subtotal}</strong></span>
                    <span>Tax: <strong className="text-slate-800">{business.currencySymbol}{taxTotal}</strong></span>
                    {discountTotal > 0 && (
                      <span className="text-red-600">Discount: -{business.currencySymbol}{discountTotal}</span>
                    )}
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-slate-500 block">Grand Total</span>
                    <span className="text-lg font-black text-blue-600">
                      {business.currencySymbol}{grandTotal}
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* MANDATORY HUMAN CONFIRMATION BUTTON (Section 7) */}
            {draftItems.length > 0 && (
              <button
                onClick={confirmAndGenerateBill}
                disabled={isGenerating}
                className="w-full py-4 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-extrabold text-sm sm:text-base shadow-lg shadow-blue-500/25 active:scale-99 transition flex items-center justify-center gap-2"
              >
                {isGenerating ? (
                  <>
                    <div className="w-5 h-5 rounded-full border-2 border-white border-t-transparent animate-spin"></div>
                    <span>Deducting Stock & Saving Invoice...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle className="w-5 h-5" />
                    <span>Confirm & Generate Final Bill ({business.currencySymbol}{grandTotal})</span>
                    <ArrowRight className="w-4 h-4 ml-1" />
                  </>
                )}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* POST-BILL CONFIRMATION MODAL / ACTION PANEL */}
      {generatedInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-lg rounded-3xl bg-white p-6 shadow-2xl space-y-5 animate-in zoom-in-95">
            <div className="text-center space-y-2">
              <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center shadow-inner">
                <CheckCircle className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-black text-slate-900">Bill Generated Successfully!</h3>
              <p className="text-xs text-slate-500">
                Invoice <strong className="text-slate-900">{generatedInvoice.invoiceNumber}</strong> has been generated and stock deducted.
              </p>
            </div>

            {/* Summary card */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-2">
              <div className="flex justify-between text-slate-600">
                <span>Customer:</span>
                <span className="font-bold text-slate-900">{generatedInvoice.customerName || 'Walk-in Guest'}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Total Items:</span>
                <span className="font-bold text-slate-900">{generatedInvoice.items.length} items</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Payment Mode:</span>
                <span className="font-bold text-slate-900">{generatedInvoice.paymentMethod}</span>
              </div>
              <div className="flex justify-between text-base font-black text-blue-600 pt-2 border-t border-slate-200">
                <span>Total Amount:</span>
                <span>{business.currencySymbol}{generatedInvoice.grandTotal}</span>
              </div>
            </div>

            {/* Direct WhatsApp delivery banner */}
            {customerPhone.trim() ? (
              <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-950 text-xs space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                    <span className="font-bold">Dispatched Direct to WhatsApp:</span>
                  </div>
                  <span className="font-mono font-black text-emerald-800 bg-white/80 px-2 py-0.5 rounded-md border border-emerald-200">
                    +{cleanWhatsAppPhone(customerPhone.trim())}
                  </span>
                </div>
                <p className="text-[11px] text-emerald-700">
                  Full itemized bill with tax and store receipt was sent to customer's WhatsApp chat.
                </p>
                <a
                  href={getWhatsAppUrl(generatedInvoice, business, customerPhone.trim())}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs flex items-center justify-center gap-2 shadow-xs transition"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>Open WhatsApp Chat (+{cleanWhatsAppPhone(customerPhone.trim())})</span>
                </a>
              </div>
            ) : (
              <button
                onClick={() => shareViaWhatsApp(generatedInvoice, business, customerPhone)}
                className="w-full py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-md flex items-center justify-center gap-2 active:scale-98 transition"
              >
                <Share2 className="w-4 h-4" />
                <span>Share Bill on WhatsApp</span>
              </button>
            )}

            {/* Actions: PDF, Print, New Bill */}
            <div className="space-y-2.5">

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => downloadInvoicePDF(generatedInvoice, business)}
                  className="py-2.5 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-800 font-bold text-xs flex items-center justify-center gap-1.5 transition"
                >
                  <Download className="w-4 h-4 text-blue-600" />
                  <span>Download PDF</span>
                </button>

                <button
                  onClick={() => shareInvoiceNative(generatedInvoice, business)}
                  className="py-2.5 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-800 font-bold text-xs flex items-center justify-center gap-1.5 transition"
                >
                  <Share2 className="w-4 h-4 text-indigo-600" />
                  <span>Device Share</span>
                </button>
              </div>

              <button
                onClick={resetAll}
                className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition"
              >
                Done • Start Next Bill
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
