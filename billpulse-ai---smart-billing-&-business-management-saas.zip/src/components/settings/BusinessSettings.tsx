import React, { useState } from 'react';
import {
  Settings,
  Store,
  FileText,
  DollarSign,
  Hash,
  CheckCircle,
  Save,
  Building,
} from 'lucide-react';
import { Business } from '../../types';
import { api } from '../../services/api';

interface BusinessSettingsProps {
  business: Business;
  onBusinessUpdated: (updated: Business) => void;
}

export const BusinessSettings: React.FC<BusinessSettingsProps> = ({
  business,
  onBusinessUpdated,
}) => {
  const [formData, setFormData] = useState({
    name: business.name || '',
    ownerName: business.ownerName || '',
    phone: business.phone || '',
    email: business.email || '',
    address: business.address || '',
    city: business.city || '',
    state: business.state || '',
    gstNumber: business.gstNumber || '',
    taxInfo: business.taxInfo || '',
    currency: business.currency || 'INR',
    currencySymbol: business.currencySymbol || '₹',
    invoicePrefix: business.invoicePrefix || 'INV',
    businessType: business.businessType || 'Cafe / Restaurant',
  });

  const [isSaving, setIsSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setErrorMessage(null);
    setSavedSuccess(false);

    try {
      const updated = await api.updateProfile(formData);
      onBusinessUpdated(updated);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to save business settings');
    } finally {
      setIsSaving(false);
    }
  };

  const sampleNextInvoice = `${formData.invoicePrefix.toUpperCase()}-${new Date().getFullYear()}-${String(
    business.nextInvoiceSequence
  ).padStart(6, '0')}`;

  return (
    <div className="max-w-4xl mx-auto space-y-5">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
        <div>
          <h1 className="text-lg font-black text-slate-900 flex items-center gap-2">
            <Building className="w-5 h-5 text-blue-600" />
            <span>Business Profile & Invoicing Branding</span>
          </h1>
          <p className="text-xs text-slate-500">
            Configure your official store name, GSTIN, currency, and invoice numbering sequence
          </p>
        </div>

        <span className="px-3 py-1 rounded-xl bg-blue-50 text-blue-700 text-xs font-bold self-start sm:self-auto">
          Tenant ID: {business.id}
        </span>
      </div>

      {savedSuccess && (
        <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center gap-2 animate-in fade-in">
          <CheckCircle className="w-4 h-4 text-emerald-600" />
          <span>Business settings saved successfully! New invoices will reflect this branding.</span>
        </div>
      )}

      {errorMessage && (
        <div className="p-3.5 rounded-2xl bg-red-50 text-red-700 text-xs font-semibold">
          {errorMessage}
        </div>
      )}

      <form onSubmit={handleSubmit} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-5 text-xs">
        
        {/* Core Store Details */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Store Profile & Owner Information
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Business Name (appears on bills) *</label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-hidden font-bold"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Business Category / Type</label>
              <input
                type="text"
                value={formData.businessType}
                onChange={(e) => setFormData({ ...formData, businessType: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Owner Name</label>
              <input
                type="text"
                value={formData.ownerName}
                onChange={(e) => setFormData({ ...formData, ownerName: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Contact Phone</label>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Email Address</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
              />
            </div>
          </div>
        </div>

        {/* Address & Tax info */}
        <div className="space-y-3 pt-3 border-t border-slate-100">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Address & Tax Identification
          </h3>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Store Address</label>
            <input
              type="text"
              placeholder="e.g. 12 West Masi Street, Opp Meenakshi Temple"
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            <div>
              <label className="block font-bold text-slate-700 mb-1">City</label>
              <input
                type="text"
                value={formData.city}
                onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">State</label>
              <input
                type="text"
                value={formData.state}
                onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">GSTIN Number (Optional)</label>
              <input
                type="text"
                placeholder="e.g. 33AAAAA0000A1Z5"
                value={formData.gstNumber}
                onChange={(e) => setFormData({ ...formData, gstNumber: e.target.value.toUpperCase() })}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-hidden font-mono uppercase"
              />
            </div>
          </div>
        </div>

        {/* Invoice Numbering & Currency */}
        <div className="space-y-3 pt-3 border-t border-slate-100">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Invoice Numbering & Currency Setup
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Invoice Prefix (e.g. CAFE, MART)</label>
              <input
                type="text"
                maxLength={6}
                value={formData.invoicePrefix}
                onChange={(e) => setFormData({ ...formData, invoicePrefix: e.target.value.toUpperCase().replace(/[^A-Z]/g, '') })}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-hidden font-mono font-bold uppercase"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Currency Code</label>
              <select
                value={formData.currency}
                onChange={(e) => {
                  const curr = e.target.value;
                  const sym = curr === 'USD' ? '$' : curr === 'EUR' ? '€' : curr === 'GBP' ? '£' : '₹';
                  setFormData({ ...formData, currency: curr, currencySymbol: sym });
                }}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
              >
                <option value="INR">INR (Indian Rupee - ₹)</option>
                <option value="USD">USD (US Dollar - $)</option>
                <option value="EUR">EUR (Euro - €)</option>
                <option value="GBP">GBP (British Pound - £)</option>
                <option value="AED">AED (Emirati Dirham - AED)</option>
              </select>
            </div>

            {/* Next Invoice Preview */}
            <div className="p-3 rounded-2xl bg-blue-50/70 border border-blue-200 text-slate-800">
              <span className="text-[10px] font-bold text-blue-800 uppercase tracking-wider block">
                Next Invoice Number Preview:
              </span>
              <span className="font-mono font-black text-sm text-blue-900 mt-1 block">
                {sampleNextInvoice}
              </span>
              <span className="text-[10px] text-slate-500">Atomic server-safe sequence</span>
            </div>
          </div>
        </div>

        {/* Submit */}
        <div className="pt-3 border-t border-slate-100 flex justify-end">
          <button
            type="submit"
            disabled={isSaving}
            className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md active:scale-98 transition flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            <span>{isSaving ? 'Saving...' : 'Save Business Settings'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
