import React, { useState, useEffect } from 'react';
import {
  FileText,
  Search,
  Calendar,
  Share2,
  Download,
  Edit3,
  CheckCircle,
  Clock,
  AlertCircle,
  X,
  History,
  Plus,
  Minus,
  Trash2,
} from 'lucide-react';
import { Invoice, Business, Product, InvoiceItem } from '../../types';
import { api } from '../../services/api';
import { downloadInvoicePDF } from '../../utils/pdfGenerator';
import {
  shareViaWhatsApp,
  shareInvoiceNative,
  cleanWhatsAppPhone,
  getWhatsAppUrl,
} from '../../utils/whatsappShare';

interface InvoiceListProps {
  business: Business;
  products: Product[];
  onInvoiceUpdated?: () => void;
}

export const InvoiceList: React.FC<InvoiceListProps> = ({
  business,
  products,
  onInvoiceUpdated,
}) => {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [paymentFilter, setPaymentFilter] = useState('All');
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);

  // WhatsApp Dispatch Modal State
  const [whatsappInvoice, setWhatsappInvoice] = useState<Invoice | null>(null);
  const [whatsappPhoneInput, setWhatsappPhoneInput] = useState('');

  // Correction Modal State
  const [correctingInvoice, setCorrectingInvoice] = useState<Invoice | null>(null);
  const [correctionReason, setCorrectionReason] = useState('');
  const [correctionItems, setCorrectionItems] = useState<InvoiceItem[]>([]);
  const [isSavingCorrection, setIsSavingCorrection] = useState(false);
  const [correctionError, setCorrectionError] = useState<string | null>(null);

  // Load Invoices
  const loadInvoices = async () => {
    setLoading(true);
    try {
      const data = await api.getInvoices({
        search: searchQuery || undefined,
        paymentMethod: paymentFilter !== 'All' ? paymentFilter : undefined,
      });
      setInvoices(data);
    } catch (err) {
      console.error('Failed to load invoices:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadInvoices();
  }, [searchQuery, paymentFilter]);

  // Open correction modal
  const openCorrectionModal = (inv: Invoice) => {
    setCorrectingInvoice(inv);
    setCorrectionReason('');
    setCorrectionItems(JSON.parse(JSON.stringify(inv.items)));
    setCorrectionError(null);
  };

  const updateItemQty = (index: number, delta: number) => {
    setCorrectionItems((prev) => {
      const copy = [...prev];
      const item = copy[index];
      const newQty = Math.max(1, item.quantity + delta);
      const subtotal = newQty * item.unitPrice;
      const discountAmount = Math.round((subtotal * item.discountPercent) / 100);
      const taxable = subtotal - discountAmount;
      const taxAmount = Math.round((taxable * item.taxPercent) / 100);
      copy[index] = {
        ...item,
        quantity: newQty,
        subtotal,
        discountAmount,
        taxAmount,
        total: taxable + taxAmount,
      };
      return copy;
    });
  };

  const updateItemPrice = (index: number, newPrice: number) => {
    setCorrectionItems((prev) => {
      const copy = [...prev];
      const item = copy[index];
      const unitPrice = Math.max(0, newPrice);
      const subtotal = item.quantity * unitPrice;
      const discountAmount = Math.round((subtotal * item.discountPercent) / 100);
      const taxable = subtotal - discountAmount;
      const taxAmount = Math.round((taxable * item.taxPercent) / 100);
      copy[index] = {
        ...item,
        unitPrice,
        subtotal,
        discountAmount,
        taxAmount,
        total: taxable + taxAmount,
      };
      return copy;
    });
  };

  const removeItemFromCorrection = (index: number) => {
    setCorrectionItems((prev) => prev.filter((_, i) => i !== index));
  };

  const addItemToCorrection = () => {
    if (products.length === 0) return;
    const p = products[0];
    const unitPrice = p.price;
    const taxPercent = p.taxPercent || 0;
    const subtotal = unitPrice * 1;
    const taxAmount = Math.round((subtotal * taxPercent) / 100);

    setCorrectionItems((prev) => [
      ...prev,
      {
        productId: p.id,
        name: p.name,
        sku: p.sku,
        quantity: 1,
        unitPrice,
        taxPercent,
        discountPercent: 0,
        subtotal,
        discountAmount: 0,
        taxAmount,
        total: subtotal + taxAmount,
      },
    ]);
  };

  const submitCorrection = async () => {
    if (!correctingInvoice) return;
    if (!correctionReason.trim()) {
      setCorrectionError('Please enter a specific reason for bill correction (audit requirement)');
      return;
    }
    if (correctionItems.length === 0) {
      setCorrectionError('An invoice must have at least one product item');
      return;
    }

    setIsSavingCorrection(true);
    setCorrectionError(null);

    try {
      const updated = await api.correctInvoice(correctingInvoice.id, {
        reason: correctionReason.trim(),
        items: correctionItems,
      });

      setInvoices((prev) => prev.map((inv) => (inv.id === updated.id ? updated : inv)));
      setCorrectingInvoice(null);
      if (onInvoiceUpdated) onInvoiceUpdated();
    } catch (err: any) {
      console.error('Correction failed:', err);
      setCorrectionError(err.message || 'Failed to submit correction');
    } finally {
      setIsSavingCorrection(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-5">
      
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
        <div>
          <h1 className="text-lg font-black text-slate-900 flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-600" />
            <span>Invoices & Transaction Records</span>
          </h1>
          <p className="text-xs text-slate-500">
            Real-time digital bills, PDF exports, WhatsApp sharing & full-audit bill corrections
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold px-3 py-1.5 rounded-xl bg-blue-50 text-blue-700">
            {invoices.length} Total Bills
          </span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
        <div className="sm:col-span-2 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search by invoice number (e.g. CAFE-2026-001043), customer name, or item..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
          />
        </div>

        <div>
          <select
            value={paymentFilter}
            onChange={(e) => setPaymentFilter(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
          >
            <option value="All">All Payment Modes</option>
            <option value="Cash">Cash</option>
            <option value="UPI">UPI</option>
            <option value="Card">Card</option>
            <option value="Other">Other</option>
          </select>
        </div>
      </div>

      {/* Invoices Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
        {loading ? (
          <div className="py-16 text-center text-slate-400">
            <div className="w-8 h-8 rounded-full border-2 border-blue-600 border-t-transparent animate-spin mx-auto mb-2"></div>
            <p className="text-xs font-semibold">Loading transactions...</p>
          </div>
        ) : invoices.length === 0 ? (
          <div className="py-16 text-center text-slate-400">
            <FileText className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-xs font-semibold">No invoices match your filter</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider text-[10px] border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Invoice #</th>
                  <th className="py-3 px-4">Date & Time</th>
                  <th className="py-3 px-4">Customer</th>
                  <th className="py-3 px-4">Items</th>
                  <th className="py-3 px-4">Payment</th>
                  <th className="py-3 px-4 text-right">Grand Total</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {invoices.map((inv) => {
                  const isCorrected = inv.status === 'corrected' || inv.correctionHistory?.length > 0;
                  return (
                    <tr key={inv.id} className="hover:bg-slate-50/80 transition">
                      <td className="py-3 px-4 font-mono font-bold text-slate-900">
                        {inv.invoiceNumber}
                      </td>
                      <td className="py-3 px-4 text-slate-500">
                        {new Date(inv.createdAt).toLocaleDateString('en-IN', {
                          day: '2-digit',
                          month: 'short',
                        })}{' '}
                        at{' '}
                        {new Date(inv.createdAt).toLocaleTimeString('en-IN', {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-900">
                          {inv.customerName || 'Walk-in Guest'}
                        </div>
                        {inv.customerPhone && (
                          <div className="text-[11px] text-slate-400">{inv.customerPhone}</div>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-[11px] font-semibold">
                          {inv.items.length} {inv.items.length === 1 ? 'item' : 'items'}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <span className="font-semibold text-slate-800">{inv.paymentMethod}</span>
                      </td>
                      <td className="py-3 px-4 text-right font-black text-slate-900 text-sm">
                        {business.currencySymbol}{inv.grandTotal}
                      </td>
                      <td className="py-3 px-4 text-center">
                        {isCorrected ? (
                          <span
                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800"
                            title="This bill was corrected with an audit trail"
                          >
                            <History className="w-3 h-3" />
                            Corrected
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                            Confirmed
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => setSelectedInvoice(inv)}
                            className="p-1.5 rounded-lg text-slate-600 hover:bg-slate-100"
                            title="View Digital Receipt"
                          >
                            <FileText className="w-4 h-4 text-slate-600" />
                          </button>

                          <button
                            onClick={() => downloadInvoicePDF(inv, business)}
                            className="p-1.5 rounded-lg text-slate-600 hover:bg-slate-100"
                            title="Download PDF"
                          >
                            <Download className="w-4 h-4 text-blue-600" />
                          </button>

                          <button
                            onClick={() => {
                              setWhatsappInvoice(inv);
                              setWhatsappPhoneInput(inv.customerPhone || '');
                            }}
                            className="p-1.5 rounded-lg text-slate-600 hover:bg-emerald-50 hover:text-emerald-700"
                            title="Send Bill Direct to WhatsApp"
                          >
                            <Share2 className="w-4 h-4 text-emerald-600" />
                          </button>

                          <button
                            onClick={() => openCorrectionModal(inv)}
                            className="p-1.5 rounded-lg text-slate-600 hover:bg-amber-50 hover:text-amber-700"
                            title="Correct Mistakes (Audit trail & stock reversal)"
                          >
                            <Edit3 className="w-4 h-4 text-amber-600" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* VIEW DIGITAL INVOICE MODAL */}
      {selectedInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-lg rounded-3xl bg-white p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center font-black">
                  BP
                </div>
                <div>
                  <h3 className="text-sm font-extrabold text-slate-900">{business.name}</h3>
                  <p className="text-[11px] text-slate-500">Digital Tax Invoice</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedInvoice(null)}
                className="p-1.5 rounded-full text-slate-400 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Meta */}
            <div className="p-3.5 rounded-2xl bg-slate-50 text-xs space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-500">Invoice Number:</span>
                <span className="font-mono font-bold text-slate-900">{selectedInvoice.invoiceNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Date:</span>
                <span className="font-semibold text-slate-900">
                  {new Date(selectedInvoice.createdAt).toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Customer:</span>
                <span className="font-semibold text-slate-900">
                  {selectedInvoice.customerName || 'Walk-in Guest'}{' '}
                  {selectedInvoice.customerPhone ? `(${selectedInvoice.customerPhone})` : ''}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Payment:</span>
                <span className="font-semibold text-slate-900">{selectedInvoice.paymentMethod}</span>
              </div>
            </div>

            {/* Item list */}
            <div className="space-y-2">
              <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                Billed Items
              </div>
              {selectedInvoice.items.map((item, i) => (
                <div key={i} className="flex justify-between text-xs py-1.5 border-b border-slate-100">
                  <div>
                    <span className="font-bold text-slate-900">{item.name}</span>
                    <span className="text-slate-500 block text-[11px]">
                      {item.quantity} × {business.currencySymbol}{item.unitPrice} (Tax {item.taxPercent}%)
                    </span>
                  </div>
                  <span className="font-bold text-slate-900">
                    {business.currencySymbol}{item.total}
                  </span>
                </div>
              ))}
            </div>

            {/* Summary */}
            <div className="pt-2 text-xs space-y-1">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal:</span>
                <span>{business.currencySymbol}{selectedInvoice.subtotal}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Tax:</span>
                <span>{business.currencySymbol}{selectedInvoice.taxTotal}</span>
              </div>
              <div className="flex justify-between text-base font-black text-blue-600 pt-2 border-t border-slate-200">
                <span>Grand Total:</span>
                <span>{business.currencySymbol}{selectedInvoice.grandTotal}</span>
              </div>
            </div>

            {/* Correction History view if any */}
            {selectedInvoice.correctionHistory?.length > 0 && (
              <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200 text-xs space-y-2">
                <div className="font-bold text-amber-900 flex items-center gap-1.5">
                  <History className="w-4 h-4 text-amber-600" />
                  <span>Audit Trail • Correction History</span>
                </div>
                {selectedInvoice.correctionHistory.map((corr, idx) => (
                  <div key={idx} className="text-slate-700 text-[11px] space-y-0.5 pb-2 border-b border-amber-200/60 last:border-0 last:pb-0">
                    <p className="font-semibold text-slate-900">
                      Reason: <span className="font-normal">{corr.reason}</span>
                    </p>
                    <p className="text-slate-500">
                      Adjusted by {corr.correctedBy} on {new Date(corr.correctedAt).toLocaleDateString()}
                    </p>
                    <p className="text-slate-600">
                      Amount updated from {business.currencySymbol}{corr.previousGrandTotal} to {business.currencySymbol}{corr.newGrandTotal}
                    </p>
                  </div>
                ))}
              </div>
            )}

            {/* Actions */}
            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={() => downloadInvoicePDF(selectedInvoice, business)}
                className="py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center justify-center gap-1.5"
              >
                <Download className="w-4 h-4" />
                <span>PDF Invoice</span>
              </button>
              <button
                onClick={() => {
                  setWhatsappInvoice(selectedInvoice);
                  setWhatsappPhoneInput(selectedInvoice.customerPhone || '');
                }}
                className="py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-xs"
              >
                <Share2 className="w-4 h-4" />
                <span>Send to WhatsApp</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* BILL CORRECTION MODAL (Section 12) */}
      {correctingInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-2xl rounded-3xl bg-white p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                  <Edit3 className="w-5 h-5 text-amber-600" />
                  <span>Correct Bill #{correctingInvoice.invoiceNumber}</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Reverses previous stock deductions and reapplies modified stock with full audit tracking.
                </p>
              </div>
              <button
                onClick={() => setCorrectingInvoice(null)}
                className="p-1.5 rounded-full text-slate-400 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {correctionError && (
              <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs font-semibold">
                {correctionError}
              </div>
            )}

            {/* Mandatory Reason Input */}
            <div>
              <label className="block text-xs font-bold text-slate-800 mb-1">
                Reason for Correction <span className="text-red-500">* (Required for Audit Trail)</span>
              </label>
              <input
                type="text"
                placeholder="e.g. Cashier mistakenly added 3 items instead of 2 / Customer changed item"
                value={correctionReason}
                onChange={(e) => setCorrectionReason(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
              />
            </div>

            {/* Items modification */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700">Modify Bill Items</span>
                <button
                  onClick={addItemToCorrection}
                  className="px-2.5 py-1 text-xs rounded-lg bg-slate-100 hover:bg-slate-200 font-semibold text-slate-700 flex items-center gap-1"
                >
                  <Plus className="w-3 h-3 text-blue-600" />
                  Add Product
                </button>
              </div>

              <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                {correctionItems.map((item, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs gap-2"
                  >
                    <div className="grow">
                      <div className="font-bold text-slate-900">{item.name}</div>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-slate-500">Unit Rate:</span>
                        <input
                          type="number"
                          value={item.unitPrice}
                          onChange={(e) => updateItemPrice(idx, Number(e.target.value))}
                          className="w-16 px-1.5 py-0.5 text-xs font-semibold rounded border border-slate-300"
                        />
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <div className="flex items-center border border-slate-300 rounded-lg bg-white overflow-hidden shadow-2xs">
                        <button
                          onClick={() => updateItemQty(idx, -1)}
                          className="px-2 py-0.5 text-slate-600 hover:bg-slate-100"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="w-6 text-center font-bold text-slate-900 text-xs">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateItemQty(idx, 1)}
                          className="px-2 py-0.5 text-slate-600 hover:bg-slate-100"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      <span className="w-16 text-right font-black text-slate-900">
                        {business.currencySymbol}{item.total}
                      </span>

                      <button
                        onClick={() => removeItemFromCorrection(idx)}
                        className="p-1 text-slate-400 hover:text-red-600"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="pt-2 border-t border-slate-200 flex items-center justify-between">
              <button
                onClick={() => setCorrectingInvoice(null)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100"
              >
                Cancel
              </button>

              <button
                onClick={submitCorrection}
                disabled={isSavingCorrection}
                className="px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-md active:scale-98 transition flex items-center gap-1.5"
              >
                {isSavingCorrection ? (
                  <>
                    <div className="w-3.5 h-3.5 rounded-full border-2 border-white border-t-transparent animate-spin"></div>
                    <span>Reversing Stock & Updating...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle className="w-4 h-4" />
                    <span>Save Correction & Reverse Inventory</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* DIRECT WHATSAPP DISPATCH MODAL */}
      {whatsappInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-md rounded-3xl bg-white p-6 shadow-2xl space-y-4 animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center">
                  <Share2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">Send Bill Direct to WhatsApp</h3>
                  <p className="text-xs font-mono text-slate-500">Bill No: {whatsappInvoice.invoiceNumber}</p>
                </div>
              </div>
              <button
                onClick={() => setWhatsappInvoice(null)}
                className="p-1.5 rounded-full text-slate-400 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-1.5">
              <div className="flex justify-between text-slate-600">
                <span>Customer:</span>
                <span className="font-bold text-slate-900">{whatsappInvoice.customerName || 'Walk-in Guest'}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Total Items:</span>
                <span className="font-semibold text-slate-900">{whatsappInvoice.items.length} items</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Payment Mode:</span>
                <span className="font-semibold text-slate-900">{whatsappInvoice.paymentMethod}</span>
              </div>
              <div className="flex justify-between text-sm font-black text-blue-600 pt-1.5 border-t border-slate-200">
                <span>Grand Total:</span>
                <span>{business.currencySymbol}{whatsappInvoice.grandTotal}</span>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700 flex items-center justify-between">
                <span>Recipient WhatsApp Number:</span>
                {whatsappPhoneInput.trim() && (
                  <span className="text-[10px] text-emerald-700 font-bold">
                    Cleaned: +{cleanWhatsAppPhone(whatsappPhoneInput.trim())}
                  </span>
                )}
              </label>
              <div className="relative">
                <div className="absolute left-2.5 top-2.5 text-slate-500 font-bold text-xs flex items-center gap-1 border-r border-slate-200 pr-1.5">
                  <span className="text-xs">🇮🇳</span>
                  <span>+91</span>
                </div>
                <input
                  type="tel"
                  placeholder="Enter 10-digit WhatsApp number"
                  value={whatsappPhoneInput}
                  onChange={(e) => setWhatsappPhoneInput(e.target.value)}
                  className="w-full pl-16 pr-3 py-2 text-xs rounded-xl border border-slate-300 bg-white focus:ring-2 focus:ring-emerald-500 font-semibold text-slate-900"
                />
              </div>
              <p className="text-[11px] text-slate-500">
                Itemized digital receipt with bill number {whatsappInvoice.invoiceNumber} will open directly in WhatsApp chat.
              </p>
            </div>

            <div className="space-y-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  const target = whatsappPhoneInput.trim();
                  shareViaWhatsApp(whatsappInvoice, business, target);
                  setWhatsappInvoice(null);
                }}
                className="w-full py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs shadow-md flex items-center justify-center gap-2 active:scale-98 transition"
              >
                <Share2 className="w-4 h-4 text-emerald-200" />
                <span>
                  {whatsappPhoneInput.trim()
                    ? `⚡ Send Bill Direct to WhatsApp (+91 ${cleanWhatsAppPhone(whatsappPhoneInput.trim())})`
                    : `Send to WhatsApp (Select Contact in WhatsApp)`}
                </span>
              </button>

              <button
                type="button"
                onClick={() => setWhatsappInvoice(null)}
                className="w-full py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
