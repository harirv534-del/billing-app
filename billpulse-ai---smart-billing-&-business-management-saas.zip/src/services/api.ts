import {
  Business,
  User,
  Product,
  Customer,
  Invoice,
  InvoiceItem,
  RecognitionResult,
} from '../types';

class ApiService {
  private currentBusinessId: string = localStorage.getItem('billpulse_business_id') || 'biz_cafe_01';
  private currentUserId: string = localStorage.getItem('billpulse_user_id') || 'user_karthik_01';
  private authToken: string = localStorage.getItem('billpulse_token') || '';

  public setSession(businessId: string | null, userId: string, token: string) {
    if (businessId) {
      this.currentBusinessId = businessId;
      localStorage.setItem('billpulse_business_id', businessId);
    }
    this.currentUserId = userId;
    this.authToken = token;
    localStorage.setItem('billpulse_user_id', userId);
    localStorage.setItem('billpulse_token', token);
  }

  public getBusinessId(): string {
    return this.currentBusinessId;
  }

  public getUserId(): string {
    return this.currentUserId;
  }

  public clearSession() {
    localStorage.removeItem('billpulse_business_id');
    localStorage.removeItem('billpulse_user_id');
    localStorage.removeItem('billpulse_token');
    this.currentBusinessId = 'biz_cafe_01';
    this.currentUserId = 'user_karthik_01';
    this.authToken = '';
  }

  private async request<T>(endpoint: string, options: RequestInit = {}, retries = 2): Promise<T> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'x-business-id': this.currentBusinessId,
      'x-user-id': this.currentUserId,
      ...(this.authToken ? { Authorization: `Bearer ${this.authToken}` } : {}),
      ...((options.headers as Record<string, string>) || {}),
    };

    let lastError: any = null;

    for (let attempt = 0; attempt <= retries; attempt++) {
      try {
        const response = await fetch(endpoint, {
          ...options,
          headers,
        });

        if (!response.ok) {
          const errorData = await response.json().catch(() => ({}));
          throw new Error(errorData.error || errorData.details || `Request failed with status ${response.status}`);
        }

        return (await response.json()) as T;
      } catch (err: any) {
        lastError = err;
        // Don't retry client errors (4xx) except network drop
        if (err.message && err.message.includes('status 4')) {
          break;
        }
        if (attempt < retries) {
          await new Promise((resolve) => setTimeout(resolve, 300 * (attempt + 1)));
        }
      }
    }

    console.warn(`API Warning on [${options.method || 'GET'}] ${endpoint}:`, lastError?.message || lastError);
    throw lastError;
  }

  // Auth
  async login(emailOrPhone: string, password?: string) {
    const res = await this.request<{ user: User; business: Business | null; token: string }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ emailOrPhone, password }),
    });
    if (res.business) {
      this.setSession(res.business.id, res.user.id, res.token);
    } else {
      this.setSession(null, res.user.id, res.token);
    }
    return res;
  }

  async register(data: any) {
    const res = await this.request<{ user: User; business: Business; token: string }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(data),
    });
    this.setSession(res.business.id, res.user.id, res.token);
    return res;
  }

  async getMe() {
    try {
      return await this.request<{ user: User; business: Business | null }>('/api/auth/me');
    } catch {
      return { user: null, business: null };
    }
  }

  // Business Profile & Staff
  async getProfile() {
    return this.request<Business>('/api/business/profile');
  }

  async updateProfile(updates: Partial<Business>) {
    return this.request<Business>('/api/business/profile', {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  }

  async getStaff() {
    return this.request<User[]>('/api/business/staff');
  }

  async addStaff(data: { name: string; email: string; phone?: string; role: string; password?: string }) {
    return this.request<User>('/api/business/staff', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  // Products
  async getProducts(params?: { search?: string; category?: string; lowStockOnly?: boolean }) {
    const query = new URLSearchParams();
    if (params?.search) query.set('search', params.search);
    if (params?.category) query.set('category', params.category);
    if (params?.lowStockOnly) query.set('lowStockOnly', 'true');
    try {
      const data = await this.request<Product[]>(`/api/products?${query.toString()}`);
      localStorage.setItem(`bp_cache_products_${this.currentBusinessId}`, JSON.stringify(data));
      return data;
    } catch (err) {
      const cached = localStorage.getItem(`bp_cache_products_${this.currentBusinessId}`);
      if (cached) return JSON.parse(cached) as Product[];
      throw err;
    }
  }

  async createProduct(product: Partial<Product>) {
    return this.request<Product>('/api/products', {
      method: 'POST',
      body: JSON.stringify(product),
    });
  }

  async updateProduct(id: string, updates: Partial<Product>) {
    return this.request<Product>(`/api/products/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  }

  async deleteProduct(id: string) {
    return this.request<{ success: boolean }>(`/api/products/${id}`, {
      method: 'DELETE',
    });
  }

  // AI Quick Photo Billing
  async recognizeProductsAI(imageBase64: string, mimeType?: string) {
    return this.request<RecognitionResult>('/api/ai/recognize-products', {
      method: 'POST',
      body: JSON.stringify({ imageBase64, mimeType: mimeType || 'image/jpeg' }),
    });
  }

  // Invoices & Billing
  async createInvoice(invoiceData: {
    items: InvoiceItem[];
    customerName?: string;
    customerPhone?: string;
    paymentMethod: 'Cash' | 'UPI' | 'Card' | 'Other';
    subtotal: number;
    taxTotal: number;
    discountTotal: number;
    grandTotal: number;
    notes?: string;
  }) {
    return this.request<Invoice>('/api/invoices/create', {
      method: 'POST',
      body: JSON.stringify(invoiceData),
    });
  }

  async getInvoices(params?: { search?: string; paymentMethod?: string; date?: string; limit?: number }) {
    const query = new URLSearchParams();
    if (params?.search) query.set('search', params.search);
    if (params?.paymentMethod) query.set('paymentMethod', params.paymentMethod);
    if (params?.date) query.set('date', params.date);
    if (params?.limit) query.set('limit', String(params.limit));
    try {
      const invoices = await this.request<Invoice[]>(`/api/invoices?${query.toString()}`);
      localStorage.setItem(`bp_cache_invoices_${this.currentBusinessId}`, JSON.stringify(invoices));
      return invoices;
    } catch (err) {
      const cached = localStorage.getItem(`bp_cache_invoices_${this.currentBusinessId}`);
      if (cached) return JSON.parse(cached) as Invoice[];
      return [];
    }
  }

  async getInvoiceById(id: string) {
    return this.request<{ invoice: Invoice; business: Business }>(`/api/invoices/${id}`);
  }

  async correctInvoice(
    id: string,
    data: {
      reason: string;
      items: InvoiceItem[];
      paymentMethod?: 'Cash' | 'UPI' | 'Card' | 'Other';
      customerName?: string;
      customerPhone?: string;
    }
  ) {
    return this.request<Invoice>(`/api/invoices/${id}/correct`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  }

  // Inventory
  async getInventoryStatus() {
    return this.request<{
      products: Product[];
      recentMovements: any[];
      summary: {
        totalProductsCount: number;
        totalStockUnits: number;
        totalInventoryValue: number;
        lowStockCount: number;
        outOfStockCount: number;
      };
    }>('/api/inventory/status');
  }

  async adjustStock(productId: string, changeQty: number, reason: string) {
    return this.request<Product>('/api/inventory/adjust', {
      method: 'POST',
      body: JSON.stringify({ productId, changeQty, reason }),
    });
  }

  // Customers
  async getCustomers(search?: string) {
    const q = search ? `?search=${encodeURIComponent(search)}` : '';
    try {
      return await this.request<Customer[]>(`/api/customers${q}`);
    } catch {
      return [];
    }
  }

  async getCustomerHistory(phone: string) {
    return this.request<{ customer?: Customer; invoices: Invoice[] }>(`/api/customers/${phone}/history`);
  }

  // Reports & Analytics with Resilient Caching & Offline Fallback
  async getDailyReport(date?: string) {
    const targetDate = date || new Date().toISOString().slice(0, 10);
    const cacheKey = `bp_cache_daily_${this.currentBusinessId}_${targetDate}`;

    try {
      const report = await this.request<{
        date: string;
        totalBills: number;
        totalRevenue: number;
        totalItemsSold: number;
        averageBillValue: number;
        topProduct: { name: string; qty: number; revenue: number } | null;
        topProductsList: Array<{ name: string; qty: number; revenue: number }>;
        paymentMethodsBreakdown: Record<string, number>;
        invoices: Invoice[];
      }>(`/api/reports/daily?date=${encodeURIComponent(targetDate)}`);

      localStorage.setItem(cacheKey, JSON.stringify(report));
      return report;
    } catch (err) {
      // 1. Try local cache
      const cached = localStorage.getItem(cacheKey);
      if (cached) {
        try {
          return JSON.parse(cached);
        } catch {}
      }

      // 2. Synthesize from cached invoices if available
      const cachedInvoicesRaw = localStorage.getItem(`bp_cache_invoices_${this.currentBusinessId}`);
      if (cachedInvoicesRaw) {
        try {
          const invoices: Invoice[] = JSON.parse(cachedInvoicesRaw);
          const dayInvoices = invoices.filter((inv) => inv.createdAt.startsWith(targetDate));
          let rev = 0;
          let items = 0;
          const pMap: Record<string, number> = { Cash: 0, UPI: 0, Card: 0, Other: 0 };
          const prodMap: Record<string, { name: string; qty: number; revenue: number }> = {};

          for (const inv of dayInvoices) {
            rev += inv.grandTotal;
            pMap[inv.paymentMethod] = (pMap[inv.paymentMethod] || 0) + inv.grandTotal;
            for (const item of inv.items) {
              items += item.quantity;
              if (!prodMap[item.productId]) {
                prodMap[item.productId] = { name: item.name, qty: 0, revenue: 0 };
              }
              prodMap[item.productId].qty += item.quantity;
              prodMap[item.productId].revenue += item.total;
            }
          }

          const topList = Object.values(prodMap).sort((a, b) => b.qty - a.qty);
          return {
            date: targetDate,
            totalBills: dayInvoices.length,
            totalRevenue: rev,
            totalItemsSold: items,
            averageBillValue: dayInvoices.length > 0 ? Math.round(rev / dayInvoices.length) : 0,
            topProduct: topList[0] || null,
            topProductsList: topList.slice(0, 10),
            paymentMethodsBreakdown: pMap,
            invoices: dayInvoices,
          };
        } catch {}
      }

      // 3. Clean empty fallback so UI never crashes
      return {
        date: targetDate,
        totalBills: 0,
        totalRevenue: 0,
        totalItemsSold: 0,
        averageBillValue: 0,
        topProduct: null,
        topProductsList: [],
        paymentMethodsBreakdown: { Cash: 0, UPI: 0, Card: 0, Other: 0 },
        invoices: [],
      };
    }
  }

  async getAnalytics() {
    const cacheKey = `bp_cache_analytics_${this.currentBusinessId}`;
    try {
      const data = await this.request<{
        dailyTrend: Array<{ date: string; revenue: number; bills: number }>;
        categoryBreakdown: Record<string, number>;
        topSellingProducts: Array<{ name: string; category: string; quantity: number; revenue: number }>;
        totalInvoicesRecorded: number;
        overallGrossVolume: number;
      }>('/api/reports/analytics');

      localStorage.setItem(cacheKey, JSON.stringify(data));
      return data;
    } catch (err) {
      const cached = localStorage.getItem(cacheKey);
      if (cached) {
        try {
          return JSON.parse(cached);
        } catch {}
      }

      // Clean default analytics timeline
      const dailyTrend = [];
      const now = new Date();
      for (let i = 29; i >= 0; i--) {
        const d = new Date(now.getTime() - i * 24 * 3600 * 1000);
        dailyTrend.push({ date: d.toISOString().slice(0, 10), revenue: 0, bills: 0 });
      }

      return {
        dailyTrend,
        categoryBreakdown: { General: 0 },
        topSellingProducts: [],
        totalInvoicesRecorded: 0,
        overallGrossVolume: 0,
      };
    }
  }

  async getAuditLogs() {
    try {
      return await this.request<any[]>('/api/audit-logs');
    } catch {
      return [];
    }
  }

  // Super Admin
  async adminLogin(password: string) {
    const res = await this.request<{ success: boolean; token: string; user: User }>('/api/admin/login', {
      method: 'POST',
      body: JSON.stringify({ email: 'admin@billpulse.io', password }),
    });
    this.setSession(null, res.user.id, res.token);
    return res;
  }

  async getAdminMetrics() {
    return this.request<any>('/api/admin/metrics');
  }

  async getAdminBusinesses() {
    try {
      return await this.request<any[]>('/api/admin/businesses');
    } catch {
      return [];
    }
  }

  async toggleBusinessStatus(id: string) {
    return this.request<Business>(`/api/admin/businesses/${id}/toggle-status`, {
      method: 'POST',
    });
  }

  async updateBusinessPlan(id: string, plan: string) {
    return this.request<Business>(`/api/admin/businesses/${id}/plan`, {
      method: 'POST',
      body: JSON.stringify({ plan }),
    });
  }
}

export const api = new ApiService();
