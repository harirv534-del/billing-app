export type Role = 'super_admin' | 'owner' | 'manager' | 'cashier' | 'staff';

export interface Business {
  id: string;
  name: string;
  ownerName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  country: string;
  gstNumber?: string;
  taxInfo?: string;
  currency: string;
  currencySymbol: string;
  invoicePrefix: string;
  nextInvoiceSequence: number;
  businessType: string;
  logoUrl?: string;
  active: boolean;
  plan: 'Free' | 'Pro' | 'Business' | 'Enterprise';
  createdAt: string;
  updatedAt: string;
}

export interface User {
  id: string;
  businessId: string | null;
  name: string;
  email: string;
  phone: string;
  role: Role;
  active: boolean;
  createdAt: string;
}

export interface Product {
  id: string;
  businessId: string;
  name: string;
  category: string;
  price: number;
  stock: number;
  lowStockLimit: number;
  sku: string;
  barcode?: string;
  taxPercent: number;
  description?: string;
  imageUrl?: string;
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface InvoiceItem {
  productId: string;
  name: string;
  sku?: string;
  quantity: number;
  unitPrice: number;
  taxPercent: number;
  discountPercent: number;
  subtotal: number;
  taxAmount: number;
  discountAmount: number;
  total: number;
}

export interface InvoiceCorrection {
  correctedAt: string;
  correctedBy: string;
  reason: string;
  previousGrandTotal: number;
  newGrandTotal: number;
  previousItems: InvoiceItem[];
  newItems: InvoiceItem[];
}

export interface Invoice {
  id: string;
  businessId: string;
  invoiceNumber: string;
  sequence: number;
  customerName?: string;
  customerPhone?: string;
  items: InvoiceItem[];
  subtotal: number;
  discountTotal: number;
  taxTotal: number;
  grandTotal: number;
  paymentMethod: 'Cash' | 'UPI' | 'Card' | 'Other';
  status: 'confirmed' | 'corrected' | 'cancelled';
  notes?: string;
  createdByUserId: string;
  createdByName: string;
  correctionHistory: InvoiceCorrection[];
  createdAt: string;
  updatedAt: string;
}

export interface Customer {
  id: string;
  businessId: string;
  name: string;
  phone: string;
  totalPurchases: number;
  totalSpent: number;
  lastPurchaseDate: string;
  invoicesCount: number;
  createdAt: string;
}

export interface InventoryMovement {
  id: string;
  businessId: string;
  productId: string;
  productName: string;
  type: 'sold' | 'added' | 'adjustment' | 'correction_reversal' | 'correction_reapply';
  quantityChange: number;
  previousStock: number;
  newStock: number;
  referenceId?: string;
  notes: string;
  timestamp: string;
}

export interface AuditLog {
  id: string;
  businessId?: string | null;
  userId: string;
  userName: string;
  action: string;
  details: string;
  timestamp: string;
}

export interface RecognizedItemDraft {
  detectedLabel: string;
  matchedProductId: string | null;
  matchedProductName: string;
  confidence: number;
  quantity: number;
  unitPrice: number;
  subtotal: number;
  taxPercent: number;
  notes: string;
  needsVerification: boolean;
}

export interface RecognitionResult {
  draftItems: RecognizedItemDraft[];
  sceneSummary: string;
  lowConfidenceWarning: string | null;
  processingTimeMs: number;
}
