import { jsPDF } from 'jspdf';
import { Invoice, Business } from '../types';

export function generateInvoicePDF(invoice: Invoice, business: Business): jsPDF {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 14;
  let y = 18;

  // Header / Brand
  doc.setFillColor(37, 99, 235); // Blue primary
  doc.rect(margin, y, pageWidth - margin * 2, 24, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text(business.name.toUpperCase(), margin + 6, y + 9);

  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'normal');
  const bizSubtext = `${business.address || ''}${business.city ? ', ' + business.city : ''} | Ph: ${business.phone || 'N/A'}`;
  doc.text(bizSubtext, margin + 6, y + 16);

  if (business.gstNumber) {
    doc.setFont('helvetica', 'bold');
    doc.text(`GSTIN: ${business.gstNumber}`, pageWidth - margin - 6, y + 16, { align: 'right' });
  }

  y += 32;

  // Invoice Meta & Customer Details
  doc.setTextColor(30, 41, 59);
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text('TAX INVOICE', margin, y);

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);

  const formattedDate = new Date(invoice.createdAt).toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
  const formattedTime = new Date(invoice.createdAt).toLocaleTimeString('en-IN', {
    hour: '2-digit',
    minute: '2-digit',
  });

  y += 6;
  doc.text(`Invoice No: `, margin, y);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text(invoice.invoiceNumber, margin + 22, y);

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  doc.text(`Date & Time: ${formattedDate} at ${formattedTime}`, pageWidth - margin, y, { align: 'right' });

  y += 6;
  doc.text(`Customer: `, margin, y);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text(invoice.customerName || 'Walk-in Guest', margin + 22, y);

  if (invoice.customerPhone) {
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100, 116, 139);
    doc.text(`Phone: ${invoice.customerPhone}`, margin + 80, y);
  }

  doc.text(`Payment: ${invoice.paymentMethod}`, pageWidth - margin, y, { align: 'right' });

  y += 10;

  // Items Table Header
  doc.setFillColor(241, 245, 249);
  doc.rect(margin, y, pageWidth - margin * 2, 8, 'F');
  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(51, 65, 85);

  doc.text('#', margin + 4, y + 5.5);
  doc.text('Item Description', margin + 14, y + 5.5);
  doc.text('Qty', margin + 95, y + 5.5, { align: 'right' });
  doc.text('Rate', margin + 125, y + 5.5, { align: 'right' });
  doc.text('Tax', margin + 145, y + 5.5, { align: 'right' });
  doc.text('Total', pageWidth - margin - 4, y + 5.5, { align: 'right' });

  y += 10;

  // Items List
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(15, 23, 42);

  invoice.items.forEach((item, index) => {
    // Check if new page is needed
    if (y > 260) {
      doc.addPage();
      y = 20;
    }

    const rowBg = index % 2 === 0 ? 255 : 250;
    doc.setFillColor(rowBg, rowBg, rowBg);
    doc.rect(margin, y - 4, pageWidth - margin * 2, 7, 'F');

    doc.text(String(index + 1), margin + 4, y);
    // Truncate name if long
    const cleanName = item.name.length > 40 ? item.name.substring(0, 38) + '...' : item.name;
    doc.text(cleanName, margin + 14, y);
    doc.text(String(item.quantity), margin + 95, y, { align: 'right' });
    doc.text(`${business.currencySymbol}${item.unitPrice.toFixed(2)}`, margin + 125, y, { align: 'right' });
    doc.text(`${item.taxPercent}%`, margin + 145, y, { align: 'right' });
    doc.setFont('helvetica', 'bold');
    doc.text(`${business.currencySymbol}${item.total.toFixed(2)}`, pageWidth - margin - 4, y, { align: 'right' });
    doc.setFont('helvetica', 'normal');

    y += 7;
  });

  y += 4;
  doc.setDrawColor(203, 213, 225);
  doc.line(margin, y, pageWidth - margin, y);
  y += 8;

  // Totals Breakdown
  const totalsX = pageWidth - margin - 75;

  doc.setFontSize(8.5);
  doc.setTextColor(100, 116, 139);
  doc.text('Subtotal:', totalsX, y);
  doc.setTextColor(15, 23, 42);
  doc.text(`${business.currencySymbol}${invoice.subtotal.toFixed(2)}`, pageWidth - margin - 4, y, { align: 'right' });

  y += 5.5;
  if (invoice.discountTotal > 0) {
    doc.setTextColor(100, 116, 139);
    doc.text('Discount:', totalsX, y);
    doc.setTextColor(220, 38, 38);
    doc.text(`-${business.currencySymbol}${invoice.discountTotal.toFixed(2)}`, pageWidth - margin - 4, y, { align: 'right' });
    y += 5.5;
  }

  doc.setTextColor(100, 116, 139);
  doc.text('Tax (GST/VAT):', totalsX, y);
  doc.setTextColor(15, 23, 42);
  doc.text(`${business.currencySymbol}${invoice.taxTotal.toFixed(2)}`, pageWidth - margin - 4, y, { align: 'right' });

  y += 6;
  doc.setFillColor(241, 245, 249);
  doc.rect(totalsX - 4, y - 4, 80, 8, 'F');
  doc.setFontSize(10.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(37, 99, 235);
  doc.text('Grand Total:', totalsX, y + 1.5);
  doc.text(`${business.currencySymbol}${invoice.grandTotal.toFixed(2)}`, pageWidth - margin - 4, y + 1.5, { align: 'right' });

  // Notes & Footer
  y += 18;
  if (invoice.notes) {
    doc.setFontSize(8);
    doc.setFont('helvetica', 'italic');
    doc.setTextColor(100, 116, 139);
    doc.text(`Note: ${invoice.notes}`, margin, y);
    y += 6;
  }

  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(148, 163, 184);
  doc.text('Thank you for your business! This is a computer-generated digital tax invoice.', margin, y);
  y += 4;
  doc.text('Go Paperless with BillPulse AI • Fast, Sustainable, Accurate Billing', margin, y);

  return doc;
}

export function downloadInvoicePDF(invoice: Invoice, business: Business) {
  const doc = generateInvoicePDF(invoice, business);
  doc.save(`${invoice.invoiceNumber}.pdf`);
}
