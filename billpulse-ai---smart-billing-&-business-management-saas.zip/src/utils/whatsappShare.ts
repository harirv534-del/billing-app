import { Invoice, Business } from '../types';

export function cleanWhatsAppPhone(rawPhone: string, defaultCountryCode = '91'): string {
  if (!rawPhone) return '';
  let cleaned = (rawPhone || '').replace(/[^0-9]/g, '');

  if (!cleaned) return '';

  // If phone starts with leading 00 (international format), strip 00
  if (cleaned.startsWith('00')) {
    cleaned = cleaned.substring(2);
  }
  // If phone starts with leading 0 and has 11 digits (e.g., 09876543210), strip the 0
  else if (cleaned.startsWith('0') && cleaned.length === 11) {
    cleaned = cleaned.substring(1);
  }

  // If exactly 10 digits (standard Indian mobile number without country code)
  if (cleaned.length === 10) {
    cleaned = `${defaultCountryCode}${cleaned}`;
  }

  return cleaned;
}

export function formatWhatsAppMessage(invoice: Invoice, business: Business): string {
  const symbol = business.currencySymbol || '₹';
  const lines: string[] = [];

  lines.push(`🧾 *TAX INVOICE - ${business.name.toUpperCase()}*`);
  if (business.address) lines.push(`📍 ${business.address}`);
  if (business.phone) lines.push(`📞 Phone: ${business.phone}`);
  if (business.gstNumber) lines.push(`🏛️ GSTIN: ${business.gstNumber}`);
  lines.push(`---------------------------------`);
  lines.push(`*Bill / Invoice No:* ${invoice.invoiceNumber}`);
  lines.push(`*Date:* ${new Date(invoice.createdAt).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })} at ${new Date(invoice.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`);
  lines.push(`*Customer:* ${invoice.customerName || 'Valued Guest'}`);
  if (invoice.customerPhone) {
    lines.push(`*Mobile / WhatsApp:* ${invoice.customerPhone}`);
  }
  lines.push(`---------------------------------`);
  lines.push(`*ITEMS PURCHASED:*`);

  invoice.items.forEach((item, idx) => {
    lines.push(`${idx + 1}. *${item.name}*`);
    lines.push(`   ${item.quantity} × ${symbol}${item.unitPrice} = *${symbol}${item.total}*`);
  });

  lines.push(`---------------------------------`);
  lines.push(`Subtotal: ${symbol}${invoice.subtotal}`);
  if (invoice.discountTotal > 0) {
    lines.push(`Discount: -${symbol}${invoice.discountTotal}`);
  }
  lines.push(`Tax (GST): ${symbol}${invoice.taxTotal}`);
  lines.push(`*GRAND TOTAL: ${symbol}${invoice.grandTotal}*`);
  lines.push(`*Payment Mode:* ${invoice.paymentMethod}`);
  lines.push(`---------------------------------`);
  lines.push(`🙏 _Thank you for shopping with ${business.name}!_`);
  lines.push(`🌱 _Digital paperless tax invoice powered by BillPulse AI_`);

  return lines.join('\n');
}

export function getWhatsAppUrl(invoice: Invoice, business: Business, targetPhone?: string): string {
  const message = formatWhatsAppMessage(invoice, business);
  const encodedText = encodeURIComponent(message);
  const phone = cleanWhatsAppPhone(targetPhone || invoice.customerPhone || '');

  // wa.me is the official WhatsApp universal link supported across Android, iOS, WhatsApp Web and WhatsApp Desktop
  return phone
    ? `https://wa.me/${phone}?text=${encodedText}`
    : `https://wa.me/?text=${encodedText}`;
}

export function openWhatsAppDirect(url: string, preOpenedWindow?: Window | null): boolean {
  try {
    if (preOpenedWindow && !preOpenedWindow.closed) {
      preOpenedWindow.location.href = url;
      preOpenedWindow.focus();
      return true;
    }

    const a = document.createElement('a');
    a.href = url;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    return true;
  } catch (e) {
    try {
      window.open(url, '_blank', 'noopener,noreferrer');
      return true;
    } catch (err) {
      console.error('Failed to open WhatsApp window:', err);
      return false;
    }
  }
}

export function shareViaWhatsApp(
  invoice: Invoice,
  business: Business,
  targetPhone?: string,
  preOpenedWindow?: Window | null
): string {
  const url = getWhatsAppUrl(invoice, business, targetPhone);
  openWhatsAppDirect(url, preOpenedWindow);
  return url;
}

export async function shareInvoiceNative(invoice: Invoice, business: Business) {
  const text = formatWhatsAppMessage(invoice, business);
  if (typeof navigator !== 'undefined' && navigator.share) {
    try {
      await navigator.share({
        title: `Invoice ${invoice.invoiceNumber} - ${business.name}`,
        text,
      });
      return true;
    } catch (e) {
      console.warn('Native share dismissed or failed:', e);
    }
  }
  // Fallback to WhatsApp
  shareViaWhatsApp(invoice, business);
  return true;
}
